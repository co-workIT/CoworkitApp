import 'package:co_workit/translations/translation_service.dart';
import 'package:co_workit/view/auth/login_screen.dart';
import 'package:co_workit/view/bottom_bar/new_bottom_bar.dart';
import 'package:co_workit/view/meetings/meeting_view.dart';
// import 'package:co_workit/view/auth/login_screen.dart';
// import 'package:co_workit/view/bottom_bar/new_bottom_bar.dart';
// import 'package:co_workit/view/meetings/meeting_view.dart';
// import 'package:co_workit/view/onbaording/onboarding.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'controllers/http_controller.dart';
import 'controllers/theme_controllers.dart';
import 'theme/themes.dart';

import 'dart:io';

import 'view/mailing/mailing_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  Get.put(ThemeController());
  HttpOverrides.global = MyHttpOverrides();//only for development phase not to be used during deployment phase
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ThemeController>(
      builder: (themeController) {
        return GetMaterialApp(
          translations: AppTranslations(), // Your translations
          locale: Locale('en', 'US'), // Initial locale
          fallbackLocale: Locale('en', 'US'), // Fallback locale
          color: Colors.black87,
          debugShowCheckedModeBanner: false,
          title: 'Cowork it',
          theme: lightTheme,
          darkTheme: darkTheme,
          themeMode: themeController.isDarkMode.value == true
              ? ThemeMode.dark
              : ThemeMode.light,
          home: LoginScreen(),
        );
      },
    );
  }
}
