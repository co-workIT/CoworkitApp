import 'dart:convert';

import 'package:co_workit/controllers/meetings_controller.dart';
import 'package:co_workit/models/booking_model.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class BookingController extends GetxController {
  var isLoading = true.obs;
  var bookingList = <Data>[].obs;
  final MeetingController controller = Get.put(MeetingController());

  final storage = FlutterSecureStorage();

  @override
  void onInit() {
    fetchBookings(id: 2); // Initial call with a default ID
    super.onInit();
  }

  void fetchBookings({required int id}) async {
    final String? token = await storage.read(key: 'auth_token');
    try {
      isLoading(true);
      if (token != null) {
        var response = await http.post(
          Uri.parse(
              'https://coworkitportal.creativeitpark.org/api/booking/get/$id'),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer $token', //bearer token
          },
        );
        print(response.body);
        if (response.statusCode == 200) {
          var jsonResponse = json.decode(response.body);
          var bookingModel = BookingModel.fromJson(jsonResponse);
          bookingList.assignAll(bookingModel.data!);
        } else {
          Get.snackbar('Error', 'Failed to load bookings');
        }
      }
    } catch (e) {
      Get.snackbar('Error', 'Failed to load bookings');
    } finally {
      isLoading(false);
    }
  }

  Future<void> editBooking(String companyId, String spaceId, String userId,
      String startDate, String endDate) async {
    final String? token = await storage.read(key: 'auth_token');
    try {
      if (token != null) {
        var response = await http.post(
          Uri.parse(
              'https://coworkitportal.creativeitpark.org/api/booking/edit/$companyId'),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer $token',
          },
          body: json.encode({
            'space_id': spaceId,
            'user_id': userId,
            'start_date': startDate,
            'end_date': endDate,
          }),
        );
        print('editbookings reponse:: $response.body');
        if (response.statusCode == 200) {
          Get.snackbar('Success', 'Booking edited successfully');
        } else {
          Get.snackbar('Error', 'Failed to edit booking');
        }
      }
    } catch (e) {
      Get.snackbar('Error', 'Failed to edit booking');
    }
  }

  Future<void> updateBooking(String companyId, String spaceId, String userId,
      String startDate, String endDate) async {
    final String? token = await storage.read(key: 'auth_token');
    try {
      if (token != null) {
        var response = await http.post(
          Uri.parse(
              'https://coworkitportal.creativeitpark.org/api/booking/update/$companyId'),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer $token',
          },
          body: json.encode({
            'space_id': spaceId,
            'user_id': userId,
            'start_date': startDate,
            'end_date': endDate,
          }),
        );
        print('Updatebookings reponse:: $response.body');
        if (response.statusCode == 200) {
          Get.snackbar('Success', 'Booking updated successfully');
        } else {
          Get.snackbar('Error', 'Failed to update booking');
        }
      }
    } catch (e) {
      Get.snackbar('Error', 'Failed to update booking');
    }
  }
}
