import 'dart:convert';

import 'package:co_workit/models/login_model.dart';
import 'package:co_workit/view/auth/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AuthService extends GetxController {
  final String _loginUrl =
      'https://coworkitportal.creativeitpark.org/api/login';
  final String _logoutEndpointUrl =
      'https://coworkitportal.creativeitpark.org/api/logout';
  final storage = const FlutterSecureStorage();
  final formKey = GlobalKey<FormState>();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  var isLoading = false.obs;
  LoginModel? loginModel;
  var user = LoginModel().obs;

  Future<bool> login(String email, String password) async {
    try {
      isLoading.value = true;
      final response = await http.post(
        Uri.parse(_loginUrl),
        body: {
          'email': email,
          'password': password,
        },
      );

      print(response.body);

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = json.decode(response.body);
        final LoginModel model =
            LoginModel.fromJson(responseData); // Parse response to LoginModel
        if (model.isSuccess ?? false) {
          final String? token = model.data?.token;
          final String? company_id = model.data?.user?.companyId;
          print('token: $token');
          print('company id: $company_id');
          if (token != null && company_id != null) {
            await storage.write(key: 'auth_token', value: token);
            await storage.write(key: 'company_id', value: company_id);
            loginModel = model;
            await _saveUserPreferences(model);
            return true;
          }
        }
        print('Login success but authentication failed');
      } else {
        print('Failed to login: ${response.statusCode}');
      }
      return false;
    } catch (e) {
      print('Login error: $e');
      return false;
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> _saveUserPreferences(LoginModel model) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    // Convert LoginModel to JSON string
    String jsonString = jsonEncode(loginModel?.toJson());
    // Store JSON string in SharedPreferences
    await prefs.setString('loginModel', jsonString);
  }

  Future<void> _loadUserPreferences() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    // Retrieve JSON string from SharedPreferences
    String? jsonString = prefs.getString('loginModel');
    if (jsonString != null) {
      // Convert JSON string to LoginModel
      Map<String, dynamic> jsonMap = jsonDecode(jsonString);
      LoginModel loginModel = LoginModel.fromJson(jsonMap);
      print('User ID: ${loginModel.data?.user?.id}');
      print('User Name: ${loginModel.data?.user?.name}');
    } else {
      print('No data found in SharedPreferences');
    }
  }

  Future<void> logout() async {
    try {
      final String? token = await storage.read(key: 'auth_token');
      if (token != null) {
        final response = await http.post(
          Uri.parse(_logoutEndpointUrl),
          headers: {
            'Authorization': 'Bearer $token',
          },
          body: {},
        );
        if (response.statusCode == 200) {
          await _clearUserPreferences(); // Clear user preferences on logout
          Get.to(() => LoginScreen());
          print('Logged out');
        } else {
          print('Logout failed: ${response.statusCode}');
        }
      }
    } catch (e) {
      print('Logout error: $e');
    }
  }

  Future<void> _clearUserPreferences() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('loginModel');
    await storage.delete(key: 'auth_token');
    await storage.delete(key: 'company_id');
  }

  String? validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your email';
    }
    final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
    if (!emailRegex.hasMatch(value)) {
      return 'Please enter a valid email address';
    }
    return null;
  }

  String? validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your password';
    }
    if (value.length < 6) {
      return 'Password must be at least 6 characters long';
    }
    return null;
  }
}
