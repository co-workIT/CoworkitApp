import 'dart:convert';

import 'package:co_workit/models/mailing_model.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class MailingController extends GetxController {
  List<Data> mailingList = <Data>[].obs;

  var isLoading = false.obs;
  final storage = FlutterSecureStorage();
  final String _endpointUrl =
      'https://coworkitportal.creativeitpark.org/api/mail/store';

  @override
  void onInit() {
    fetchMailingData();
    super.onInit();
  }

  void fetchMailingData() async {
    isLoading.value = true;
    try {
      final String? token = await storage.read(key: 'auth_token');
      final String? company_id = await storage.read(key: 'company_id');

      if (token != null && company_id != null) {
        var response = await http.get(
          Uri.parse(
              'https://coworkitportal.creativeitpark.org/api/mail/get/$company_id'),
          headers: {
            'Authorization': 'Bearer $token',
          },
        );
        print(response.body);
        if (response.statusCode == 200) {
          var jsonString = json.decode(response.body);
          var mailingModel = MailingModel.fromJson(jsonString);
          if (mailingModel.data != null) {
            mailingList.assignAll(mailingModel.data!);
          }
          print('Successfully loaded mailings');
        } else {
          Get.snackbar('Error', 'Failed to load data');
          print('Error: Failed to load data');
        }
      } else {
        Get.snackbar('Error', 'Token or Company ID is null');
        print('Error: Token or Company ID is null');
      }
    } catch (e) {
      print('Error: ${e.toString()}');
      Get.snackbar('Error', e.toString());
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> addMailing(String name, String date) async {
    isLoading.value = true;
    try {
      final String? token = await storage.read(key: 'auth_token');
      final String? companyId = await storage.read(key: 'company_id');
      // print('company id: $companyId');
      if (token != null && companyId != null) {
        final response = await http.post(
          Uri.parse(_endpointUrl),
          headers: {
            'Authorization': 'Bearer $token',
            'Content-Type': 'application/json',
          },
          body: jsonEncode({
            'name': name,
            'date': date,
            'company_id': companyId,
          }),
        );

        print(response.body);
        if (response.statusCode == 200) {
          fetchMailingData(); // Fetch the full list to ensure consistency
          print('Added new mailing');
        } else {
          print('Failed to add new mailing: ${response.statusCode}');
          print('Response body: ${response.body}');
        }
      } else {
        print('Token is null');
      }
    } catch (e) {
      print('Fetch data error: $e');
    } finally {
      isLoading.value = false; // Set loading to false when finished
    }
  }

  Future<void> updateMailing(
      String id, String name, String date, String companyId) async {
    isLoading.value = true;
    try {
      final String? token = await storage.read(key: 'auth_token');

      if (token != null) {
        final response = await http.put(
          Uri.parse(
              'https://coworkitportal.creativeitpark.org/api/mail/update/$id'),
          headers: {
            'Authorization': 'Bearer $token',
            'Content-Type': 'application/json',
          },
          body: jsonEncode({
            'name': name,
            'date': date,
            'company_id': companyId,
          }),
        );
        //print(response.body);
        if (response.statusCode == 200) {
          // Refresh the mailing list
          fetchMailingData();
        } else {
          print('Failed to update mailing: ${response.statusCode}');
          //print('Response body: ${response.body}');
        }
      } else {
        print('Token is null');
      }
    } catch (e) {
      print('Update data error: $e');
    } finally {
      isLoading.value = false;
    }
  }
}
