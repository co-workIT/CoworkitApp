import 'package:co_workit/models/new_mailing_model.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';


class MailingController extends GetxController {

  var mailings = <MailingModel>[].obs;
  var isLoading = true.obs;
  var errorMessage = ''.obs;

  @override
  void onInit() {
    fetchMailings();
    super.onInit();
  }

  Future<void> fetchMailings() async {
    isLoading(true);
    // try {
      final response = await http.get(
        Uri.parse('https://justiceontrack.creativeitpark.org/api/lawyers/list'),
        headers: {
          'Authorization': '12|IhiwsNdIJgDrWHKSUT4LBLTmpM28T5wQIFcJXSYe',
        },
      );
    print('response body ${response.body}');
      if (response.statusCode == 200) {
        var jsonResponse = json.decode(response.body);
        MailingResponse mailingResponse = MailingResponse.fromJson(jsonResponse);
        mailings.value = mailingResponse.data;
      } else {
        print('response body ${response.body}');
        errorMessage.value = 'Failed to load mailings';
      }

    // } catch (e) {
    //   print(e);
    //   errorMessage.value = 'An error occurred: $e';
    // } finally {
    //   isLoading(false);
    // }
  }
}
