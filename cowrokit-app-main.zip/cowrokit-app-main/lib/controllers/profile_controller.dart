import 'dart:convert';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/login_model.dart';
import '../controllers/auth_controller.dart';

class ProfileController extends GetxController {
  final AuthService authService = Get.put(AuthService());
  Rx<LoginModel> user = LoginModel().obs;
  var isLoading = true.obs; // Loading state

  @override
  void onInit() {
    super.onInit();
    fetchUserData();
  }

  // Fetch user data from SharedPreferences
  Future<void> fetchUserData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? jsonString = prefs.getString('loginModel');

    if (jsonString != null) {
      Map<String, dynamic> jsonMap = jsonDecode(jsonString);
      user.value = LoginModel.fromJson(jsonMap);
    } else {
      // Handle the case where there is no data
      print('No user data found in SharedPreferences');
      user.value = LoginModel(); // or handle accordingly
    }

    isLoading(false);
  }
}
