import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart'; // Add this import

import '../models/meeting_model.dart';

class MeetingController extends GetxController {
  var isLoading = true.obs;
  var meetingList = <Data>[].obs;
  var filteredMeetings = <Data>[].obs; // Add this observable
  var selectedDate = DateTime.now().obs; // Add this observable
  var datesWithMeetings = <String>{}.obs; // Add this observable
  final storage = FlutterSecureStorage();

  @override
  void onInit() {
    fetchMeetings();
    super.onInit();
  }

  Future<void> fetchMeetings() async {
    final String? token = await storage.read(key: 'auth_token');
    try {
      isLoading(true);
      var response = await http.get(
        Uri.parse(
            'https://coworkitportal.creativeitpark.org/api/meeting_room/get'),
        headers: {
          'Authorization': 'Bearer $token',
        },
      );
      print(response.body);
      if (response.statusCode == 200) {
        var jsonString = json.decode(response.body);
        var meetingModel = MeetingModel.fromJson(jsonString);
        if (meetingModel.data != null) {
          meetingList.value = meetingModel.data!;
          datesWithMeetings.value = meetingList
              .map((meeting) => DateFormat('yyyy-MM-dd')
                  .format(DateTime.parse(meeting.createdAt!)))
              .toSet();
          filterMeetingsByDate(selectedDate.value); // Filter meetings on fetch
        }
      } else {
        Get.snackbar("Error", "Failed to fetch data");
      }
    } catch (e) {
      print(e.toString());
      Get.snackbar("Error", e.toString());
    } finally {
      isLoading(false);
    }
  }

  void filterMeetingsByDate(DateTime date) {
    String dateStr = DateFormat('yyyy-MM-dd').format(date);
    filteredMeetings.value = meetingList.where((meeting) {
      return meeting.ConvertDate(meeting.createdAt!, true) == dateStr;
    }).toList();
  }
}
