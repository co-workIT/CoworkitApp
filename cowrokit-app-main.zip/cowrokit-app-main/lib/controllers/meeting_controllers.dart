import 'package:co_workit/utills/token_service.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/meeting_model.dart';

class MeetingController extends GetxController {
  var isLoading = true.obs;
  var meetingList = <Data>[].obs;

  @override
  void onInit() {
    fetchMeetings();
    super.onInit();
  }

  void fetchMeetings() async {
    try {
      isLoading(true);
      String? token ='10|ThbLPsHnSUlxl5mD04j11UVAXmDwpSxpRUU0P01Y';
      // await TokenService.getToken(); // Retrieve the token
      var response = await http.get(
        Uri.parse('https://coworkitportal.creativeitpark.org/api/meeting_room/get'), // Replace with your actual API URL
        headers: {
          'Authorization': 'Bearer $token', // Include the Bearer token
          'Accept': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        var jsonResponse = json.decode(response.body);
        var getMeetingModel = MeetingModel.fromJson(jsonResponse);
        meetingList.value = getMeetingModel.data ?? [];
      } else {
        // Handle error
        print("Error: ${response.statusCode}");
      }
    } catch (e) {
      print("Error: $e");
    } finally {
      isLoading(false);
    }
  }
}
