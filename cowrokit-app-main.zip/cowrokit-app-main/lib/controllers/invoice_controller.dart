import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import '../models/invoice_model_new.dart';

class InvoiceController extends GetxController {
  var invoices = <Data>[].obs;

  final storage = FlutterSecureStorage();
  var isLoading = true.obs;

  @override
  void onInit() {
    super.onInit();
    FetchInvoice();
  }

  Future<void> FetchInvoice() async {
    isLoading(true);
    try {
      final String? token = await storage.read(key: 'auth_token');
      final String? companyId = await storage.read(key: 'company_id');

      if (token != null) {
        final response = await http.get(
          Uri.parse(
              'https://coworkitportal.creativeitpark.org/api/invoice/get/$companyId'),
          headers: {
            'Authorization': 'Bearer $token',
          },
        );

        if (response.statusCode == 200) {
          var jsonString = json.decode(response.body);
          var invoiceModel = InvoiceModel.fromJson(jsonString);
          if (invoiceModel.data != null) {
            invoices.value = invoiceModel.data!;
            print('successfully loaded invoices ');
            isLoading(false);
          } else {
            isLoading(false);
            print('Failed to load invoices: no data');
          }
        } else {
          isLoading(false);
          print('Failed to load invoices: ${response.statusCode}');
        }
      } else {
        print('No auth token found');
      }
    } catch (e) {
      print('Fetch data error: $e');
    }
  }
}
