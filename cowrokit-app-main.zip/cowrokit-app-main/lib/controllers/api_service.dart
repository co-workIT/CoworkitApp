// import 'dart:convert';
//
// import 'package:co_workit/models/invoice_model_new.dart';
// import 'package:flutter_secure_storage/flutter_secure_storage.dart';
// import 'package:http/http.dart' as http;
//
// class ApiService {
//   int company_id=1;
//   final String _endpointUrl = 'https://coworkitportal.creativeitpark.org/api/invoice/get/1';
//   final storage = FlutterSecureStorage();
//
//
//
//   Future<void> FetchInvoice() async {
//     try {
//       final String? token = await storage.read(key: 'auth_token');
//
//       if (token != null) {
//         final response = await http.get(
//           Uri.parse(_endpointUrl),
//           headers: {
//             'Authorization': 'Bearer $token',
//           },
//         );
//
//         if (response.statusCode == 200) {
//           var jsonString = json.decode(response.body);
//           var invoiceModel = InvoiceModel().fromJson(jsonString);
//           if (invoiceModel.data != null) {
//             meetingList.value = invoiceModel.data!;
//           print('successfully loaded invoices ');
//         } else {
//           print('Failed to load invoice: ${response.statusCode}');
//         }
//       }
//     }
//     }catch (e) {
//       print('Fetch data error: $e');
//     }
//   }
// }
