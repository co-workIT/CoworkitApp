import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class PasswordController extends GetxController {
  var oldPassword = ''.obs;
  var newPassword = ''.obs;
  var confirmNewPassword = ''.obs;
  var isLoading = false.obs;

  final oldPasswordController = TextEditingController();
  final newPasswordController = TextEditingController();
  final confirmNewPasswordController = TextEditingController();

  final formKey = GlobalKey<FormState>();
  final storage = const FlutterSecureStorage();

  String? validateOldPassword(String value) {
    if (value.isEmpty) {
      return 'Old Password is required';
    }
    return null;
  }

  String? validateNewPassword(String value) {
    if (value.isEmpty) {
      return 'New Password is required';
    } else if (value.length < 6) {
      return 'Password must be at least 6 characters long';
    }
    return null;
  }

  String? validateConfirmNewPassword(String value) {
    if (value.isEmpty) {
      return 'Confirm New Password is required';
    } else if (value != newPasswordController.text) {
      return 'New Password and Confirm New Password do not match';
    }
    return null;
  }

  Future<void> resetPassword() async {
    if (formKey.currentState!.validate()) {
      isLoading.value = true;
      try {
        final url = Uri.parse('https://coworkitportal.creativeitpark.org/api/password/update');
        final String? token = await storage.read(key: 'auth_token');

        if (token == null) {
          Get.snackbar('Error', 'Authentication token is missing');
          return;
        }

        final response = await http.post(
          url,
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer $token',
          },
          body: json.encode({
            'password': oldPasswordController.text,
            'new_password': newPasswordController.text,
          }),
        );

        if (response.statusCode == 200) {
          Get.snackbar(
            'Success',
            'Password reset successful',
            icon: Icon(Icons.done, color: Colors.green),
          );
        } else {
          Get.snackbar(
            'Error',
            'Password reset failed: ${response.body}',
            icon: Icon(Icons.error, color: Colors.red),
          );
        }
      } catch (e) {
        Get.snackbar(
          'Error',
          'An error occurred: $e',
          icon: Icon(Icons.error, color: Colors.red),
        );
      } finally {
        isLoading.value = false;
      }
    }
  }
}
