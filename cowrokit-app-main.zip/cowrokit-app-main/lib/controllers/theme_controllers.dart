import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeController extends GetxController {
  Rx<ThemeMode> themeMode = ThemeMode.light.obs;
  static const String _themeKey = '_themeKey';
  RxBool isDarkMode = false.obs;

  @override
  void onInit() {
    super.onInit();
    _loadTheme();
  }

  void switchTheme() {
    if (isDarkMode.value) {
      themeMode.value = ThemeMode.light;
      Get.changeThemeMode(ThemeMode.light);
      isDarkMode.value = false;
    } else {
      themeMode.value = ThemeMode.dark;
      Get.changeThemeMode(ThemeMode.dark);
      isDarkMode.value = true;
    }
    setSystemUIOverlayStyle();
    _saveTheme();
  }

  void _loadTheme() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    isDarkMode.value = prefs.getBool(_themeKey) ?? false;
    themeMode.value = isDarkMode.value ? ThemeMode.dark : ThemeMode.light;
    Get.changeThemeMode(themeMode.value);
    setSystemUIOverlayStyle();
  }

  void _saveTheme() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool(_themeKey, isDarkMode.value);
  }

  void setSystemUIOverlayStyle() {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: isDarkMode.value
          ? Colors.black
          : const Color.fromRGBO(30, 168, 231, 1), // status bar color
      statusBarIconBrightness: isDarkMode.value
          ? Brightness.light
          : Brightness.dark, // status bar icon brightness
      systemNavigationBarColor: isDarkMode.value
          ? const Color.fromRGBO(30, 168, 231, 1) // navigation bar color
          : Colors.black,
      systemNavigationBarIconBrightness: isDarkMode.value
          ? Brightness.light
          : Brightness.dark, // navigation bar icon brightness
    ));
  }

  bool get currentTheme => isDarkMode.value;
}
