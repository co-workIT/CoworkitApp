import 'package:get/get.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'dart:async';

class ConnectivityController extends GetxController {
  var connectionStatusList = <ConnectivityResult>[].obs;
  final Connectivity _connectivity = Connectivity();
  late StreamSubscription<List<ConnectivityResult>> _connectivitySubscription;
  var wasDisconnected = false.obs;

  @override
  void onInit() {
    super.onInit();
    _initConnectivity();
    _connectivitySubscription =
        _connectivity.onConnectivityChanged.listen((List<ConnectivityResult> result) {
          _updateConnectionStatus(result);
        });
  }

  Future<void> _initConnectivity() async {
    late List<ConnectivityResult> result;
    try {
      result = await _connectivity.checkConnectivity() as List<ConnectivityResult>;
    } catch (e) {
      print('Could not check connectivity status');
      return;
    }
    _updateConnectionStatus(result);
  }

  void _updateConnectionStatus(List<ConnectivityResult> results) {
    connectionStatusList.value = results;
    // Example logic to check if there is no connection
    bool hasConnection = results.any((result) => result != ConnectivityResult.none);
    if (!hasConnection) {
      wasDisconnected.value = true;
    } else {
      if (wasDisconnected.value) {
        wasDisconnected.value = false;
        _reloadFunctions();
      }
    }
  }

  void _reloadFunctions() {
    // Add the functions you want to reload here
    print('Connection restored. Reloading functions...');
    // Example function call
    _fetchData();
  }

  Future<void> _fetchData() async {
    // Simulate a data fetch
    print('Fetching data...');
    await Future.delayed(Duration(seconds: 2));
    print('Data fetched successfully.');
  }

  @override
  void onClose() {
    _connectivitySubscription.cancel();
    super.onClose();
  }
}
