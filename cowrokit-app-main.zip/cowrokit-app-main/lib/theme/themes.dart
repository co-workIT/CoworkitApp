import 'package:flutter/material.dart';

final ThemeData lightTheme = ThemeData(
  scaffoldBackgroundColor: Color.fromRGBO(246, 248, 248, 1),
  primaryColor: const Color(0xFF0D47A1),
  secondaryHeaderColor: Colors.black,
  hintColor: const Color(0xFFFFC107),
  cardColor: Colors.white,
  shadowColor: Colors.white30,
  floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: Color.fromRGBO(30, 168, 231, 1),
      foregroundColor: Colors.white,
      focusColor:  Color.fromRGBO(30, 168, 231, 1).withOpacity(0.8)
  ),
  textTheme: const TextTheme(
    bodyLarge: TextStyle(color: Colors.black),
    bodySmall: TextStyle(color: Colors.white),
    bodyMedium: TextStyle(color: Colors.black),
    displayLarge: TextStyle(color: Colors.black),
    displaySmall: TextStyle(color: Colors.white),
    displayMedium: TextStyle(color: Colors.black),
    titleLarge: TextStyle(color: Colors.black),
    titleSmall: TextStyle(color: Colors.white),
    titleMedium: TextStyle(color: Colors.black),
    labelLarge: TextStyle(color: Colors.black),
    labelSmall: TextStyle(color: Colors.white),
    labelMedium: TextStyle(color: Colors.black),
  ),
  datePickerTheme: DatePickerThemeData(
    backgroundColor: Colors.white,
    rangePickerBackgroundColor: Colors.white.withOpacity(0.2),
    inputDecorationTheme: const InputDecorationTheme(
      labelStyle: TextStyle(color: Colors.red),
    ),
    cancelButtonStyle: ButtonStyle(
      textStyle: WidgetStateProperty.resolveWith<TextStyle?>(
        (Set<WidgetState> states) {
          if (states.contains(WidgetState.pressed)) {
            return const TextStyle(color: Colors.red);
          }
          return const TextStyle(color: Colors.black);
        },
      ),
    ),
    confirmButtonStyle: ButtonStyle(
      textStyle: WidgetStateProperty.resolveWith<TextStyle?>(
        (Set<WidgetState> states) {
          if (states.contains(WidgetState.pressed)) {
            return const TextStyle(color: Colors.green);
          }
          return const TextStyle(color: Colors.black);
        },
      ),
    ),
  ),

  // DatePickerThemeData(
  //     backgroundColor: Colors.white,
  //     rangePickerBackgroundColor: Colors.white.withOpacity(0.2),
  //     inputDecorationTheme:
  //         const InputDecorationTheme(labelStyle: TextStyle(color: Colors.red)),
  //     cancelButtonStyle: const ButtonStyle(
  //         textStyle: WidgetStatePropertyAll(TextStyle(color: Colors.black)))),
  iconTheme: const IconThemeData(color: Colors.white),
  // colorSchemeSeed: Colors.white,
  colorScheme: const ColorScheme.light(
    surface: Color(0xFFF5F5F5),
    primary: Colors.black26,
    secondary: Colors.black,
    onPrimary: Colors.black,
    onSecondary: Colors.red,
    onError: Colors.red,
    onSurface: Colors.lightBlue,
    error: Colors.red,
  ),
);

final ThemeData darkTheme = ThemeData(
  primaryColor: const Color(0xFF0D47A1),
  secondaryHeaderColor: const Color(0xFF1976D2),
  hintColor: const Color(0xFFFFC107),
  textTheme: const TextTheme(
    bodyLarge: TextStyle(color: Colors.white),
    bodySmall: TextStyle(color: Colors.white),
    bodyMedium: TextStyle(color: Colors.white),
    displayLarge: TextStyle(color: Colors.white),
    displaySmall: TextStyle(color: Colors.white),
    displayMedium: TextStyle(color: Colors.white),
    titleLarge: TextStyle(color: Colors.white),
    titleSmall: TextStyle(color: Colors.white),
    titleMedium: TextStyle(color: Colors.white),
    labelLarge: TextStyle(color: Colors.white),
    labelSmall: TextStyle(color: Colors.white),
    labelMedium: TextStyle(color: Colors.white),
  ),
  // colorSchemeSeed: Colors.black,
  iconTheme: const IconThemeData(color: Colors.white),
  cardColor: const Color.fromRGBO(50, 50, 50, 1),
  colorScheme: const ColorScheme.dark(
    surface: Color(0xFFF5F5F5),
    primary: Colors.white,
    secondary: Colors.black,
    onPrimary: Colors.white,
    onSecondary: Colors.white,
    onError: Colors.red,
    onSurface: Colors.lightBlue,
    error: Colors.red,
  ),
);
