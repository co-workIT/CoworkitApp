import 'package:intl/intl.dart';

class MeetingModel {
  bool? isSuccess;
  String? message;
  List<Data>? data;

  MeetingModel({this.isSuccess, this.message, this.data});

  MeetingModel.fromJson(Map<String, dynamic> json) {
    isSuccess = json['is_success'];
    message = json['message'];
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['is_success'] = this.isSuccess;
    data['message'] = this.message;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  int? id;
  String? name;
  String? capacity;
  String? price;
  String? description;
  String? typeId;
  String? meeting;
  String? window;
  String? ownedBy;
  String? createdBy;
  String? createdAt;
  String? updatedAt;

  Data(
      {this.id,
        this.name,
        this.capacity,
        this.price,
        this.description,
        this.typeId,
        this.meeting,
        this.window,
        this.ownedBy,
        this.createdBy,
        this.createdAt,
        this.updatedAt});
  String ConvertDate(String date, bool isDate){

    DateTime dt = DateTime.parse(date.toString()).toLocal();
    if(isDate){
    String dateStr = DateFormat('yyyy-MM-dd').format(dt);
    return dateStr;
    }
    else{
    String timeStr = DateFormat('HH:mm').format(dt);
    return timeStr;
  }
  }

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    capacity = json['capacity'];
    price = json['price'];
    description = json['description'];
    typeId = json['type_id'];
    meeting = json['meeting'];
    window = json['window'];
    ownedBy = json['owned_by'];
    createdBy = json['created_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['capacity'] = this.capacity;
    data['price'] = this.price;
    data['description'] = this.description;
    data['type_id'] = this.typeId;
    data['meeting'] = this.meeting;
    data['window'] = this.window;
    data['owned_by'] = this.ownedBy;
    data['created_by'] = this.createdBy;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
