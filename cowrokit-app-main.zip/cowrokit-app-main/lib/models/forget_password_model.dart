class PasswordModel {
  String oldPassword;
  String newPassword;
  String confirmNewPassword;

  PasswordModel({
    required this.oldPassword,
    required this.newPassword,
    required this.confirmNewPassword,
  });
}
