class Settings {
  final String siteCurrency;
  final String siteCurrencySymbol;
  final String companyName;
  final String companyEmail;

  Settings({
    required this.siteCurrency,
    required this.siteCurrencySymbol,
    required this.companyName,
    required this.companyEmail,
  });

  factory Settings.fromJson(Map<String, dynamic> json) {
    return Settings(
      siteCurrency: json['site_currency'],
      siteCurrencySymbol: json['site_currency_symbol'],
      companyName: json['company_name'],
      companyEmail: json['company_email'],
    );
  }
}
