class MailingModel {
  List<Data>? data;

  MailingModel({this.data});

  MailingModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  int? id;
  String? companyId;
  String? userId;
  String? name;
  String? date;
  String? price;
  String? ownedBy;
  String? createdBy;
  String? createdAt;
  String? updatedAt;

  Data({
    this.id,
    this.companyId,
    this.userId,
    this.name,
    this.date,
    this.price,
    this.ownedBy,
    this.createdBy,
    this.createdAt,
    this.updatedAt,
  });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    companyId = json['company_id'];
    userId = json['user_id'];
    name = json['name'];
    date = json['date'];
    price = json['price'];
    ownedBy = json['owned_by'];
    createdBy = json['created_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['company_id'] = this.companyId;
    data['user_id'] = this.userId;
    data['name'] = this.name;
    data['date'] = this.date;
    data['price'] = this.price;
    data['owned_by'] = this.ownedBy;
    data['created_by'] = this.createdBy;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
