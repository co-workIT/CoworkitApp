class Apiresponse {
  List<Lawyers>? lawyers;

  Apiresponse({this.lawyers});

  Apiresponse.fromJson(Map<String, dynamic> json) {
    if (json['lawyers'] != null) {
      lawyers = <Lawyers>[];
      json['lawyers'].forEach((v) {
        lawyers!.add(new Lawyers.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.lawyers != null) {
      data['lawyers'] = this.lawyers!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Lawyers {
  int? id;
  String? userId;
  String? firstName;
  String? lastName;
  String? phone;
  String? email;
  String? enrollementNum;
  String? gender;
  String? about;
  String? courts;
  String? specialization;
  String? extraServices;
  String? address;
  String? experience;
  String? caseWon;
  String? caseFail;
  String? fee;
  String? profilePicture;
  String? createdAt;
  String? updatedAt;

  Lawyers(
      {this.id,
        this.userId,
        this.firstName,
        this.lastName,
        this.phone,
        this.email,
        this.enrollementNum,
        this.gender,
        this.about,
        this.courts,
        this.specialization,
        this.extraServices,
        this.address,
        this.experience,
        this.caseWon,
        this.caseFail,
        this.fee,
        this.profilePicture,
        this.createdAt,
        this.updatedAt});

  Lawyers.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    firstName = json['FirstName'];
    lastName = json['LastName'];
    phone = json['phone'];
    email = json['email'];
    enrollementNum = json['Enrollement_num'];
    gender = json['Gender'];
    about = json['About'];
    courts = json['Courts'];
    specialization = json['Specialization'];
    extraServices = json['ExtraServices'];
    address = json['Address'];
    experience = json['Experience'];
    caseWon = json['Case_won'];
    caseFail = json['Case_Fail'];
    fee = json['Fee'];
    profilePicture = json['Profile_Picture'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['FirstName'] = this.firstName;
    data['LastName'] = this.lastName;
    data['phone'] = this.phone;
    data['email'] = this.email;
    data['Enrollement_num'] = this.enrollementNum;
    data['Gender'] = this.gender;
    data['About'] = this.about;
    data['Courts'] = this.courts;
    data['Specialization'] = this.specialization;
    data['ExtraServices'] = this.extraServices;
    data['Address'] = this.address;
    data['Experience'] = this.experience;
    data['Case_won'] = this.caseWon;
    data['Case_Fail'] = this.caseFail;
    data['Fee'] = this.fee;
    data['Profile_Picture'] = this.profilePicture;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}