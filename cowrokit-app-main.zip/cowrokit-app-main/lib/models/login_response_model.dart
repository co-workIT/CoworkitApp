

import 'package:co_workit/models/settings.dart';
import 'package:co_workit/models/user.dart';

class LoginResponse {
  final bool isSuccess;
  final String message;
  final String token;
  final User user;
  final Settings settings;

  LoginResponse({
    required this.isSuccess,
    required this.message,
    required this.token,
    required this.user,
    required this.settings,
  });

  factory LoginResponse.fromJson(Map<String, dynamic> json) {
    return LoginResponse(
      isSuccess: json['is_success'],
      message: json['message'],
      token: json['data']['token'],
      user: User.fromJson(json['data']['user']),
      settings: Settings.fromJson(json['data']['settings']),
    );
  }
}
