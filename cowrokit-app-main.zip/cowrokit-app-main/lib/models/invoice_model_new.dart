class InvoiceModel {
  List<Data>? data;

  InvoiceModel({this.data});

  InvoiceModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  int? id;
  String? customerId;
  String? name;
  String? email;
  String? taxNumber;
  String? contact;
  String? avatar;
  String? ntn;
  String? companyId;
  String? ownedBy;
  String? createdBy;
  String? isActive;
  String? emailVerifiedAt;
  String? billingName;
  String? billingCountry;
  String? billingState;
  String? billingCity;
  String? billingPhone;
  String? billingZip;
  String? billingAddress;
  String? shippingName;
  String? shippingCountry;
  String? shippingState;
  String? shippingCity;
  String? shippingPhone;
  String? shippingZip;
  String? shippingAddress;
  String? lang;
  String? balance;
  String? createdAt;
  String? updatedAt;
  List<Invoices>? invoices;

  Data({
    this.id,
    this.customerId,
    this.name,
    this.email,
    this.taxNumber,
    this.contact,
    this.avatar,
    this.ntn,
    this.companyId,
    this.ownedBy,
    this.createdBy,
    this.isActive,
    this.emailVerifiedAt,
    this.billingName,
    this.billingCountry,
    this.billingState,
    this.billingCity,
    this.billingPhone,
    this.billingZip,
    this.billingAddress,
    this.shippingName,
    this.shippingCountry,
    this.shippingState,
    this.shippingCity,
    this.shippingPhone,
    this.shippingZip,
    this.shippingAddress,
    this.lang,
    this.balance,
    this.createdAt,
    this.updatedAt,
    this.invoices,
  });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    customerId = json['customer_id'];
    name = json['name'];
    email = json['email'];
    taxNumber = json['tax_number'];
    contact = json['contact'];
    avatar = json['avatar'];
    ntn = json['ntn'];
    companyId = json['company_id'];
    ownedBy = json['owned_by'];
    createdBy = json['created_by'];
    isActive = json['is_active'];
    emailVerifiedAt = json['email_verified_at'];
    billingName = json['billing_name'];
    billingCountry = json['billing_country'];
    billingState = json['billing_state'];
    billingCity = json['billing_city'];
    billingPhone = json['billing_phone'];
    billingZip = json['billing_zip'];
    billingAddress = json['billing_address'];
    shippingName = json['shipping_name'];
    shippingCountry = json['shipping_country'];
    shippingState = json['shipping_state'];
    shippingCity = json['shipping_city'];
    shippingPhone = json['shipping_phone'];
    shippingZip = json['shipping_zip'];
    shippingAddress = json['shipping_address'];
    lang = json['lang'];
    balance = json['balance'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    if (json['invoices'] != null) {
      invoices = <Invoices>[];
      json['invoices'].forEach((v) {
        invoices!.add(Invoices.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data['id'] = id;
    data['customer_id'] = customerId;
    data['name'] = name;
    data['email'] = email;
    data['tax_number'] = taxNumber;
    data['contact'] = contact;
    data['avatar'] = avatar;
    data['ntn'] = ntn;
    data['company_id'] = companyId;
    data['owned_by'] = ownedBy;
    data['created_by'] = createdBy;
    data['is_active'] = isActive;
    data['email_verified_at'] = emailVerifiedAt;
    data['billing_name'] = billingName;
    data['billing_country'] = billingCountry;
    data['billing_state'] = billingState;
    data['billing_city'] = billingCity;
    data['billing_phone'] = billingPhone;
    data['billing_zip'] = billingZip;
    data['billing_address'] = billingAddress;
    data['shipping_name'] = shippingName;
    data['shipping_country'] = shippingCountry;
    data['shipping_state'] = shippingState;
    data['shipping_city'] = shippingCity;
    data['shipping_phone'] = shippingPhone;
    data['shipping_zip'] = shippingZip;
    data['shipping_address'] = shippingAddress;
    data['lang'] = lang;
    data['balance'] = balance;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    if (invoices != null) {
      data['invoices'] = invoices!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Invoices {
  int? id;
  String? invoiceId;
  String? customerId;
  String? issueDate;
  String? dueDate;
  String? sendDate;
  String? categoryId;
  String? refNumber;
  String? status;
  String? shippingDisplay;
  String? discountApply;
  String? contractId;
  String? ownedBy;
  String? createdBy;
  String? createdAt;
  String? updatedAt;

  Invoices({
    this.id,
    this.invoiceId,
    this.customerId,
    this.issueDate,
    this.dueDate,
    this.sendDate,
    this.categoryId,
    this.refNumber,
    this.status,
    this.shippingDisplay,
    this.discountApply,
    this.contractId,
    this.ownedBy,
    this.createdBy,
    this.createdAt,
    this.updatedAt,
  });

  Invoices.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    invoiceId = json['invoice_id'];
    customerId = json['customer_id'];
    issueDate = json['issue_date'];
    dueDate = json['due_date'];
    sendDate = json['send_date'];
    categoryId = json['category_id'];
    refNumber = json['ref_number'];
    status = json['status'];
    shippingDisplay = json['shipping_display'];
    discountApply = json['discount_apply'];
    contractId = json['contract_id'];
    ownedBy = json['owned_by'];
    createdBy = json['created_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data['id'] = id;
    data['invoice_id'] = invoiceId;
    data['customer_id'] = customerId;
    data['issue_date'] = issueDate;
    data['due_date'] = dueDate;
    data['send_date'] = sendDate;
    data['category_id'] = categoryId;
    data['ref_number'] = refNumber;
    data['status'] = status;
    data['shipping_display'] = shippingDisplay;
    data['discount_apply'] = discountApply;
    data['contract_id'] = contractId;
    data['owned_by'] = ownedBy;
    data['created_by'] = createdBy;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    return data;
  }
}
