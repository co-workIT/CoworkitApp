class LoginModel {
  bool? isSuccess;
  String? message;
  Data? data;

  LoginModel({this.isSuccess, this.message, this.data});

  LoginModel.fromJson(Map<String, dynamic> json) {
    isSuccess = json['is_success'];
    message = json['message'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['is_success'] = this.isSuccess;
    data['message'] = this.message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  String? token;
  int? userId;
  User? user;
  Settings? settings;

  Data({this.token, this.userId, this.user, this.settings});

  Data.fromJson(Map<String, dynamic> json) {
    token = json['token'];
    userId = json['user_id'];
    user = json['user'] != null ? new User.fromJson(json['user']) : null;
    settings = json['settings'] != null
        ? new Settings.fromJson(json['settings'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['token'] = this.token;
    data['user_id'] = this.userId;
    if (this.user != null) {
      data['user'] = this.user!.toJson();
    }
    if (this.settings != null) {
      data['settings'] = this.settings!.toJson();
    }
    return data;
  }
}

class User {
  int? id;
  String? name;
  String? email;
  String? emailVerifiedAt;
  String? plan;
  Null planExpireDate;
  String? requestedPlan;
  String? type;
  String? storageLimit;
  String? avatar;
  String? messengerColor;
  String? lang;
  String? defaultPipeline;
  String? activeStatus;
  String? deleteStatus;
  String? mode;
  String? darkMode;
  String? isActive;
  String? lastLoginAt;
  String? ownedBy;
  String? createdBy;
  String? createdAt;
  String? updatedAt;
  String? isEmailVerified;
  String? companyId;
  String? companyAdmin;
  String? profile;

  User(
      {this.id,
        this.name,
        this.email,
        this.emailVerifiedAt,
        this.plan,
        this.planExpireDate,
        this.requestedPlan,
        this.type,
        this.storageLimit,
        this.avatar,
        this.messengerColor,
        this.lang,
        this.defaultPipeline,
        this.activeStatus,
        this.deleteStatus,
        this.mode,
        this.darkMode,
        this.isActive,
        this.lastLoginAt,
        this.ownedBy,
        this.createdBy,
        this.createdAt,
        this.updatedAt,
        this.isEmailVerified,
        this.companyId,
        this.companyAdmin,
        this.profile});

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    emailVerifiedAt = json['email_verified_at'];
    plan = json['plan'];
    planExpireDate = json['plan_expire_date'];
    requestedPlan = json['requested_plan'];
    type = json['type'];
    storageLimit = json['storage_limit'];
    avatar = json['avatar'];
    messengerColor = json['messenger_color'];
    lang = json['lang'];
    defaultPipeline = json['default_pipeline'];
    activeStatus = json['active_status'];
    deleteStatus = json['delete_status'];
    mode = json['mode'];
    darkMode = json['dark_mode'];
    isActive = json['is_active'];
    lastLoginAt = json['last_login_at'];
    ownedBy = json['owned_by'];
    createdBy = json['created_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    isEmailVerified = json['is_email_verified'];
    companyId = json['company_id'];
    companyAdmin = json['company_admin'];
    profile = json['profile'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['email'] = this.email;
    data['email_verified_at'] = this.emailVerifiedAt;
    data['plan'] = this.plan;
    data['plan_expire_date'] = this.planExpireDate;
    data['requested_plan'] = this.requestedPlan;
    data['type'] = this.type;
    data['storage_limit'] = this.storageLimit;
    data['avatar'] = this.avatar;
    data['messenger_color'] = this.messengerColor;
    data['lang'] = this.lang;
    data['default_pipeline'] = this.defaultPipeline;
    data['active_status'] = this.activeStatus;
    data['delete_status'] = this.deleteStatus;
    data['mode'] = this.mode;
    data['dark_mode'] = this.darkMode;
    data['is_active'] = this.isActive;
    data['last_login_at'] = this.lastLoginAt;
    data['owned_by'] = this.ownedBy;
    data['created_by'] = this.createdBy;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['is_email_verified'] = this.isEmailVerified;
    data['company_id'] = this.companyId;
    data['company_admin'] = this.companyAdmin;
    data['profile'] = this.profile;
    return data;
  }
}

class Settings {
  String? siteCurrency;
  String? siteCurrencySymbol;
  String? siteCurrencySymbolPosition;
  String? siteDateFormat;
  String? siteTimeFormat;
  String? companyName;
  Null companyAddress;
  Null companyCity;
  Null companyState;
  Null companyZipcode;
  Null companyCountry;
  Null companyTelephone;
  String? companyEmail;
  String? companyEmailFromName;
  String? invoicePrefix;
  String? journalPrefix;
  String? invoiceColor;
  String? proposalPrefix;
  String? proposalColor;
  String? billPrefix;
  String? expensePrefix;
  String? billColor;
  String? customerPrefix;
  String? venderPrefix;
  Null footerTitle;
  String? footerNotes;
  String? invoiceTemplate;
  String? billTemplate;
  String? proposalTemplate;
  Null registrationNumber;
  Null vatNumber;
  String? defaultLanguage;
  String? enableStripe;
  String? enablePaypal;
  String? paypalMode;
  String? paypalClientId;
  String? paypalSecretKey;
  String? stripeKey;
  String? stripeSecret;
  String? decimalNumber;
  String? taxType;
  String? shippingDisplay;
  String? displayLandingPage;
  String? employeePrefix;
  String? leaveStatus;
  String? bugPrefix;
  Null titleText;
  Null footerText;
  String? companyStartTime;
  String? companyEndTime;
  String? gdprCookie;
  String? intervalTime;
  String? zoomApikey;
  String? zoomApisecret;
  String? slackWebhook;
  String? telegramAccestoken;
  String? telegramChatid;
  String? enableSignup;
  String? emailVerification;
  String? cookieText;
  String? companyLogoLight;
  String? companyLogoDark;
  String? companyFavicon;
  String? custThemeBg;
  String? custDarklayout;
  String? color;
  String? sITERTL;
  String? purchasePrefix;
  String? purchaseColor;
  String? purchaseTemplate;
  String? posColor;
  String? posTemplate;
  String? posPrefix;
  String? storageSetting;
  String? localStorageValidation;
  String? localStorageMaxUploadSize;
  String? s3Key;
  String? s3Secret;
  String? s3Region;
  String? s3Bucket;
  String? s3Url;
  String? s3Endpoint;
  String? s3MaxUploadSize;
  String? s3StorageValidation;
  String? wasabiKey;
  String? wasabiSecret;
  String? wasabiRegion;
  String? wasabiBucket;
  String? wasabiUrl;
  String? wasabiRoot;
  String? wasabiMaxUploadSize;
  String? wasabiStorageValidation;
  String? purchaseLogo;
  String? proposalLogo;
  String? invoiceLogo;
  String? billLogo;
  String? posLogo;
  String? contractPrefix;
  String? barcodeType;
  String? barcodeFormat;
  String? newUser;
  String? newClient;
  String? newSupportTicket;
  String? leadAssigned;
  String? dealAssigned;
  String? newAward;
  String? customerInvoiceSent;
  String? newInvoicePayment;
  String? newPaymentReminder;
  String? newBillPayment;
  String? billResent;
  String? proposalSent;
  String? complaintResent;
  String? leaveActionSent;
  String? payslipSent;
  String? promotionSent;
  String? resignationSent;
  String? terminationSent;
  String? transferSent;
  String? tripSent;
  String? venderBillSent;
  String? warningSent;
  String? newContract;
  String? vatGstNumberSwitch;
  String? googleCalendarEnable;
  String? googleCalenderJsonFile;
  String? metaTitle;
  String? metaDesc;
  String? metaImage;
  String? enableCookie;
  String? necessaryCookies;
  String? cookieLogging;
  String? cookieTitle;
  String? cookieDescription;
  String? strictlyCookieTitle;
  String? strictlyCookieDescription;
  String? moreInformationDescription;
  String? contactusUrl;
  String? twilioSid;
  String? twilioToken;
  String? twilioFrom;
  String? chatGptKey;
  String? ipRestrict;
  String? mailDriver;
  String? mailHost;
  String? mailPort;
  String? mailUsername;
  String? mailPassword;
  String? mailEncryption;
  String? mailFromAddress;
  String? mailFromName;
  String? appsUrl;

  Settings(
      {this.siteCurrency,
        this.siteCurrencySymbol,
        this.siteCurrencySymbolPosition,
        this.siteDateFormat,
        this.siteTimeFormat,
        this.companyName,
        this.companyAddress,
        this.companyCity,
        this.companyState,
        this.companyZipcode,
        this.companyCountry,
        this.companyTelephone,
        this.companyEmail,
        this.companyEmailFromName,
        this.invoicePrefix,
        this.journalPrefix,
        this.invoiceColor,
        this.proposalPrefix,
        this.proposalColor,
        this.billPrefix,
        this.expensePrefix,
        this.billColor,
        this.customerPrefix,
        this.venderPrefix,
        this.footerTitle,
        this.footerNotes,
        this.invoiceTemplate,
        this.billTemplate,
        this.proposalTemplate,
        this.registrationNumber,
        this.vatNumber,
        this.defaultLanguage,
        this.enableStripe,
        this.enablePaypal,
        this.paypalMode,
        this.paypalClientId,
        this.paypalSecretKey,
        this.stripeKey,
        this.stripeSecret,
        this.decimalNumber,
        this.taxType,
        this.shippingDisplay,
        this.displayLandingPage,
        this.employeePrefix,
        this.leaveStatus,
        this.bugPrefix,
        this.titleText,
        this.footerText,
        this.companyStartTime,
        this.companyEndTime,
        this.gdprCookie,
        this.intervalTime,
        this.zoomApikey,
        this.zoomApisecret,
        this.slackWebhook,
        this.telegramAccestoken,
        this.telegramChatid,
        this.enableSignup,
        this.emailVerification,
        this.cookieText,
        this.companyLogoLight,
        this.companyLogoDark,
        this.companyFavicon,
        this.custThemeBg,
        this.custDarklayout,
        this.color,
        this.sITERTL,
        this.purchasePrefix,
        this.purchaseColor,
        this.purchaseTemplate,
        this.posColor,
        this.posTemplate,
        this.posPrefix,
        this.storageSetting,
        this.localStorageValidation,
        this.localStorageMaxUploadSize,
        this.s3Key,
        this.s3Secret,
        this.s3Region,
        this.s3Bucket,
        this.s3Url,
        this.s3Endpoint,
        this.s3MaxUploadSize,
        this.s3StorageValidation,
        this.wasabiKey,
        this.wasabiSecret,
        this.wasabiRegion,
        this.wasabiBucket,
        this.wasabiUrl,
        this.wasabiRoot,
        this.wasabiMaxUploadSize,
        this.wasabiStorageValidation,
        this.purchaseLogo,
        this.proposalLogo,
        this.invoiceLogo,
        this.billLogo,
        this.posLogo,
        this.contractPrefix,
        this.barcodeType,
        this.barcodeFormat,
        this.newUser,
        this.newClient,
        this.newSupportTicket,
        this.leadAssigned,
        this.dealAssigned,
        this.newAward,
        this.customerInvoiceSent,
        this.newInvoicePayment,
        this.newPaymentReminder,
        this.newBillPayment,
        this.billResent,
        this.proposalSent,
        this.complaintResent,
        this.leaveActionSent,
        this.payslipSent,
        this.promotionSent,
        this.resignationSent,
        this.terminationSent,
        this.transferSent,
        this.tripSent,
        this.venderBillSent,
        this.warningSent,
        this.newContract,
        this.vatGstNumberSwitch,
        this.googleCalendarEnable,
        this.googleCalenderJsonFile,
        this.metaTitle,
        this.metaDesc,
        this.metaImage,
        this.enableCookie,
        this.necessaryCookies,
        this.cookieLogging,
        this.cookieTitle,
        this.cookieDescription,
        this.strictlyCookieTitle,
        this.strictlyCookieDescription,
        this.moreInformationDescription,
        this.contactusUrl,
        this.twilioSid,
        this.twilioToken,
        this.twilioFrom,
        this.chatGptKey,
        this.ipRestrict,
        this.mailDriver,
        this.mailHost,
        this.mailPort,
        this.mailUsername,
        this.mailPassword,
        this.mailEncryption,
        this.mailFromAddress,
        this.mailFromName,
        this.appsUrl});

  Settings.fromJson(Map<String, dynamic> json) {
    siteCurrency = json['site_currency'];
    siteCurrencySymbol = json['site_currency_symbol'];
    siteCurrencySymbolPosition = json['site_currency_symbol_position'];
    siteDateFormat = json['site_date_format'];
    siteTimeFormat = json['site_time_format'];
    companyName = json['company_name'];
    companyAddress = json['company_address'];
    companyCity = json['company_city'];
    companyState = json['company_state'];
    companyZipcode = json['company_zipcode'];
    companyCountry = json['company_country'];
    companyTelephone = json['company_telephone'];
    companyEmail = json['company_email'];
    companyEmailFromName = json['company_email_from_name'];
    invoicePrefix = json['invoice_prefix'];
    journalPrefix = json['journal_prefix'];
    invoiceColor = json['invoice_color'];
    proposalPrefix = json['proposal_prefix'];
    proposalColor = json['proposal_color'];
    billPrefix = json['bill_prefix'];
    expensePrefix = json['expense_prefix'];
    billColor = json['bill_color'];
    customerPrefix = json['customer_prefix'];
    venderPrefix = json['vender_prefix'];
    footerTitle = json['footer_title'];
    footerNotes = json['footer_notes'];
    invoiceTemplate = json['invoice_template'];
    billTemplate = json['bill_template'];
    proposalTemplate = json['proposal_template'];
    registrationNumber = json['registration_number'];
    vatNumber = json['vat_number'];
    defaultLanguage = json['default_language'];
    enableStripe = json['enable_stripe'];
    enablePaypal = json['enable_paypal'];
    paypalMode = json['paypal_mode'];
    paypalClientId = json['paypal_client_id'];
    paypalSecretKey = json['paypal_secret_key'];
    stripeKey = json['stripe_key'];
    stripeSecret = json['stripe_secret'];
    decimalNumber = json['decimal_number'];
    taxType = json['tax_type'];
    shippingDisplay = json['shipping_display'];
    displayLandingPage = json['display_landing_page'];
    employeePrefix = json['employee_prefix'];
    leaveStatus = json['leave_status'];
    bugPrefix = json['bug_prefix'];
    titleText = json['title_text'];
    footerText = json['footer_text'];
    companyStartTime = json['company_start_time'];
    companyEndTime = json['company_end_time'];
    gdprCookie = json['gdpr_cookie'];
    intervalTime = json['interval_time'];
    zoomApikey = json['zoom_apikey'];
    zoomApisecret = json['zoom_apisecret'];
    slackWebhook = json['slack_webhook'];
    telegramAccestoken = json['telegram_accestoken'];
    telegramChatid = json['telegram_chatid'];
    enableSignup = json['enable_signup'];
    emailVerification = json['email_verification'];
    cookieText = json['cookie_text'];
    companyLogoLight = json['company_logo_light'];
    companyLogoDark = json['company_logo_dark'];
    companyFavicon = json['company_favicon'];
    custThemeBg = json['cust_theme_bg'];
    custDarklayout = json['cust_darklayout'];
    color = json['color'];
    sITERTL = json['SITE_RTL'];
    purchasePrefix = json['purchase_prefix'];
    purchaseColor = json['purchase_color'];
    purchaseTemplate = json['purchase_template'];
    posColor = json['pos_color'];
    posTemplate = json['pos_template'];
    posPrefix = json['pos_prefix'];
    storageSetting = json['storage_setting'];
    localStorageValidation = json['local_storage_validation'];
    localStorageMaxUploadSize = json['local_storage_max_upload_size'];
    s3Key = json['s3_key'];
    s3Secret = json['s3_secret'];
    s3Region = json['s3_region'];
    s3Bucket = json['s3_bucket'];
    s3Url = json['s3_url'];
    s3Endpoint = json['s3_endpoint'];
    s3MaxUploadSize = json['s3_max_upload_size'];
    s3StorageValidation = json['s3_storage_validation'];
    wasabiKey = json['wasabi_key'];
    wasabiSecret = json['wasabi_secret'];
    wasabiRegion = json['wasabi_region'];
    wasabiBucket = json['wasabi_bucket'];
    wasabiUrl = json['wasabi_url'];
    wasabiRoot = json['wasabi_root'];
    wasabiMaxUploadSize = json['wasabi_max_upload_size'];
    wasabiStorageValidation = json['wasabi_storage_validation'];
    purchaseLogo = json['purchase_logo'];
    proposalLogo = json['proposal_logo'];
    invoiceLogo = json['invoice_logo'];
    billLogo = json['bill_logo'];
    posLogo = json['pos_logo'];
    contractPrefix = json['contract_prefix'];
    barcodeType = json['barcode_type'];
    barcodeFormat = json['barcode_format'];
    newUser = json['new_user'];
    newClient = json['new_client'];
    newSupportTicket = json['new_support_ticket'];
    leadAssigned = json['lead_assigned'];
    dealAssigned = json['deal_assigned'];
    newAward = json['new_award'];
    customerInvoiceSent = json['customer_invoice_sent'];
    newInvoicePayment = json['new_invoice_payment'];
    newPaymentReminder = json['new_payment_reminder'];
    newBillPayment = json['new_bill_payment'];
    billResent = json['bill_resent'];
    proposalSent = json['proposal_sent'];
    complaintResent = json['complaint_resent'];
    leaveActionSent = json['leave_action_sent'];
    payslipSent = json['payslip_sent'];
    promotionSent = json['promotion_sent'];
    resignationSent = json['resignation_sent'];
    terminationSent = json['termination_sent'];
    transferSent = json['transfer_sent'];
    tripSent = json['trip_sent'];
    venderBillSent = json['vender_bill_sent'];
    warningSent = json['warning_sent'];
    newContract = json['new_contract'];
    vatGstNumberSwitch = json['vat_gst_number_switch'];
    googleCalendarEnable = json['google_calendar_enable'];
    googleCalenderJsonFile = json['google_calender_json_file'];
    metaTitle = json['meta_title'];
    metaDesc = json['meta_desc'];
    metaImage = json['meta_image'];
    enableCookie = json['enable_cookie'];
    necessaryCookies = json['necessary_cookies'];
    cookieLogging = json['cookie_logging'];
    cookieTitle = json['cookie_title'];
    cookieDescription = json['cookie_description'];
    strictlyCookieTitle = json['strictly_cookie_title'];
    strictlyCookieDescription = json['strictly_cookie_description'];
    moreInformationDescription = json['more_information_description'];
    contactusUrl = json['contactus_url'];
    twilioSid = json['twilio_sid'];
    twilioToken = json['twilio_token'];
    twilioFrom = json['twilio_from'];
    chatGptKey = json['chat_gpt_key'];
    ipRestrict = json['ip_restrict'];
    mailDriver = json['mail_driver'];
    mailHost = json['mail_host'];
    mailPort = json['mail_port'];
    mailUsername = json['mail_username'];
    mailPassword = json['mail_password'];
    mailEncryption = json['mail_encryption'];
    mailFromAddress = json['mail_from_address'];
    mailFromName = json['mail_from_name'];
    appsUrl = json['apps_url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['site_currency'] = this.siteCurrency;
    data['site_currency_symbol'] = this.siteCurrencySymbol;
    data['site_currency_symbol_position'] = this.siteCurrencySymbolPosition;
    data['site_date_format'] = this.siteDateFormat;
    data['site_time_format'] = this.siteTimeFormat;
    data['company_name'] = this.companyName;
    data['company_address'] = this.companyAddress;
    data['company_city'] = this.companyCity;
    data['company_state'] = this.companyState;
    data['company_zipcode'] = this.companyZipcode;
    data['company_country'] = this.companyCountry;
    data['company_telephone'] = this.companyTelephone;
    data['company_email'] = this.companyEmail;
    data['company_email_from_name'] = this.companyEmailFromName;
    data['invoice_prefix'] = this.invoicePrefix;
    data['journal_prefix'] = this.journalPrefix;
    data['invoice_color'] = this.invoiceColor;
    data['proposal_prefix'] = this.proposalPrefix;
    data['proposal_color'] = this.proposalColor;
    data['bill_prefix'] = this.billPrefix;
    data['expense_prefix'] = this.expensePrefix;
    data['bill_color'] = this.billColor;
    data['customer_prefix'] = this.customerPrefix;
    data['vender_prefix'] = this.venderPrefix;
    data['footer_title'] = this.footerTitle;
    data['footer_notes'] = this.footerNotes;
    data['invoice_template'] = this.invoiceTemplate;
    data['bill_template'] = this.billTemplate;
    data['proposal_template'] = this.proposalTemplate;
    data['registration_number'] = this.registrationNumber;
    data['vat_number'] = this.vatNumber;
    data['default_language'] = this.defaultLanguage;
    data['enable_stripe'] = this.enableStripe;
    data['enable_paypal'] = this.enablePaypal;
    data['paypal_mode'] = this.paypalMode;
    data['paypal_client_id'] = this.paypalClientId;
    data['paypal_secret_key'] = this.paypalSecretKey;
    data['stripe_key'] = this.stripeKey;
    data['stripe_secret'] = this.stripeSecret;
    data['decimal_number'] = this.decimalNumber;
    data['tax_type'] = this.taxType;
    data['shipping_display'] = this.shippingDisplay;
    data['display_landing_page'] = this.displayLandingPage;
    data['employee_prefix'] = this.employeePrefix;
    data['leave_status'] = this.leaveStatus;
    data['bug_prefix'] = this.bugPrefix;
    data['title_text'] = this.titleText;
    data['footer_text'] = this.footerText;
    data['company_start_time'] = this.companyStartTime;
    data['company_end_time'] = this.companyEndTime;
    data['gdpr_cookie'] = this.gdprCookie;
    data['interval_time'] = this.intervalTime;
    data['zoom_apikey'] = this.zoomApikey;
    data['zoom_apisecret'] = this.zoomApisecret;
    data['slack_webhook'] = this.slackWebhook;
    data['telegram_accestoken'] = this.telegramAccestoken;
    data['telegram_chatid'] = this.telegramChatid;
    data['enable_signup'] = this.enableSignup;
    data['email_verification'] = this.emailVerification;
    data['cookie_text'] = this.cookieText;
    data['company_logo_light'] = this.companyLogoLight;
    data['company_logo_dark'] = this.companyLogoDark;
    data['company_favicon'] = this.companyFavicon;
    data['cust_theme_bg'] = this.custThemeBg;
    data['cust_darklayout'] = this.custDarklayout;
    data['color'] = this.color;
    data['SITE_RTL'] = this.sITERTL;
    data['purchase_prefix'] = this.purchasePrefix;
    data['purchase_color'] = this.purchaseColor;
    data['purchase_template'] = this.purchaseTemplate;
    data['pos_color'] = this.posColor;
    data['pos_template'] = this.posTemplate;
    data['pos_prefix'] = this.posPrefix;
    data['storage_setting'] = this.storageSetting;
    data['local_storage_validation'] = this.localStorageValidation;
    data['local_storage_max_upload_size'] = this.localStorageMaxUploadSize;
    data['s3_key'] = this.s3Key;
    data['s3_secret'] = this.s3Secret;
    data['s3_region'] = this.s3Region;
    data['s3_bucket'] = this.s3Bucket;
    data['s3_url'] = this.s3Url;
    data['s3_endpoint'] = this.s3Endpoint;
    data['s3_max_upload_size'] = this.s3MaxUploadSize;
    data['s3_storage_validation'] = this.s3StorageValidation;
    data['wasabi_key'] = this.wasabiKey;
    data['wasabi_secret'] = this.wasabiSecret;
    data['wasabi_region'] = this.wasabiRegion;
    data['wasabi_bucket'] = this.wasabiBucket;
    data['wasabi_url'] = this.wasabiUrl;
    data['wasabi_root'] = this.wasabiRoot;
    data['wasabi_max_upload_size'] = this.wasabiMaxUploadSize;
    data['wasabi_storage_validation'] = this.wasabiStorageValidation;
    data['purchase_logo'] = this.purchaseLogo;
    data['proposal_logo'] = this.proposalLogo;
    data['invoice_logo'] = this.invoiceLogo;
    data['bill_logo'] = this.billLogo;
    data['pos_logo'] = this.posLogo;
    data['contract_prefix'] = this.contractPrefix;
    data['barcode_type'] = this.barcodeType;
    data['barcode_format'] = this.barcodeFormat;
    data['new_user'] = this.newUser;
    data['new_client'] = this.newClient;
    data['new_support_ticket'] = this.newSupportTicket;
    data['lead_assigned'] = this.leadAssigned;
    data['deal_assigned'] = this.dealAssigned;
    data['new_award'] = this.newAward;
    data['customer_invoice_sent'] = this.customerInvoiceSent;
    data['new_invoice_payment'] = this.newInvoicePayment;
    data['new_payment_reminder'] = this.newPaymentReminder;
    data['new_bill_payment'] = this.newBillPayment;
    data['bill_resent'] = this.billResent;
    data['proposal_sent'] = this.proposalSent;
    data['complaint_resent'] = this.complaintResent;
    data['leave_action_sent'] = this.leaveActionSent;
    data['payslip_sent'] = this.payslipSent;
    data['promotion_sent'] = this.promotionSent;
    data['resignation_sent'] = this.resignationSent;
    data['termination_sent'] = this.terminationSent;
    data['transfer_sent'] = this.transferSent;
    data['trip_sent'] = this.tripSent;
    data['vender_bill_sent'] = this.venderBillSent;
    data['warning_sent'] = this.warningSent;
    data['new_contract'] = this.newContract;
    data['vat_gst_number_switch'] = this.vatGstNumberSwitch;
    data['google_calendar_enable'] = this.googleCalendarEnable;
    data['google_calender_json_file'] = this.googleCalenderJsonFile;
    data['meta_title'] = this.metaTitle;
    data['meta_desc'] = this.metaDesc;
    data['meta_image'] = this.metaImage;
    data['enable_cookie'] = this.enableCookie;
    data['necessary_cookies'] = this.necessaryCookies;
    data['cookie_logging'] = this.cookieLogging;
    data['cookie_title'] = this.cookieTitle;
    data['cookie_description'] = this.cookieDescription;
    data['strictly_cookie_title'] = this.strictlyCookieTitle;
    data['strictly_cookie_description'] = this.strictlyCookieDescription;
    data['more_information_description'] = this.moreInformationDescription;
    data['contactus_url'] = this.contactusUrl;
    data['twilio_sid'] = this.twilioSid;
    data['twilio_token'] = this.twilioToken;
    data['twilio_from'] = this.twilioFrom;
    data['chat_gpt_key'] = this.chatGptKey;
    data['ip_restrict'] = this.ipRestrict;
    data['mail_driver'] = this.mailDriver;
    data['mail_host'] = this.mailHost;
    data['mail_port'] = this.mailPort;
    data['mail_username'] = this.mailUsername;
    data['mail_password'] = this.mailPassword;
    data['mail_encryption'] = this.mailEncryption;
    data['mail_from_address'] = this.mailFromAddress;
    data['mail_from_name'] = this.mailFromName;
    data['apps_url'] = this.appsUrl;
    return data;
  }
}