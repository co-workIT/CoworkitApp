class BookingModel {
  List<Data>? data;

  BookingModel({this.data});

  BookingModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(new Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  int? id;
  String? spaceId;
  String? companyId;
  String? userId;
  String? startDate;
  String? endDate;
  String? totalMin;
  String? createdBy;
  String? ownedBy;
  String? createdAt;
  String? updatedAt;
  Company? company;
  User? user;

  Data(
      {this.id,
        this.spaceId,
        this.companyId,
        this.userId,
        this.startDate,
        this.endDate,
        this.totalMin,
        this.createdBy,
        this.ownedBy,
        this.createdAt,
        this.updatedAt,
        this.company,
        this.user});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    spaceId = json['space_id'];
    companyId = json['company_id'];
    userId = json['user_id'];
    startDate = json['start_date'];
    endDate = json['end_date'];
    totalMin = json['total_min'];
    createdBy = json['created_by'];
    ownedBy = json['owned_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    company =
    json['company'] != null ? new Company.fromJson(json['company']) : null;
    user = json['user'] != null ? new User.fromJson(json['user']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['space_id'] = this.spaceId;
    data['company_id'] = this.companyId;
    data['user_id'] = this.userId;
    data['start_date'] = this.startDate;
    data['end_date'] = this.endDate;
    data['total_min'] = this.totalMin;
    data['created_by'] = this.createdBy;
    data['owned_by'] = this.ownedBy;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    if (this.company != null) {
      data['company'] = this.company!.toJson();
    }
    if (this.user != null) {
      data['user'] = this.user!.toJson();
    }
    return data;
  }
}

class Company {
  int? id;
  String? name;
  String? createdBy;
  String? ownedBy;
  String? createdAt;
  String? updatedAt;

  Company(
      {this.id,
        this.name,
        this.createdBy,
        this.ownedBy,
        this.createdAt,
        this.updatedAt});

  Company.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    createdBy = json['created_by'];
    ownedBy = json['owned_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['created_by'] = this.createdBy;
    data['owned_by'] = this.ownedBy;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}

class User {
  int? id;
  String? name;
  String? email;
  String? emailVerifiedAt;
  String? plan;
  Null? planExpireDate;
  String? requestedPlan;
  String? type;
  String? storageLimit;
  String? avatar;
  String? messengerColor;
  String? lang;
  String? defaultPipeline;
  String? activeStatus;
  String? deleteStatus;
  String? mode;
  String? darkMode;
  String? isActive;
  String? lastLoginAt;
  String? ownedBy;
  String? createdBy;
  String? createdAt;
  String? updatedAt;
  String? isEmailVerified;
  String? companyId;
  String? companyAdmin;
  String? profile;

  User(
      {this.id,
        this.name,
        this.email,
        this.emailVerifiedAt,
        this.plan,
        this.planExpireDate,
        this.requestedPlan,
        this.type,
        this.storageLimit,
        this.avatar,
        this.messengerColor,
        this.lang,
        this.defaultPipeline,
        this.activeStatus,
        this.deleteStatus,
        this.mode,
        this.darkMode,
        this.isActive,
        this.lastLoginAt,
        this.ownedBy,
        this.createdBy,
        this.createdAt,
        this.updatedAt,
        this.isEmailVerified,
        this.companyId,
        this.companyAdmin,
        this.profile});

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    emailVerifiedAt = json['email_verified_at'];
    plan = json['plan'];
    planExpireDate = json['plan_expire_date'];
    requestedPlan = json['requested_plan'];
    type = json['type'];
    storageLimit = json['storage_limit'];
    avatar = json['avatar'];
    messengerColor = json['messenger_color'];
    lang = json['lang'];
    defaultPipeline = json['default_pipeline'];
    activeStatus = json['active_status'];
    deleteStatus = json['delete_status'];
    mode = json['mode'];
    darkMode = json['dark_mode'];
    isActive = json['is_active'];
    lastLoginAt = json['last_login_at'];
    ownedBy = json['owned_by'];
    createdBy = json['created_by'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    isEmailVerified = json['is_email_verified'];
    companyId = json['company_id'];
    companyAdmin = json['company_admin'];
    profile = json['profile'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['email'] = this.email;
    data['email_verified_at'] = this.emailVerifiedAt;
    data['plan'] = this.plan;
    data['plan_expire_date'] = this.planExpireDate;
    data['requested_plan'] = this.requestedPlan;
    data['type'] = this.type;
    data['storage_limit'] = this.storageLimit;
    data['avatar'] = this.avatar;
    data['messenger_color'] = this.messengerColor;
    data['lang'] = this.lang;
    data['default_pipeline'] = this.defaultPipeline;
    data['active_status'] = this.activeStatus;
    data['delete_status'] = this.deleteStatus;
    data['mode'] = this.mode;
    data['dark_mode'] = this.darkMode;
    data['is_active'] = this.isActive;
    data['last_login_at'] = this.lastLoginAt;
    data['owned_by'] = this.ownedBy;
    data['created_by'] = this.createdBy;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['is_email_verified'] = this.isEmailVerified;
    data['company_id'] = this.companyId;
    data['company_admin'] = this.companyAdmin;
    data['profile'] = this.profile;
    return data;
  }
}