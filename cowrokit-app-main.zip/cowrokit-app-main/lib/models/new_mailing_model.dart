class MailingModel {
  final int id;
  final String name;
  final String capacity;
  final String price;
  final String description;
  final String typeId;
  final String meeting;
  final String window;
  final String ownedBy;
  final String createdBy;
  final String createdAt;
  final String updatedAt;

  MailingModel({
    required this.id,
    required this.name,
    required this.capacity,
    required this.price,
    required this.description,
    required this.typeId,
    required this.meeting,
    required this.window,
    required this.ownedBy,
    required this.createdBy,
    required this.createdAt,
    required this.updatedAt,
  });

  factory MailingModel.fromJson(Map<String, dynamic> json) {
    return MailingModel(
      id: json['id'],
      name: json['name'],
      capacity: json['capacity'],
      price: json['price'],
      description: json['description'],
      typeId: json['type_id'],
      meeting: json['meeting'],
      window: json['window'],
      ownedBy: json['owned_by'],
      createdBy: json['created_by'],
      createdAt: json['created_at'],
      updatedAt: json['updated_at'],
    );
  }
}

class MailingResponse {
  final List<MailingModel> data;

  MailingResponse({required this.data});

  factory MailingResponse.fromJson(Map<String, dynamic> json) {
    var list = json['data'] as List;
    List<MailingModel> mailings = list.map((i) => MailingModel.fromJson(i)).toList();

    return MailingResponse(data: mailings);
  }
}
