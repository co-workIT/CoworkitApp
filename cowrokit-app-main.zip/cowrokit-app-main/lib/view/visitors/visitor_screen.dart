import 'package:co_workit/constant/custom_form_field.dart';
import 'package:co_workit/constant/custom_fab_button.dart';
import 'package:co_workit/controllers/visitor_controller.dart';
import 'package:co_workit/models/visitor_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../constant/custom_color.dart';
import '../../constant/custom_text_style.dart';

class VisitorScreen extends StatelessWidget {
  final VisitorController visitorController = Get.put(VisitorController());

  VisitorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    CustomTextStyles textStyle = CustomTextStyles();
    return Scaffold(
      backgroundColor: Colors.white70,
      floatingActionButton: CustomFloatingButton(
        backgroundColor: Theme.of(context).floatingActionButtonTheme.backgroundColor,
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) {
              return VisitorDialog(visitorController: visitorController);
            },
          );
        },
        icon: Icon(Icons.add,
            color: Theme.of(context).iconTheme.color),
      ),
      body: Container(
        height: double.infinity,
        color: Theme.of(context).scaffoldBackgroundColor,
        child: SafeArea(
          child: GetBuilder<VisitorController>(
            builder: (controller) => GridView.builder(
              padding: const EdgeInsets.all(12),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 1,
                childAspectRatio: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 5,
              ),
              itemCount: controller.visitors.length,
              itemBuilder: (context, index) {
                Visitor visitor = controller.visitors[index];
                return Card(
                  color: Theme.of(context).cardColor,
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5.0),
                  ),
                  shadowColor: Colors.black26,
                  child: Container(
                    // Adjust opacity for a frosted glass effect
                    padding: const EdgeInsets.all(13.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("Visitor Name".tr,
                                style: textStyle.text14b(context)),
                            Text(visitor.name,
                                style: textStyle.text14(context)),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("Visitor CNIC".tr,
                                style: textStyle.text14b(context)),
                            Text(visitor.cnic,
                                style: textStyle.text14(context)),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("Date".tr, style: textStyle.text14b(context)),
                            Text(visitor.date,
                                style: textStyle.text14(context)),
                          ],
                        ),
                        const Divider(color: Colors.black),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit, color: Colors.green),
                              onPressed: () {
                                showDialog(
                                  context: context,
                                  builder: (context) {
                                    return VisitorDialog(
                                      visitorController: visitorController,
                                      visitor: visitor,
                                    );
                                  },
                                );
                              },
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete,
                                  color: CustomColor.iconColorRed),
                              onPressed: () {
                                visitorController.deleteVisitor(visitor.id);
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}

class VisitorDialog extends StatefulWidget {
  final VisitorController visitorController;
  final Visitor? visitor;

  const VisitorDialog({required this.visitorController, this.visitor});

  @override
  _VisitorDialogState createState() => _VisitorDialogState();
}

class _VisitorDialogState extends State<VisitorDialog> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _cnicController;
  late TextEditingController _dateController;
  // late DateTime _dateTime = DateTime.now();

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.visitor?.name ?? '');
    _cnicController = TextEditingController(text: widget.visitor?.cnic ?? '');
    _dateController = TextEditingController(text: widget.visitor?.date ?? '');
    // if (widget.visitor != null) {
    //   _dateTime = DateTime.parse(widget.visitor!.date);
    // }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _cnicController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    CustomTextStyles textStyle = CustomTextStyles();
    return AlertDialog(
      title: Text(
        widget.visitor == null ? 'Add Visitor'.tr : 'Update Visitor'.tr,
        style: TextStyle(color: Theme.of(context).secondaryHeaderColor),
      ),
      content: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextFormField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: 'Name'.tr,
                filled: true,
                fillColor: Colors.white.withOpacity(0.9),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  gapPadding: 5,
                  borderSide: const BorderSide(
                    color: Color.fromRGBO(30, 168, 231, 1),
                    width: 1.0,
                  ),
                ),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter a name'.tr;
                }
                return null;
              },
            ),
            const SizedBox(
              height: 10.0,
            ),
            TextFormField(
              controller: _dateController,
              decoration: InputDecoration(
                labelText: 'Date'.tr,
                filled: true,
                fillColor: Colors.white.withOpacity(0.9),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  gapPadding: 5,
                  borderSide: const BorderSide(
                    color: Color.fromRGBO(30, 168, 231, 1),
                    width: 1.0,
                  ),
                ),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter a name'.tr;
                }
                return null;
              },
            ),
            const SizedBox(
              height: 10.0,
            ),
            TextFormField(
              controller: _cnicController,
              decoration: InputDecoration(
                labelText: 'CNIC'.tr,
                filled: true,
                fillColor: Colors.white.withOpacity(0.9),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  gapPadding: 5,
                  borderSide: const BorderSide(
                    color: Color.fromRGBO(30, 168, 231, 1),
                    width: 1.0,
                  ),
                ),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter a name'.tr;
                }
                return null;
              },
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text('Cancel'.tr, style: textStyle.formText(context)),
        ),
        TextButton(
          onPressed: () {
            if (_formKey.currentState?.validate() ?? false) {
              if (widget.visitor == null) {
                widget.visitorController.addVisitor(
                  Visitor(
                    id: DateTime.now().millisecondsSinceEpoch,
                    name: _nameController.text,
                    date: _dateController.text,
                    cnic: _cnicController.text,
                  ),
                );
              } else {
                widget.visitorController.updateVisitor(
                  widget.visitor!.copyWith(
                    name: _nameController.text,
                    date: _dateController.text,
                    cnic: _cnicController.text,
                  ),
                );
              }
              Navigator.of(context).pop();
            }
          },
          child: Text(widget.visitor == null ? 'Add'.tr : 'Update'.tr,
              style: textStyle.formText(context)),
        ),
      ],
    );
  }
}
