// import 'package:co_workit/constant/custom_form_field.dart';
// import 'package:co_workit/constant/custom_text_button.dart';
// import 'package:co_workit/constant/custom_text_style.dart';
// import 'package:co_workit/controllers/booking_controller.dart';
// import 'package:co_workit/models/event.dart';
// import 'package:co_workit/view/booking/widgets/calendar.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:intl/intl.dart';
// import 'package:table_calendar/table_calendar.dart';
//
// import '../../constant/custom_color.dart';
// // import '../../controllers/meeting_controllers.dart';
//
// class BookingScreen extends StatelessWidget {
//   final BookingController meetingController = Get.put(BookingController());
//
//   @override
//   Widget build(BuildContext context) {
//     final BookingController controller = Get.put(BookingController());
//     CustomTextStyles textStyle = CustomTextStyles();
//     return Scaffold(
//       body: Container(
//         color: Theme.of(context).brightness == Brightness.light
//             ? CustomColor.backgroundColor
//             : CustomColorDark.backgroundColor,
//         child: Column(
//           mainAxisSize: MainAxisSize.max,
//           children: [
//             Padding(
//               padding: const EdgeInsets.all(10.0),
//               child: Obx(() => CalendarHeader(
//                     focusedDay: controller.focusedDay.value,
//                     clearButtonVisible: controller.canClearSelection,
//                     onTodayButtonTap: controller.goToToday,
//                     onClearButtonTap: controller.clearSelection,
//                     onLeftArrowTap: () {
//                       controller.pageController.previousPage(
//                         duration: const Duration(milliseconds: 300),
//                         curve: Curves.easeOut,
//                       );
//                     },
//                     onRightArrowTap: () {
//                       controller.pageController.nextPage(
//                         duration: const Duration(milliseconds: 300),
//                         curve: Curves.easeOut,
//                       );
//                     },
//                   )),
//             ),
//             const SizedBox(height: 8.0),
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 20.0),
//               child: Obx(() => TableCalendar<Event>(
//                     daysOfWeekStyle: const DaysOfWeekStyle(
//                       weekdayStyle: TextStyle(
//                         color: Colors.blue,
//                         fontWeight: FontWeight.bold,
//                       ),
//                       weekendStyle: TextStyle(
//                         color: Colors.redAccent,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                     firstDay: DateTime.utc(2022, 1, 1),
//                     lastDay: DateTime.utc(2030, 12, 31),
//                     focusedDay: controller.focusedDay.value,
//                     headerVisible: false,
//                     selectedDayPredicate: (day) =>
//                         controller.selectedDays.contains(day),
//                     rangeStartDay: controller.rangeStart.value,
//                     rangeEndDay: controller.rangeEnd.value,
//                     calendarFormat: controller.calendarFormat.value,
//                     rangeSelectionMode: controller.rangeSelectionMode.value,
//                     eventLoader: controller.getEventsForDay,
//                     holidayPredicate: (day) => day.day == 20,
//                     onDaySelected: (selectedDay, focusedDay) {
//                       controller.onDaySelected(selectedDay, focusedDay);
//                       _showAddEventDialog(context, controller, selectedDay);
//                     },
//                     onRangeSelected: controller.onRangeSelected,
//                     onCalendarCreated: (pageController) {
//                       controller.pageController = pageController;
//                     },
//                     onPageChanged: (focusedDay) =>
//                         controller.focusedDay.value = focusedDay,
//                     onFormatChanged: (format) {
//                       if (controller.calendarFormat.value != format) {
//                         controller.calendarFormat.value = format;
//                       }
//                     },
//                     calendarBuilders: CalendarBuilders(
//                       markerBuilder: (context, date, events) {
//                         if (events.isNotEmpty) {
//                           return Padding(
//                             padding: const EdgeInsets.only(top: 20, left: 15),
//                             child: ListView.builder(
//                               scrollDirection: Axis.horizontal,
//                               itemCount: events.length > 3 ? 4 : events.length,
//                               itemBuilder: (context, index) {
//                                 if (index < 3) {
//                                   return Container(
//                                     width: 5.0,
//                                     height: 5.0,
//                                     margin: const EdgeInsets.symmetric(
//                                         horizontal: 0.2),
//                                     decoration: const BoxDecoration(
//                                       shape: BoxShape.circle,
//                                       color: Colors.red,
//                                     ),
//                                   );
//                                 } else {
//                                   return Container(
//                                     width: 15.0,
//                                     height: 5.0,
//                                     margin: const EdgeInsets.symmetric(
//                                         horizontal: 0.2),
//                                     decoration: const BoxDecoration(
//                                       color: Colors.transparent,
//                                     ),
//                                     child: Center(
//                                       child: Text(
//                                         '+${events.length - 3}',
//                                         style: const TextStyle(
//                                           fontSize: 10,
//                                           fontWeight: FontWeight.bold,
//                                           color: Colors.red,
//                                         ),
//                                       ),
//                                     ),
//                                   );
//                                 }
//                               },
//                             ),
//                           );
//                         }
//                         return const SizedBox();
//                       },
//                     ),
//                   )),
//             ),
//             const SizedBox(height: 8.0),
//             Expanded(
//               child: Obx(() {
//                 if (meetingController.isLoading.value) {
//                   return Center(child: CircularProgressIndicator());
//                 } else {
//                   return ListView.builder(
//                     itemCount: meetingController.meetingList.length,
//                     itemBuilder: (context, index) {
//                       var meeting = meetingController.meetingList[index];
//                       return ListTile(
//                         title: Text(meeting.name ?? 'No Name'),
//                         subtitle: Text(
//                           'Capacity: ${meeting.capacity ?? 'N/A'}, '
//                           'Price: ${meeting.price ?? 'N/A'}, '
//                           'Description: ${meeting.description ?? 'N/A'}',
//                         ),
//                       );
//                     },
//                   );
//                 }
//               }),
//
//               // Obx(() => ListView.builder(
//               //       itemCount: controller.selectedEvents.length,
//               //       itemBuilder: (context, index) {
//               //         final event = controller.selectedEvents[index];
//               //         return Container(
//               //           margin: const EdgeInsets.symmetric(
//               //             horizontal: 10.0,
//               //             vertical: 4.0,
//               //           ),
//               //           decoration: BoxDecoration(
//               //             border: Border.all(),
//               //             borderRadius: BorderRadius.circular(5.0),
//               //           ),
//               //           child: Padding(
//               //             padding: const EdgeInsets.symmetric(horizontal: 8.0),
//               //             child: ListTile(
//               //               title: Row(
//               //                 mainAxisSize: MainAxisSize.max,
//               //                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               //                 children: [
//               //                   Text(
//               //                     'Meetings:',
//               //                     style: textStyle.headline2(context),
//               //                   ),
//               //                   Text('${index + 1}'
//               //                       // '${controller.getEventsForDay(event.date).length}',
//               //                       ),
//               //                   Row(
//               //                     mainAxisSize: MainAxisSize.min,
//               //                     children: [
//               //                       IconButton(
//               //                         icon: const Icon(
//               //                           Icons.add,
//               //                           color: Colors.black,
//               //                           size: 30,
//               //                         ),
//               //                         onPressed: () => _showEditEventDialog(
//               //                             context, controller, event),
//               //                       ),
//               //                       IconButton(
//               //                         icon: const Icon(Icons.delete,
//               //                             color: CustomColor.iconColorRed),
//               //                         onPressed: () {
//               //                           controller.removeEvent(event);
//               //                         },
//               //                       ),
//               //                     ],
//               //                   ),
//               //                 ],
//               //               ),
//               //               subtitle: Column(
//               //                 children: [
//               //                   Row(
//               //                     mainAxisAlignment:
//               //                         MainAxisAlignment.spaceBetween,
//               //                     children: [
//               //                       Text(
//               //                         'Company Name:',
//               //                         style: textStyle.text14n(context),
//               //                       ),
//               //                       Text(
//               //                         event.company,
//               //                       ),
//               //                     ],
//               //                   ),
//               //                   Row(
//               //                     mainAxisAlignment:
//               //                         MainAxisAlignment.spaceBetween,
//               //                     children: [
//               //                       Text(
//               //                         'Subject:',
//               //                         style: textStyle.text14n(context),
//               //                       ),
//               //                       Text(
//               //                         event.title,
//               //                       ),
//               //                     ],
//               //                   ),
//               //                   Row(
//               //                     mainAxisAlignment:
//               //                         MainAxisAlignment.spaceBetween,
//               //                     children: [
//               //                       Text(
//               //                         'Start Time:',
//               //                         style: TextStyle(
//               //                             color: Theme.of(context)
//               //                                 .secondaryHeaderColor),
//               //                       ),
//               //                       Text(
//               //                         '${event.startTime}',
//               //                       ),
//               //                     ],
//               //                   ),
//               //                   Row(
//               //                     mainAxisAlignment:
//               //                         MainAxisAlignment.spaceBetween,
//               //                     children: [
//               //                       Text(
//               //                         'End Time:',
//               //                         style: TextStyle(
//               //                             color: Theme.of(context)
//               //                                 .secondaryHeaderColor),
//               //                       ),
//               //                       Text(
//               //                         '${event.endTime}',
//               //                       ),
//               //                     ],
//               //                   ),
//               //                   Row(
//               //                     mainAxisAlignment:
//               //                         MainAxisAlignment.spaceBetween,
//               //                     children: [
//               //                       Text(
//               //                         'Date:',
//               //                         style: TextStyle(
//               //                             color: Theme.of(context)
//               //                                 .secondaryHeaderColor),
//               //                       ),
//               //                       Text(
//               //                         '${DateFormat.yMd().format(event.date)}',
//               //                       ),
//               //                     ],
//               //                   ),
//               //                 ],
//               //               ),
//               //             ),
//               //           ),
//               //         );
//               //       },
//               //     )),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   void _showAddEventDialog(BuildContext context, BookingController controller,
//       DateTime selectedDay) {
//     final messageController = TextEditingController();
//     final companyNameController = TextEditingController();
//     TimeOfDay? _selectedStartTime;
//     TimeOfDay? _selectedEndTime;
//     CustomTextStyles textStyle = CustomTextStyles();
//     final _formKey = GlobalKey<FormState>();
//     showDialog(
//       context: context,
//       builder: (context) {
//         return StatefulBuilder(
//           builder: (context, setState) {
//             return AlertDialog(
//               shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(5)),
//               shadowColor: Theme.of(context).secondaryHeaderColor,
//               title: Text(
//                 'Create Meeting',
//                 style: textStyle.head18bb(context),
//               ),
//               content: Form(
//                 key: _formKey,
//                 child: SingleChildScrollView(
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.center,
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       CustomTextFormField(
//                         textStyle: TextStyle(
//                           color: Theme.of(context).secondaryHeaderColor,
//                         ),
//                         validator: (value) {
//                           value == null || value.isEmpty
//                               ? "Write Company name"
//                               : null;
//                         },
//                         controller: companyNameController,
//                         labelText: 'Company',
//                         radius: 5,
//                       ),
//                       // TextFormField(
//                       //   validator: (value) {
//                       //     if (value == null || value.isEmpty) {
//                       //       return "Write Company name";
//                       //     }
//                       //     return null;
//                       //   },
//                       //   controller: companyNameController,
//                       //   decoration:
//                       //       const InputDecoration(labelText: 'Company Name'),
//                       // ),
//                       const SizedBox(height: 8.0),
//                       Container(
//                         width: 200,
//                         height: 50,
//                         decoration: BoxDecoration(
//                           border: Border.all(
//                               color: Colors.grey,
//                               width: 1.0), // Border color and width
//                           borderRadius:
//                               BorderRadius.circular(8.0), // Border radius
//                         ),
//                         child: ListTile(
//                           title: Text(
//                             'Start Time:',
//                             style: textStyle.text14n(context),
//                           ),
//                           trailing: Text(
//                             _selectedStartTime == null
//                                 ? 'Select Time'
//                                 : _selectedStartTime!.format(context),
//                           ),
//                           onTap: () async {
//                             final selectedTime = await showTimePicker(
//                               barrierColor: Colors.transparent,
//                               context: context,
//                               initialTime: TimeOfDay.now(),
//                             );
//                             if (selectedTime != null) {
//                               setState(() {
//                                 _selectedStartTime = selectedTime;
//                               });
//                             }
//                           },
//                         ),
//                       ),
//                       const SizedBox(height: 15.0),
//                       Container(
//                         width: 200,
//                         height: 50,
//                         decoration: BoxDecoration(
//                           border: Border.all(
//                               color: Colors.grey,
//                               width: 1.0), // Border color and width
//                           borderRadius:
//                               BorderRadius.circular(8.0), // Border radius
//                         ),
//                         child: ListTile(
//                           title: Text(
//                             'End Time:',
//                             style: textStyle.text14(context),
//                           ),
//                           trailing: Text(
//                               _selectedEndTime == null
//                                   ? 'Select Time'
//                                   : _selectedEndTime!.format(context),
//                               style: textStyle.text14(context)),
//                           onTap: () async {
//                             final selectedTime = await showTimePicker(
//                               context: context,
//                               initialTime: TimeOfDay.now(),
//                             );
//                             if (selectedTime != null) {
//                               setState(() {
//                                 _selectedEndTime = selectedTime;
//                               });
//                             }
//                           },
//                         ),
//                       ),
//                       const SizedBox(height: 8.0),
//                       CustomTextFormField(
//                         textStyle: TextStyle(
//                           color: Theme.of(context).secondaryHeaderColor,
//                         ),
//                         validator: (value) {
//                           if (value == null || value.isEmpty) {
//                             return "Write Subject";
//                           }
//                           return null;
//                         },
//                         controller: messageController,
//                         labelText: 'Subject',
//                         radius: 5,
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//               actions: [
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     CustomTextButton(
//                       textColor: Colors.white,
//                       width: 100,
//                       height: 40,
//                       backgroundColor: Theme.of(context).primaryColor,
//                       onPressed: () {
//                         Navigator.of(context).pop();
//                       },
//                       text: 'Cancel',
//                     ),
//                     const SizedBox(
//                       width: 10,
//                     ),
//                     CustomTextButton(
//                       textColor: Colors.white,
//                       width: 100,
//                       height: 40,
//                       backgroundColor: Theme.of(context).primaryColor,
//                       onPressed: () {
//                         if (_formKey.currentState!.validate()) {
//                           if (_selectedStartTime == null ||
//                               _selectedEndTime == null) {
//                             ScaffoldMessenger.of(context).showSnackBar(
//                               SnackBar(
//                                   content: Text(
//                                       'Please select start and end times',
//                                       style: textStyle.text14(context))),
//                             );
//                             return;
//                           }
//
//                           final startTime = _selectedStartTime!.format(context);
//                           final endTime = _selectedEndTime!.format(context);
//                           final message = messageController.text;
//                           final company = companyNameController.text;
//
//                           final event = Event(
//                             date: selectedDay,
//                             title: message,
//                             startTime: startTime,
//                             endTime: endTime,
//                             company: company,
//                           );
//
//                           controller.addEvent(event);
//                           Navigator.of(context).pop();
//                         }
//                       },
//                       text: 'Create',
//                     ),
//                     const SizedBox(
//                       width: 10,
//                     ),
//                   ],
//                 ),
//
//                 // TextButton(
//                 //   onPressed: () {
//                 //     if (_formKey.currentState!.validate()) {
//                 //       if (_selectedStartTime == null ||
//                 //           _selectedEndTime == null) {
//                 //         ScaffoldMessenger.of(context).showSnackBar(
//                 //           SnackBar(
//                 //               content: Text('Please select start and end times',
//                 //                   style: textStyle.text14(context))),
//                 //         );
//                 //         return;
//                 //       }
//
//                 //       final startTime = _selectedStartTime!.format(context);
//                 //       final endTime = _selectedEndTime!.format(context);
//                 //       final message = messageController.text;
//                 //       final company = companyNameController.text;
//
//                 //       final event = Event(
//                 //         date: selectedDay,
//                 //         title: message,
//                 //         startTime: startTime,
//                 //         endTime: endTime,
//                 //         company: company,
//                 //       );
//
//                 //       controller.addEvent(event);
//                 //       Navigator.of(context).pop();
//                 //     }
//                 //   },
//                 //   child: Text('Create', style: textStyle.text14(context)),
//                 // ),
//               ],
//             );
//           },
//         );
//       },
//     );
//   }
//
//   void _showEditEventDialog(
//       BuildContext context, BookingController controller, Event event) {
//     final messageController = TextEditingController(text: event.title);
//     final companyNameController = TextEditingController(text: event.company);
//     TimeOfDay? _selectedStartTime = _timeOfDayFromString(event.startTime);
//     TimeOfDay? _selectedEndTime = _timeOfDayFromString(event.endTime);
//
//     final _formKey = GlobalKey<FormState>();
//     showDialog(
//       context: context,
//       builder: (context) {
//         return StatefulBuilder(
//           builder: (context, setState) {
//             return AlertDialog(
//               shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(10.0)),
//               title: Text(
//                 'Edit Meeting',
//                 style: TextStyle(color: Theme.of(context).secondaryHeaderColor),
//               ),
//               content: Form(
//                 key: _formKey,
//                 child: SingleChildScrollView(
//                   child: Column(
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       CustomTextFormField(
//                         textStyle: TextStyle(
//                           color: Theme.of(context).secondaryHeaderColor,
//                         ),
//                         validator: (value) {
//                           value == null || value.isEmpty
//                               ? "Write Company name"
//                               : null;
//                         },
//                         controller: companyNameController,
//                         labelText: 'Company',
//                         radius: 5,
//                       ),
//                       // TextFormField(
//                       //   validator: (value) {
//                       //     if (value == null || value.isEmpty) {
//                       //       return "Write Company name";
//                       //     }
//                       //     return null;
//                       //   },
//                       //   controller: companyNameController,
//                       //   decoration: InputDecoration(
//                       //       labelText: 'Company Name',
//                       //       labelStyle: TextStyle(
//                       //           color: Theme.of(context).secondaryHeaderColor)),
//                       // ),
//                       const SizedBox(height: 0.0),
//                       Container(
//                         decoration: BoxDecoration(
//                           border: Border.all(
//                               color: Colors.grey,
//                               width: 1.0), // Border color and width
//                           borderRadius:
//                               BorderRadius.circular(8.0), // Border radius
//                         ),
//                         child: ListTile(
//                           title: Text(
//                             'Start Time:',
//                             style: TextStyle(
//                                 color: Theme.of(context).secondaryHeaderColor),
//                           ),
//                           trailing: Text(
//                             _selectedStartTime == null
//                                 ? 'Select Time'
//                                 : _selectedStartTime!.format(context),
//                             style: TextStyle(
//                                 color: Theme.of(context).secondaryHeaderColor),
//                           ),
//                           onTap: () async {
//                             final selectedTime = await showTimePicker(
//                               context: context,
//                               initialTime: TimeOfDay.now(),
//                             );
//                             if (selectedTime != null) {
//                               setState(() {
//                                 _selectedStartTime = selectedTime;
//                               });
//                             }
//                           },
//                         ),
//                       ),
//                       const SizedBox(height: 4.0),
//                       ListTile(
//                         title: Text('End Time:',
//                             style: TextStyle(
//                                 color: Theme.of(context).secondaryHeaderColor)),
//                         trailing: Text(
//                             _selectedEndTime == null
//                                 ? 'Select Time'
//                                 : _selectedEndTime!.format(context),
//                             style: TextStyle(
//                                 color: Theme.of(context).secondaryHeaderColor)),
//                         onTap: () async {
//                           _showCustomTimePicker(context, TimeOfDay.now());
//                           // final selectedTime = await showTimePicker(
//                           //   context: context,
//                           //   initialTime: TimeOfDay.now(),
//                           // );
//                           // if (selectedTime != null) {
//                           //   setState(() {
//                           //     _selectedEndTime = selectedTime;
//                           //   });
//                           // }
//                         },
//                       ),
//                       const SizedBox(height: 0.0),
//                       CustomTextFormField(
//                         textStyle: TextStyle(
//                           color: Theme.of(context).secondaryHeaderColor,
//                         ),
//                         validator: (value) {
//                           if (value == null || value.isEmpty) {
//                             return "Write Subject";
//                           }
//                           return null;
//                         },
//                         controller: messageController,
//                         labelText: 'Subject',
//                         radius: 5,
//                       ),
//                       // TextFormField(
//                       //   validator: (value) {
//                       //     if (value == null || value.isEmpty) {
//                       //       return "Write Subject";
//                       //     }
//                       //     return null;
//                       //   },
//                       //   controller: messageController,
//                       //   decoration: InputDecoration(
//                       //       labelText: 'Subject',
//                       //       labelStyle: TextStyle(
//                       //           color: Theme.of(context).secondaryHeaderColor)),
//                       // ),
//                     ],
//                   ),
//                 ),
//               ),
//               actions: [
//                 TextButton(
//                   onPressed: () {
//                     Navigator.of(context).pop();
//                   },
//                   child: const Text(
//                     'Cancel',
//                     style: TextStyle(color: Colors.red),
//                   ),
//                 ),
//                 TextButton(
//                   onPressed: () {
//                     if (_formKey.currentState!.validate()) {
//                       if (_selectedStartTime == null ||
//                           _selectedEndTime == null) {
//                         ScaffoldMessenger.of(context).showSnackBar(
//                           const SnackBar(
//                               content:
//                                   Text('Please select start and end times')),
//                         );
//                         return;
//                       }
//
//                       final startTime = _selectedStartTime!.format(context);
//                       final endTime = _selectedEndTime!.format(context);
//                       final message = messageController.text;
//                       final company = companyNameController.text;
//
//                       final updatedEvent = Event(
//                         date: event.date,
//                         title: message,
//                         startTime: startTime,
//                         endTime: endTime,
//                         company: company,
//                       );
//
//                       controller.updateEvent(event, updatedEvent);
//                       Navigator.of(context).pop();
//                     }
//                   },
//                   child: Text('Update',
//                       style: TextStyle(
//                           color: Theme.of(context).secondaryHeaderColor)),
//                 ),
//               ],
//             );
//           },
//         );
//       },
//     );
//   }
//
//   TimeOfDay _timeOfDayFromString(String time) {
//     try {
//       final format = DateFormat.jm();
//       return TimeOfDay.fromDateTime(format.parse(time));
//     } catch (e) {
//       return const TimeOfDay(
//           hour: 0, minute: 0); // Return a default time in case of error
//     }
//   }
//
//   Future<TimeOfDay?> _showCustomTimePicker(
//       BuildContext context, TimeOfDay initialTime) {
//     TimeOfDay selectedTime = initialTime;
//     return showDialog<TimeOfDay>(
//       context: context,
//       builder: (context) {
//         return StatefulBuilder(
//           builder: (context, setState) {
//             return AlertDialog(
//               title: const Text('Select Time'),
//               content: SizedBox(
//                 height: 200,
//                 child: Column(
//                   children: [
//                     Expanded(
//                       child: TimePickerDialog(
//                         initialTime: TimeOfDay.now(),
//                         confirmText: 'Confirm',
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               actions: [
//                 TextButton(
//                   onPressed: () {
//                     Navigator.pop(context, null);
//                   },
//                   child: Text(
//                     'Cancel',
//                     style: TextStyle(
//                         color: Theme.of(context).secondaryHeaderColor),
//                   ),
//                 ),
//                 TextButton(
//                   onPressed: () {
//                     Navigator.pop(context, selectedTime);
//                   },
//                   child: Text(
//                     'OK',
//                     style: TextStyle(
//                         color: Theme.of(context).secondaryHeaderColor),
//                   ),
//                 ),
//               ],
//             );
//           },
//         );
//       },
//     );
//   }
// }
