import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:co_workit/controllers/profile_controller.dart';

class ProfileScreen extends StatelessWidget {

  final ProfileController profileController = Get.put(ProfileController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white
        ),
        backgroundColor: Get.theme.floatingActionButtonTheme.backgroundColor,
        title: const Text('Profile',style: TextStyle(color: Colors.white),),
      ),
      body: Obx(() {
        // Check if data is still loading
        if (profileController.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        } else {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0,vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () async {
                    // Placeholder for updating profile picture
                    // final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
                    // if (image != null) {
                    //   // Handle image upload and update profile picture
                    //   await _updateProfilePicture(image.path);
                    // }
                  },
                  child: CircleAvatar(
                    radius: 45,
                    backgroundImage: NetworkImage(
                      profileController.user.value.data?.user?.profile ??
                          'https://static.vecteezy.com/system/resources/previews/026/619/142/non_2x/default-avatar-profile-icon-of-social-media-user-photo-image-vector.jpg',
                    ),
                  ),
                ),
                SizedBox(height: 10.0),
                Card(
                color: Colors.white,
                shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(5.0), // Increased corner radius
                side: BorderSide(
                color: Theme.of(context).brightness == Brightness.dark
                ? Colors.grey[800] ?? Colors.grey
                    : Colors.grey[300] ?? Colors.grey,
                // Adjust border color based on theme
                width: 0.5,
                ),
                ),
                shadowColor: Theme.of(context).shadowColor.withOpacity(0.3), // Subtle drop shadow
                margin: const EdgeInsets.symmetric(
        vertical: 8.0, horizontal: 16.0),
                  child:
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                            children: [
                    Text(
                    'Name: ${profileController.user.value.data?.user?.name}',
                      style: const TextStyle(fontSize: 14),
                    ),
                        const SizedBox(height: 10),
                                    Text(
                    'Email: ${profileController.user.value.data?.user?.email ?? 'N/A'}',
                    style: const TextStyle(fontSize: 14),
                                    ),
                              const SizedBox(height: 10),
                              Text(
                                'User Plan: ${profileController.user.value.data?.user?.plan ?? 'N/A'}',
                                style: const TextStyle(fontSize: 14),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                'User Plan: ${profileController.user.value.data?.user?.plan ?? 'N/A'}',
                                style: const TextStyle(fontSize: 14),
                              ),

                            ],
                            ),
                  )
                // Add more fields as needed
                ),
              ],
            ),
          );
        }
      }),
    );
  }
}
