import 'package:co_workit/constant/custom_form_field.dart';

import 'package:co_workit/controllers/profile_controller.dart';
import 'package:co_workit/view/auth/forget_password.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


import '../../constant/custom_button.dart';
import '../../constant/custom_color.dart';
import '../../constant/custom_text_button.dart';
import '../../constant/custom_text_style.dart';

class ProfileScreen extends StatelessWidget {
  // final ImagePicker _picker = ImagePicker(); // Initialize ImagePicker
  final ProfileController profileController = Get.put(ProfileController());

  @override
  Widget build(BuildContext context) {
    CustomTextStyles textStyle = CustomTextStyles();

    return Scaffold(
      backgroundColor: Get.theme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).floatingActionButtonTheme.backgroundColor,
        iconTheme: IconThemeData(
          color: Theme.of(context).brightness == Brightness.dark
              ? CustomColor.backgroundColor
              : CustomColorDark.backgroundColor,
        ),
        title: Text('Profile', style: textStyle.head18b(context)),
      ),
      body: Container(
        color: Theme.of(context).brightness == Brightness.light
            ? CustomColor.backgroundColor.withOpacity(0.8)
            : CustomColorDark.backgroundColor,
        height: double.infinity,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Center(
                  child: GestureDetector(
                    onTap: () async {
                      // // Pick an image and update profile picture
                      // final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
                      // if (image != null) {
                      //   // Handle image upload and update profile picture
                      //   await _updateProfilePicture(image.path);
                      // }
                    },
                    child: CircleAvatar(
                      radius: 45,
                        backgroundImage: NetworkImage(
                          profileController.user.value.data?.user?.profile ??
                              'https://static.vecteezy.com/system/resources/previews/026/619/142/non_2x/default-avatar-profile-icon-of-social-media-user-photo-image-vector.jpg',
                        ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                CustomTextFormField(
                  textStyle: const TextStyle(color: CustomColor.appBackgrounColor),
                  controller: TextEditingController(
                    text: profileController.user.value.data?.user?.name ?? '',
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter your name';
                    }
                    return null;
                  },
                  onChanged: (value) {
                    // Handle name change
                  },
                  labelText: 'Your name',
                  keyboardType: TextInputType.text,
                  prefixIcon: Icon(
                    Icons.person,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? CustomColor.backgroundColor
                        : CustomColorDark.backgroundColor,
                  ),
                ),
                CustomTextFormField(
                  textStyle: const TextStyle(color: CustomColor.textColorWhite),
                  controller: TextEditingController(
                    text: profileController.user.value.data?.user?.email ?? '',
                  ),
                  labelText: 'Email',
                  prefixIcon: Icon(
                    Icons.email,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? CustomColor.backgroundColor
                        : CustomColorDark.backgroundColor,
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter your email';
                    }
                    // Add email format validation if needed
                    return null;
                  },
                  onChanged: (value) {
                    // Handle email change
                  },
                ),
                CustomButton(
                  backgroundColor: CustomColor.appBarColor,
                  onPressed: () {
                    if (Form.of(context).validate()) {
                      // Save changes logic
                      String name = profileController.user.value.data?.user?.name ?? '';
                      String email =profileController.user.value.data?.user?.email ?? '';
                      // Implement save changes functionality here
                      print('Name: $name, Email: $email');
                    }
                  },
                  text: 'Save Changes',
                ),
                const SizedBox(height: 10),
                CustomTextButton(
                  textColor: Colors.white,
                  onPressed: () {
                    Get.to(() => ForgetPassword());
                  },
                  text: 'Forget Password',
                  borderRadius: 40,
                  backgroundColor: Theme.of(context).brightness == Brightness.dark
                      ? CustomColor.backgroundColor
                      : CustomColorDark.backgroundColor,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _updateProfilePicture(String imagePath) async {
    // Implement the logic to upload the image and update the profile picture
    // This can include making a request to your backend to update the profile picture

    // Example:
    // final response = await yourApiService.uploadProfilePicture(imagePath);
    // if (response.isSuccessful) {
    //   authController.updateUserProfilePicture(response.newProfilePictureUrl);
    // }
  }
}
