import 'package:co_workit/controllers/invoice_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../constant/custom_text_style.dart';

class InvoiceScreenNew extends StatelessWidget {
  final InvoiceController invoiceController = Get.put(InvoiceController());

  InvoiceScreenNew({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    CustomTextStyles textStyle = CustomTextStyles(); // Initialize CustomTextStyles instance

    return Scaffold(
      body: Column(
        children: [
          Container(
            alignment: Alignment.center,
            width: double.infinity,
            height: 100,
            padding: const EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              color: Get.theme.floatingActionButtonTheme.backgroundColor,
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(40.0),
                bottomRight: Radius.circular(40.0),
              ),
            ),
            child: const Text(
              'Invoice',
              style: TextStyle(
                color: Colors.white,
                fontSize: 25,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: Theme.of(context).scaffoldBackgroundColor,
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Card(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5.0), // Increased corner radius
                      side: BorderSide(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.grey[800] ?? Colors.grey
                            : Colors.grey[300] ?? Colors.grey,
                        // Adjust border color based on theme
                        width: 0.5,
                      ),
                    ),
                    shadowColor: Theme.of(context).shadowColor.withOpacity(0.3), // Subtle drop shadow
                    margin: const EdgeInsets.symmetric(
                        vertical: 8.0, horizontal: 16.0), // Add spacing between cards
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Invoice #:'.tr,
                                  style: textStyle.text14(context)), // Use text14 style here
                              Text('01',
                                  style: textStyle.text14(context)), // Use text14 style here
                            ],
                          ),
                          const SizedBox(height: 2.0),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('email:'.tr,
                                  style: textStyle.text14(context)), // Use text14 style here
                              Text('email.@mail.com',
                                  style: textStyle.text14(context)), // Use text14 style here
                            ],
                          ),
                          const SizedBox(height: 2.0),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Name:'.tr,
                                  style: textStyle.text14(context)), // Use text14 style here
                              Text('Invoice',
                                  style: textStyle.text14(context)), // Use text14 style here
                            ],
                          ),
                          const SizedBox(height: 2.0),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Balance:'.tr,
                                  style: textStyle.text14(context)), // Use text14 style here
                              Text('100',
                                  style: textStyle.text14(context)), // Use text14 style here
                            ],
                          ),
                          const SizedBox(height: 2.0),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
