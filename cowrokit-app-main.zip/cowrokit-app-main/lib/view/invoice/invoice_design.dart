import 'package:co_workit/controllers/invoice_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../constant/custom_text_style.dart';
import 'invoice_detail_design.dart';

class InvoiceScreen1 extends StatelessWidget {
  final InvoiceController invoiceController = Get.put(InvoiceController());

  InvoiceScreen1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    CustomTextStyles textStyle =
        CustomTextStyles(); // Initialize CustomTextStyles instance

    return Scaffold(
      body: Container(
        height: double.infinity,
        color: Theme.of(context).scaffoldBackgroundColor,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Obx(() {
              if (invoiceController.isLoading.value) {
                return const Center(child: CircularProgressIndicator());
              }
              return ListView.builder(
                itemCount: invoiceController.invoices.length,
                itemBuilder: (context, index) {
                  final invoice = invoiceController.invoices[index];
                  return GestureDetector(
                    onTap: () {
                      Get.to(() => InvoiceDetailScreen1(invoice: invoice));
                    },
                    child: Card(
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                            5.0), // Increased corner radius
                        side: BorderSide(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.grey[800] ?? Colors.grey
                              : Colors.grey[300] ?? Colors.grey,
                          // Adjust border color based on theme
                          width: 0.5,
                        ),
                      ),
                      shadowColor: Theme.of(context)
                          .shadowColor
                          .withOpacity(0.3), // Subtle drop shadow
                      margin: const EdgeInsets.symmetric(
                          vertical: 8.0,
                          horizontal: 4.0), // Add spacing between cards
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                CircleAvatar(
                                  radius: 37,
                                  backgroundColor: Get
                                      .theme
                                      .floatingActionButtonTheme
                                      .backgroundColor,
                                  child: CircleAvatar(
                                    radius: 35,
                                    backgroundImage:
                                        NetworkImage(invoice.avatar!),
                                  ),
                                ),

                                const SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    Text('#: '.tr,
                                        style: textStyle.text14(
                                            context)), // Use text14 style here
                                    Text(
                                        invoice.id != null
                                            ? invoice.id.toString()
                                            : '--',
                                        style: textStyle.text14(context)),
                                  ],
                                ), // Use text14 style here
                              ],
                            ),
                            const SizedBox(height: 20.0),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Icon(
                                  Icons.email_rounded,
                                  color: Get.theme.floatingActionButtonTheme
                                      .backgroundColor,
                                ),
                                // Text('email:'.tr,
                                //     style: textStyle.text14(
                                //         context)), // Use text14 style here

                                Text(invoice.email ?? '',
                                    style: textStyle.text14(
                                        context)), // Use text14 style here
                              ],
                            ),
                            const SizedBox(height: 2.0),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Icon(
                                  Icons.person_2_rounded,
                                  color: Get.theme.floatingActionButtonTheme
                                      .backgroundColor,
                                ),
                                // Text('Name:'.tr,
                                //     style: textStyle.text14(
                                //         context)), // Use text14 style here

                                Text(invoice.name ?? '',
                                    style: textStyle.text14(
                                        context)), // Use text14 style here
                              ],
                            ),
                            const SizedBox(height: 2.0),
                            Divider(
                              color: Get.theme.floatingActionButtonTheme
                                  .backgroundColor,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Icon(
                                  Icons.monetization_on_outlined,
                                  color: Get.theme.floatingActionButtonTheme
                                      .backgroundColor,
                                ),
                                // Text('Balance:'.tr,
                                //     style: textStyle.text14(
                                //         context)), // Use text14 style here

                                Text('${invoice.balance} Rs' ?? '',
                                    style: textStyle.text14(
                                        context)), // Use text14 style here
                              ],
                            ),
                            const SizedBox(height: 2.0),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              );
            }),
          ),
        ),
      ),
    );
  }
}
