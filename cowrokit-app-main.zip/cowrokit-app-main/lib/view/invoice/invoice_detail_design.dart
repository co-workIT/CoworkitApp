import 'package:co_workit/constant/custom_color.dart';
import 'package:co_workit/constant/custom_text_style.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../models/invoice_model_new.dart';

class InvoiceDetailScreen1 extends StatelessWidget {
  final Data invoice;

  InvoiceDetailScreen1({Key? key, required this.invoice}) : super(key: key);
  CustomTextStyles textStyle = CustomTextStyles();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white.withOpacity(0.9),
      appBar: AppBar(
        title: Icon(
          Icons.newspaper,
          size: 50,
        ),
        centerTitle: true,
        iconTheme: const IconThemeData(
          color: Colors.white,
        ),
        backgroundColor: const Color.fromRGBO(30, 168, 231, 1),
      ),
      body: Column(
        children: [
          Container(
            alignment: Alignment.center,
            width: double.infinity,
            height: 100,
            padding: const EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              color: Get.theme.floatingActionButtonTheme.backgroundColor,
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(40.0),
                bottomRight: Radius.circular(40.0),
              ),
            ),
            child: const Text(
              'Invoice Detail',
              style: TextStyle(color: Colors.white, fontSize: 20),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: SingleChildScrollView(
                child: Card(
                  color: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  elevation: 4,
                  shadowColor: CustomColor.shadowColor,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircleAvatar(
                              radius: 35,
                              backgroundImage: NetworkImage(
                                invoice.avatar ??
                                    'https://e7.pngegg.com/pngimages/993/650/png-clipart-user-profile-computer-icons-others-miscellaneous-black.png',
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Text('Invoice ID: #'.tr,
                                style: textStyle.text14n(context)),
                            Text(invoice.id != null ? '${invoice.id}' : '--',
                                style: textStyle.text14b(context)),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Text('Name: '.tr, style: TextStyle(fontSize: 12)),
                            Text(
                                invoice.name != null && invoice.name!.isNotEmpty
                                    ? '${invoice.name}'
                                    : '--',
                                style: const TextStyle(
                                    fontSize: 12, fontWeight: FontWeight.bold)),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            const Text('E-mail ',
                                style: TextStyle(fontSize: 12)),
                            Text(
                                invoice.email != null
                                    ? '${invoice.email}'
                                    : '--',
                                style: const TextStyle(
                                    fontSize: 12, fontWeight: FontWeight.bold)),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            const Text('Balance',
                                style: TextStyle(fontSize: 12)),
                            Text(
                                invoice.balance != null
                                    ? '${invoice.balance}'
                                    : '--',
                                style: const TextStyle(
                                    fontSize: 12, fontWeight: FontWeight.bold)),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            const Text('NTN : ',
                                style: TextStyle(fontSize: 12)),
                            Text(invoice.ntn != null ? '${invoice.ntn}' : '--',
                                style: const TextStyle(
                                    fontSize: 12, fontWeight: FontWeight.bold)),
                          ],
                        ),
                        const SizedBox(height: 30),
                        Row(
                          children: [
                            Text('Tax number: '.tr),
                            Text(
                                invoice.taxNumber != null
                                    ? '${invoice.taxNumber}'
                                    : '--',
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.bold)),
                            const SizedBox(width: 60.0),
                          ],
                        ),
                        Divider(
                          thickness: 2,
                          color: Get
                              .theme.floatingActionButtonTheme.backgroundColor,
                        ),
                        Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.monetization_on_rounded,
                                color: Get.theme.floatingActionButtonTheme
                                    .backgroundColor,
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                'Billings',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Get.theme.floatingActionButtonTheme
                                      .backgroundColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 10),
                        Divider(
                          thickness: 2,
                          color: Get
                              .theme.floatingActionButtonTheme.backgroundColor,
                        ),
                        buildRow(
                          'Name:'.tr,
                          invoice.billingName ?? '--',
                          context,
                          Icons.person,
                        ),
                        buildRow('City:'.tr, invoice.billingCity ?? '--',
                            context, Icons.location_city),
                        buildRow('Address:'.tr, invoice.billingAddress ?? '--',
                            context, Icons.place_rounded),
                        buildRow('State:'.tr, invoice.billingState ?? '--',
                            context, Icons.place_rounded),
                        buildRow('Phone:'.tr, invoice.billingPhone ?? '--',
                            context, Icons.phone),
                        buildRow('Postal code:'.tr, invoice.billingZip ?? '--',
                            context, Icons.local_post_office_rounded),
                        const Divider(),
                        Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.local_shipping_rounded,
                                color: Get.theme.floatingActionButtonTheme
                                    .backgroundColor,
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                'Shipping',
                                style: TextStyle(
                                  fontSize: 20,
                                  color: Get.theme.floatingActionButtonTheme
                                      .backgroundColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Divider(
                          thickness: 2,
                          color: Get
                              .theme.floatingActionButtonTheme.backgroundColor,
                        ),
                        buildRow('Name:'.tr, invoice.shippingName ?? '--',
                            context, Icons.person),
                        buildRow('City:'.tr, invoice.shippingCity ?? '--',
                            context, Icons.location_city_rounded),
                        buildRow('Address:'.tr, invoice.shippingAddress ?? '--',
                            context, Icons.place_rounded),
                        buildRow('State:'.tr, invoice.shippingState ?? '--',
                            context, Icons.place_rounded),
                        buildRow('Phone:'.tr, invoice.shippingPhone ?? '--',
                            context, Icons.phone),
                        buildRow('Postal code:'.tr, invoice.shippingZip ?? '--',
                            context, Icons.local_post_office_rounded),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildRow(
      String label, String value, BuildContext context, IconData icon) {
    CustomTextStyles textStyle = CustomTextStyles();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Icon(
            icon,
            color: Colors.black,
            size: 20,
          ),
          const SizedBox(
            width: 10,
          ),
          Text(label, style: textStyle.text14b(context)),
          Spacer(),
          Text(value, style: textStyle.text14n(context)),
        ],
      ),
    );
  }
}
