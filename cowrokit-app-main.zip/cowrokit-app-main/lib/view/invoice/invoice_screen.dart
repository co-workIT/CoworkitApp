// import 'package:adaptive_theme/adaptive_theme.dart';
// import 'package:co_workit/controllers/invoice_controller.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import '../../constant/custom_color.dart';
// import '../../constant/custom_text_style.dart';
// import 'invoice_detail_design.dart';
//
// class InvoiceScreen extends StatelessWidget {
//   final InvoiceController invoiceController = Get.put(InvoiceController());
//
//   InvoiceScreen({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     CustomTextStyles textStyle = CustomTextStyles(); // Initialize CustomTextStyles instance
//
//     return Scaffold(
//       body: Container(
//         height: double.infinity,
//         color: AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light ? CustomColor.backgroundColor: CustomColorDark.backgroundColor,
//         child: SafeArea(
//           child: Padding(
//             padding: EdgeInsets.all(16.0),
//             child: GetBuilder<InvoiceController>(
//               builder: (controller) {
//                 if (controller.invoices.isEmpty) {
//                   return Center(
//                     child: Text(
//                       'No invoices available',
//                       style: textStyle.text14n(context), // Use text14n style here
//                     ),
//                   );
//                 }
//                 return SingleChildScrollView(
//                   scrollDirection: Axis.horizontal,
//                   child: DataTable(
//                     headingTextStyle: textStyle.head18b(context),
//                     dataTextStyle: textStyle.text14n(context), // Use text14n style here
//                     columnSpacing: 20.0,
//                     horizontalMargin: 12.0,
//                     dividerThickness: 2.0,
//                     columns: [
//                       DataColumn(label: Text('Invoice #', style: textStyle.text14(context))), // Use text14 style here
//                       DataColumn(label: Text('Issue Date', style: textStyle.text14(context))), // Use text14 style here
//                       DataColumn(label: Text('Due Date', style: textStyle.text14(context))), // Use text14 style here
//                       DataColumn(label: Text('Due Amount', style: textStyle.text14(context))), // Use text14 style here
//                       DataColumn(label: Text('Status', style: textStyle.text14(context))), // Use text14 style here
//                       DataColumn(label: Text('Action', style: textStyle.text14(context))), // Use text14 style here
//                     ],
//                     rows: controller.invoices.map((invoice) {
//                       return DataRow(
//                         cells: [
//                           DataCell(Text(invoice.id.toString(), style: textStyle.text14(context))), // Use text14 style here
//                           DataCell(Text(invoice.issueDate.trim(), style: textStyle.text14(context))), // Use text14 style here
//                           DataCell(Text(invoice.dueDate.trim(), style: textStyle.text14(context))), // Use text14 style here
//                           DataCell(Text(invoice.dueAmount, style: textStyle.text14(context))), // Use text14 style here
//                           DataCell(
//                             Text(
//                               invoice.status,
//                               style: invoice.status == 'Paid'
//                                   ? textStyle.text14nPaid(context)
//                                   : textStyle.text14nUnpaid(context),
//                             ),
//
//                           ),
//                           DataCell(
//                             IconButton(
//                               onPressed: () {
//                                 Get.to(() => InvoiceDetailScreen1(invoice: invoice));
//                               },
//                               icon: Icon(Icons.remove_red_eye, color: CustomColor.appBarColor),
//                             ),
//                           ),
//                         ],
//                       );
//                     }).toList(),
//                   ),
//                 );
//               },
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
