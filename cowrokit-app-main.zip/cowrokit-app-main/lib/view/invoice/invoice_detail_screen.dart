import 'package:co_workit/constant/custom_color.dart';
import 'package:co_workit/constant/custom_text_style.dart';
import 'package:co_workit/models/invoice_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../models/invoice_model_new.dart';

class InvoiceDetailNew extends StatelessWidget {
  final Data invoice;

  InvoiceDetailNew({Key? key, required this.invoice}) : super(key: key);
  CustomTextStyles textStyle = CustomTextStyles();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white.withOpacity(0.9),
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.white,
        ),
        backgroundColor: const Color.fromRGBO(30, 168, 231, 1),
        title: Text('Invoice Details'.tr, style: textStyle.head18b(context)),
      ),
      body: Container(
        color: Theme.of(context).scaffoldBackgroundColor,
        height: double.infinity,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Card(
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                elevation: 4,
                shadowColor: CustomColor.shadowColor,
                child: Padding(
                  padding:
                  const EdgeInsets.symmetric(vertical: 15.0, horizontal: 15),
                  child: Center(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 35,
                              child: Image.network('https://media.istockphoto.com/id/1337144146/vector/default-avatar-profile-icon-vector.jpg?s=612x612&w=0&k=20&c=BIbFwuv7FxTWvh5S3vB6bkT0Qv8Vn8N5Ffseq84ClGI='),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Text('Invoice ID: #'.tr,
                                style: textStyle.text14n(context)),
                            Text('01'.tr,
                                style: textStyle.text14b(context)),
                          ],
                        ),
                        SizedBox(height: 10,),
                        Row(
                          children: [
                            Text('Name: '.tr,
                                style: TextStyle(fontSize: 12)),
                            Text('InvoiceName',
                                style: const TextStyle(
                                    fontSize: 12, fontWeight: FontWeight.bold)),

                          ],
                        ),
                        SizedBox(height: 10,),
                        Row(children: [
                          const Text('E-mail ',
                              style: TextStyle(fontSize: 12)),
                          Text('email@mail.com',
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.bold)),
                        ],),
                        SizedBox(height: 10,),
                        Row(children: [
                          const Text('Balance',
                              style: TextStyle(fontSize: 12)),
                          Text('1003',
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.bold)),
                        ],),
                        SizedBox(height: 10,),
                        Row(children: [
                          const Text('NTN : ',
                              style: TextStyle(fontSize: 12)),
                          Text('102940389437304',
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.bold)),
                        ],),
                        const SizedBox(height: 30),
                        Row(
                          children: [
                            Text('tax number: '.tr),
                            Text('${invoice.taxNumber}',
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.bold)),
                            const SizedBox(width: 60.0),
                          ],
                        ),

                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Column(
                    children: [
                      Card(
                        color: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        elevation: 4,
                        shadowColor: CustomColor.shadowColor,
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Center(
                                  child: Text('Billings',style: TextStyle(fontSize: 20),)),
                              const Divider(),
                              // buildRow('Invoice: ', '#${invoice.detailId}', context),
                              buildRow('Name:'.tr, '${invoice.billingName}', context),
                              buildRow('City:'.tr, '${invoice.billingCity}', context),
                              buildRow('Address:'.tr, '${invoice.billingAddress}', context),
                              buildRow('State:'.tr, '${invoice.billingState}', context),
                              buildRow('Phone:'.tr, '${invoice.billingPhone}', context),
                              buildRow('Postal code:'.tr, '${invoice.billingZip}', context),
                            ],
                          ),
                        ),
                      ),
                      Card(
                        color: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        elevation: 4,
                        shadowColor: CustomColor.shadowColor,
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Center(
                                  child: Text('Shipping',style: TextStyle(fontSize: 20),)),

                              const Divider(),
                              // buildRow('Invoice: ', '#${invoice.detailId}', context),
                              buildRow('Name:'.tr, '${invoice.shippingName}', context),
                              buildRow('City:'.tr, '${invoice.shippingCity}', context),
                              buildRow('Address:'.tr, '${invoice.shippingAddress}', context),
                              buildRow('State:'.tr, '${invoice.shippingState}', context),
                              buildRow('Phone:'.tr, '${invoice.shippingPhone}', context),
                              buildRow('Postal code:'.tr, '${invoice.shippingZip}', context),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }

  Widget buildRow(String label, String value, BuildContext context) {
    CustomTextStyles textStyle = CustomTextStyles();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: textStyle.text14b(context)),
          Text(value, style: textStyle.text14b(context)),
        ],
      ),
    );
  }
}
