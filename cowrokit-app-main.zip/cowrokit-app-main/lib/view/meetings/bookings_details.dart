import 'package:co_workit/controllers/bookings_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BookingEditView extends StatelessWidget {
  final BookingController bookingController = Get.put(BookingController());

  final TextEditingController spaceIdController = TextEditingController();
  final TextEditingController userIdController = TextEditingController();
  final TextEditingController startDateController = TextEditingController();
  final TextEditingController endDateController = TextEditingController();

  final int companyId;

  BookingEditView({required this.companyId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Booking'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: spaceIdController,
              decoration: InputDecoration(labelText: 'Space ID'),
            ),
            TextField(
              controller: userIdController,
              decoration: InputDecoration(labelText: 'User ID'),
            ),
            TextField(
              controller: startDateController,
              decoration: InputDecoration(labelText: 'Start Date'),
            ),
            TextField(
              controller: endDateController,
              decoration: InputDecoration(labelText: 'End Date'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                bookingController.editBooking(
                  companyId.toString(),
                  spaceIdController.text,
                  userIdController.text,
                  startDateController.text,
                  endDateController.text,
                );
              },
              child: Text('Edit Booking'),
            ),
            ElevatedButton(
              onPressed: () {
                bookingController.updateBooking(
                  companyId.toString(),
                  spaceIdController.text,
                  userIdController.text,
                  startDateController.text,
                  endDateController.text,
                );
              },
              child: Text('Update Booking'),
            ),
          ],
        ),
      ),
    );
  }
}
