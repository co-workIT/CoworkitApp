// import 'package:co_workit/controllers/bookings_controller.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
//
//
// class BookingPage extends StatelessWidget {
//   final BookingController bookingController = Get.put(BookingController());
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Obx(() {
//         if (bookingController.isLoading.value) {
//           return Center(child: CircularProgressIndicator());
//         } else {
//           return ListView.builder(
//             itemCount: bookingController.bookingList.length,
//             itemBuilder: (context, index) {
//               var booking = bookingController.bookingList[index];
//               return ListTile(
//                 title: Text('Booking ID: ${booking.id}'),
//                 subtitle: Text('Start Date: ${booking.startDate}, End Date: ${booking.endDate}'),
//               );
//             },
//           );
//         }
//       }),
//     );
//   }
// }
