import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../constant/custom_text_style.dart';
import '../../controllers/meetings_controller.dart';
import 'meeting_detailed.dart';

class MeetingView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final MeetingController controller = Get.put(MeetingController());
    final CustomTextStyles textStyle = CustomTextStyles();

    return Scaffold(
      body: SafeArea(
        child: Card(
          elevation: 0,
          color: Colors.white,
          child: Column(
            children: [
              Obx(() {
                return Card(
                  elevation: 10,
                  shadowColor: Colors.black.withOpacity(0.6),
                  color: Get.theme.floatingActionButtonTheme
                      .backgroundColor, // Background color for the calendar
                  child: TableCalendar(
                    rowHeight: 40,
                    firstDay: DateTime(2000),
                    lastDay: DateTime(2100),
                    availableCalendarFormats: const {
                      CalendarFormat.month: 'Month',
                      CalendarFormat.twoWeeks: '2 weeks',
                      CalendarFormat.week: 'Week'
                    },
                    daysOfWeekStyle: const DaysOfWeekStyle(
                      weekendStyle: TextStyle(
                        color: Colors.redAccent,
                        fontWeight: FontWeight.bold,
                      ),
                      weekdayStyle: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    calendarStyle: const CalendarStyle(
                      todayDecoration: BoxDecoration(
                        color: Colors.yellowAccent,
                        shape: BoxShape.circle,
                      ),
                      selectedDecoration: BoxDecoration(
                        color: Colors.blueAccent,
                        shape: BoxShape.circle,
                      ),
                      markerDecoration: BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                      weekendTextStyle: TextStyle(
                        color: Colors.redAccent,
                      ),
                      holidayTextStyle: TextStyle(
                        color: Colors.blueAccent,
                      ),
                    ),
                    headerStyle: HeaderStyle(
                      formatButtonVisible: false,
                      titleCentered: true,
                      formatButtonShowsNext: false,
                      titleTextStyle: const TextStyle(
                        color: Colors.white,
                        fontSize: 20.0,
                        fontWeight: FontWeight.bold,
                      ),
                      leftChevronIcon: Container(
                        decoration: const BoxDecoration(
                          color: Colors.blue,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.chevron_left,
                          color: Colors.white, // Icon color
                        ),
                      ),
                      rightChevronIcon: Container(
                        decoration: const BoxDecoration(
                          color: Colors.blue,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.chevron_right,
                          color: Colors.white, // Icon color
                        ),
                      ),
                    ),
                    focusedDay: controller.selectedDate.value,
                    selectedDayPredicate: (day) {
                      return isSameDay(controller.selectedDate.value, day);
                    },
                    onDaySelected: (selectedDay, focusedDay) {
                      controller.selectedDate.value = selectedDay;
                      controller.filterMeetingsByDate(selectedDay);
                    },
                    calendarBuilders: CalendarBuilders(
                      defaultBuilder: (context, day, focusedDay) {
                        final dateStr = DateFormat('yyyy-MM-dd').format(day);
                        final hasMeeting =
                            controller.datesWithMeetings.contains(dateStr);
                        return Stack(
                          children: [
                            if (hasMeeting)
                              Positioned(
                                bottom: 1,
                                right: 1,
                                child: Container(
                                  width: 6,
                                  height: 6,
                                  decoration: const BoxDecoration(
                                    color: Colors.red, // Dot color
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              ),
                            Center(
                              child: Text(
                                '${day.day}',
                                style: TextStyle(
                                  color: day.weekday == DateTime.saturday ||
                                          day.weekday == DateTime.sunday
                                      ? Colors.redAccent
                                      : Colors.black,
                                  fontWeight:
                                      day.weekday == DateTime.saturday ||
                                              day.weekday == DateTime.sunday
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                      dowBuilder: (context, day) {
                        final text = DateFormat.E().format(day);
                        return Center(
                          child: Text(
                            text,
                            style: TextStyle(
                              color: day.weekday == DateTime.saturday ||
                                      day.weekday == DateTime.sunday
                                  ? Colors.redAccent
                                  : Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                );
              }),
              Expanded(
                child: Obx(() {
                  if (controller.isLoading.value) {
                    return const Center(child: CircularProgressIndicator());
                  } else if (controller.filteredMeetings.isEmpty) {
                    return Center(
                        child: Image.asset(
                      'assets/images/No Meetings for this Day!.png',
                      filterQuality: FilterQuality.low,
                    )
                        // Text(
                        //   'No meetings available on this date'.tr,
                        //   style: textStyle.text14n(context),
                        // ),
                        );
                  } else {
                    return Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: ListView.builder(
                        itemCount: controller.filteredMeetings.length,
                        itemBuilder: (context, index) {
                          var meeting = controller.filteredMeetings[index];
                          return GestureDetector(
                            onTap: () {
                              Get.to(MeetingDetailed(
                                  meeting: controller.filteredMeetings[index]));
                            },
                            child: Card(
                              color: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5.0),
                                side: BorderSide(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.grey[800] ?? Colors.grey
                                      : Colors.grey[300] ?? Colors.grey,
                                  width: 0.5,
                                ),
                              ),
                              shadowColor: Theme.of(context)
                                  .shadowColor
                                  .withOpacity(0.3),
                              margin: const EdgeInsets.symmetric(vertical: 8.0),
                              child: ListTile(
                                contentPadding: const EdgeInsets.all(16.0),
                                leading: ImageIcon(
                                  const AssetImage('assets/icons/meeting.png'),
                                  size: 40,
                                  color: Get.theme.floatingActionButtonTheme
                                      .backgroundColor,
                                ),
                                title: Text(
                                  meeting.name ?? 'No Name',
                                  style: textStyle.head18bw(
                                      context), // Use text16 style for titles
                                ),
                                subtitle: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Capacity: ${meeting.capacity}',
                                      style: textStyle.text14(
                                          context), // Use text14 style for subtitles
                                    ),
                                    Text(
                                      'Price: ${meeting.price}',
                                      style: textStyle.text14(
                                          context), // Use text14 style for subtitles
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    );
                  }
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
