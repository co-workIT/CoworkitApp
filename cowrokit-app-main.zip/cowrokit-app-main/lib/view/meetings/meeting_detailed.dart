import 'package:co_workit/constant/custom_button.dart';
import 'package:co_workit/constant/custom_color.dart';
import 'package:co_workit/constant/custom_text_style.dart';
import 'package:co_workit/controllers/bookings_controller.dart';
import 'package:co_workit/models/meeting_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import 'booking_dailouge.dart';

class MeetingDetailed extends StatefulWidget {
  final Data meeting;

  MeetingDetailed({Key? key, required this.meeting}) : super(key: key);

  @override
  _MeetingDetailedState createState() => _MeetingDetailedState();
}

class _MeetingDetailedState extends State<MeetingDetailed> {
  final CustomTextStyles textStyle = CustomTextStyles();
  bool _showRelatedBookings = false;

  final BookingController bookingController = Get.put(BookingController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white.withOpacity(0.9),
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: const Color.fromRGBO(30, 168, 231, 1),
        title: Text('Meeting Details'.tr, style: textStyle.head18b(context)),
      ),
      body: Container(
        color: Theme.of(context).scaffoldBackgroundColor,
        height: double.infinity,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildMeetingDetailsCard(),
                const SizedBox(height: 20),
                Container(
                  alignment: Alignment.center,
                  child: CustomButton(
                    backgroundColor:
                        Get.theme.floatingActionButtonTheme.backgroundColor,
                    width: 250,
                    onPressed: () {
                      setState(() {
                        _showRelatedBookings = !_showRelatedBookings;
                        if (_showRelatedBookings) {
                          bookingController.fetchBookings(
                              id: widget.meeting.id!);
                        }
                      });
                    },
                    text: _showRelatedBookings
                        ? 'Hide Related Bookings'
                        : 'Show Related Bookings',
                  ),
                ),
                const SizedBox(height: 20),
                if (_showRelatedBookings)
                  _buildRelatedBookings()
                else
                  Text('No bookings Yet!'),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMeetingDetailsCard() {
    return GestureDetector(
      onLongPress: () {
        showModalBottomSheet(
          context: context,
          builder: (BuildContext context) {
            return Wrap(
              children: [
                ListTile(
                  leading: Icon(Icons.edit),
                  title: Text('Edit Booking'),
                  onTap: () {
                    Navigator.pop(context);
                    _showEditBookingDialog();
                  },
                ),
                ListTile(
                  leading: Icon(Icons.update),
                  title: Text('Update Booking'),
                  onTap: () {
                    Navigator.pop(context);
                    _showUpdateBookingDialog();
                  },
                ),
              ],
            );
          },
        );
      },
      child: Card(
        color: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
        elevation: 4,
        shadowColor: CustomColor.shadowColor,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildDetailRow('Meeting Id:', widget.meeting.id.toString()),
              _buildDetailRow('Name:', widget.meeting.name!.toUpperCase()),
              const Divider(),
              _buildDateTimeRow(
                'Date:',
                'Time:',
                widget.meeting.createdAt!,
              ),
              const Divider(),
              _buildDetailRow('Price:', '${widget.meeting.price!} Rs'),
              _buildDescriptionRow('Description:', widget.meeting.description!),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Text(
            '$label ',
            style: textStyle.head16b(context),
          ),
          Text(value ?? '', style: textStyle.head16n(context)),
        ],
      ),
    );
  }

  Widget _buildDateTimeRow(
      String dateLabel, String timeLabel, String dateTime) {
    final date = DateTime.parse(dateTime);
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Text(
              dateLabel,
              style: textStyle.head16b(context),
            ),
            Text(DateFormat('yyyy-MM-dd').format(date),
                style: textStyle.head16n(context)),
          ],
        ),
        Row(
          children: [
            Text(
              timeLabel,
              style: textStyle.head16b(context),
            ),
            Text(DateFormat('hh:mm:ss a').format(date),
                style: textStyle.head16n(context)),
          ],
        ),
      ],
    );
  }

  Widget _buildDescriptionRow(String label, String description) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: SelectableText('$label\n$description',
                style: textStyle.head16n(context)),
          ),
        ],
      ),
    );
  }

  Widget _buildRelatedBookings() {
    return Obx(() {
      if (bookingController.isLoading.value) {
        return const Center(child: CircularProgressIndicator());
      } else if (bookingController.bookingList.isEmpty) {
        return const Center(child: Text('No related bookings found.'));
      } else {
        return SizedBox(
          height: 150, // Adjust height as needed
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: bookingController.bookingList.length,
            itemBuilder: (context, index) {
              final booking = bookingController.bookingList[index];
              return Container(
                width: 200, // Adjust width as needed
                margin: const EdgeInsets.only(right: 5),
                child: Card(
                  color: Get.theme.floatingActionButtonTheme.backgroundColor
                      ?.withOpacity(0.6),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  elevation: 4,
                  shadowColor: CustomColor.shadowColor,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 8.0, horizontal: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Row(
                          children: [
                            ImageIcon(AssetImage('assets/icons/booking.png'))
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Booking Id: ',
                              style: textStyle.text14b(context),
                            ),
                            Text(
                              '${booking.id}',
                              style: textStyle.text14b(context),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'User: ',
                              style: textStyle.text14n(context),
                            ),
                            Text(
                              '${booking.user?.name ?? 'N/A'}',
                              style: textStyle.text14n(context),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Start: ',
                              style: textStyle.text14n(context),
                            ),
                            Text(
                              '${DateFormat('yyyy-MM-dd').format(DateTime.parse(booking.startDate!))}',
                              style: textStyle.text14n(context),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'End: ',
                              style: textStyle.text14n(context),
                            ),
                            Text(
                              '${DateFormat('yyyy-MM-dd').format(DateTime.parse(booking.endDate!))}',
                              style: textStyle.text14n(context),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        );
      }
    });
  }

  void _showEditBookingDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return BookingDialog(
          title: 'Edit Booking',
          onSubmit: (spaceId, userId, startDate, endDate) {
            bookingController.editBooking(
                '1', spaceId, userId, startDate, endDate);
          },
        );
      },
    );
  }

  void _showUpdateBookingDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return BookingDialog(
          title: 'Update Booking',
          onSubmit: (spaceId, userId, startDate, endDate) {
            bookingController.updateBooking(
                '1', spaceId, userId, startDate, endDate);
          },
        );
      },
    );
  }
}
