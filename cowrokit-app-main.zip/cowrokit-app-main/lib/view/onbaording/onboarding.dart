import 'package:co_workit/view/bottom_bar/new_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:onboarding_screen/onboarding_screen.dart';
import 'package:co_workit/models/onbaording_model.dart';

class OnBoarding extends StatelessWidget {
  final List<SliderModel> mySlides = [
    SliderModel(
      imageAssetPath: Image.asset('assets/images/onboarding3.png'),
      title: 'Welcome to Cowork it',
      desc:
          'Discover a new way to enhance your []. Join us on a journey to simplify and elevate your [related activity] experience.',
      descStyle: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w400,
        color: Colors.white,
      ),
      titleStyle: const TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w400,
        color: Colors.white,
      ),
    ),
    SliderModel(
      imageAssetPath: Image.asset(
        'assets/images/onboarding4.png',
        fit: BoxFit.fill,
      ),
      title: 'Easy Navigation',
      desc:
          'Our intuitive interface ensures you find what you need quickly. Navigate through the app effortlessly and make the most out of its features.',
      descStyle: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w400,
        color: Colors.white,
      ),
      titleStyle: const TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w400,
        color: Colors.white,
      ),
    ),
    SliderModel(
      imageAssetPath: Image.asset('assets/images/onboarding2.png'),
      title: 'Personalized Experience',
      desc:
          'Customize your app settings to match your preferences. Enjoy a personalized experience tailored just for you.',
      descStyle: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w400,
        color: Colors.white,
      ),
      titleStyle: const TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w400,
        color: Colors.white,
      ),
    ),
    SliderModel(
      imageAssetPath: Image.asset('assets/images/onboarding1.png'),
      title: 'Get Started Now!',
      desc:
          'You’re all set! Dive into Coworkit and explore all the amazing features waiting for you. Enjoy your journey!',
      descStyle: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w400,
        color: Colors.white,
      ),
      titleStyle: const TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w400,
        color: Colors.white,
      ),
    ),
  ];
  final PageController _controller = PageController();

  @override
  Widget build(BuildContext context) {
    return OnBoardingScreen(
      label: const Text(
        'Get Started',
        style: TextStyle(
          fontSize: 22,
          fontWeight: FontWeight.bold,
          color: Color.fromRGBO(30, 168, 231, 1),
        ),
      ),

      /// This function works when you will complete `OnBoarding`
      function: () {
        Get.to(BottomBar());
      },

      /// This [mySlides] must not be more than 5.
      mySlides: mySlides,
      controller: _controller,
      slideIndex: 0,
      statusBarColor: const Color.fromRGBO(30, 168, 231, 1),
      startGradientColor: const Color.fromRGBO(30, 168, 231, 1),
      endGradientColor: Colors.white,
      skipStyle: const TextStyle(color: Colors.white),
      pageIndicatorColorList: const [
        Colors.white,
        Colors.white,
        Colors.white,
        Colors.white,
        Colors.white
      ],
    );
  }
}
