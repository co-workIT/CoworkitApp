import 'package:co_workit/constant/custom_color.dart';
import 'package:co_workit/constant/custom_text_style.dart';
import 'package:co_workit/controllers/auth_controller.dart';
import 'package:co_workit/controllers/theme_controllers.dart';
import 'package:co_workit/view/invoice/invoice_design.dart';
import 'package:co_workit/view/mailing/mailing_screen.dart';
import 'package:co_workit/view/meetings/meeting_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_advanced_drawer/flutter_advanced_drawer.dart';
import 'package:get/get.dart';
import 'package:salomon_bottom_bar/salomon_bottom_bar.dart';

import '../profile/profile_screen.dart';
import '../settings/setting.dart';

class BottomBar extends StatefulWidget {
  @override
  _BottomBarState createState() => _BottomBarState();
}

class _BottomBarState extends State<BottomBar> {
  final _advancedDrawerController = AdvancedDrawerController();
  final ThemeController themeController = Get.find();
  // final AuthService authService = Get.find();
  final authService = Get.put(AuthService());
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    InvoiceScreen1(),
    // BookingScreen(),
    MailingScreen(),
    // VisitorScreen(),
    MeetingView(),
    // BookingPage(),
  ];

  final List<String> _titles = [
    'Invoices',
    // 'Bookings',
    'Mailing',
    // 'Visitors',
    'Meetings',
    // 'Bookings',
  ];
  final List<Locale> supportedLocales = [
    const Locale('en', 'US'),
    const Locale('ar', 'SA'),
    const Locale('es', 'ES'),
  ];

  final Map<String, String> languageMap = {
    'en_US': 'Eng',
    'ar_SA': 'Ar',
    'es_ES': 'Es',
  };

  // void _onItemTapped(int index) {
  //   setState(() {
  //     _selectedIndex = index;
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    CustomTextStyles textStyle = CustomTextStyles();
    return AdvancedDrawer(
      backdropColor: const Color.fromRGBO(30, 168, 231, 1),
      backdrop: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.blueGrey, Colors.blueGrey.withOpacity(0.2)],
          ),
        ),
      ),
      controller: _advancedDrawerController,
      animationCurve: Curves.easeInOut,
      animationDuration: const Duration(milliseconds: 300),
      animateChildDecoration: true,
      rtlOpening: false,
      childDecoration: const BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(16)),
      ),
      drawer: SafeArea(
        child: ListTileTheme(
          textColor: CustomColor.textColorWhite,
          iconColor: CustomColor.textColorWhite,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Center(
                child: GestureDetector(
                  onTap: () {
                    // Handle image update
                  },
                  child: const CircleAvatar(
                    radius: 50,
                    backgroundImage: NetworkImage(
                      "https://firebasestorage.googleapis.com/v0/b/final-year-project-b1601.appspot.com/o/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa%2FCoworkit-2%201.png?alt=media&token=a3372457-11c3-484b-ab92-ba2a9842b7c0",
                    ),
                  ),
                ),
              ),
              ListTile(
                onTap: () {},
                leading:
                    const Icon(Icons.home, color: CustomColor.iconColorWhite),
                title: Text('Home'.tr, style: textStyle.text16b400(context)),
              ),
              ListTile(
                onTap: () {
                  // Get.to(() => ProfileScreen());
                  Get.to(() => ProfileScreen());
                },
                leading: const Icon(Icons.account_circle_rounded,
                    color: CustomColor.iconColorWhite),
                title: Text('Profile'.tr, style: textStyle.text16b400(context)),
              ),
              ListTile(
                onTap: () {},
                leading: const Icon(Icons.favorite,
                    color: CustomColor.iconColorWhite),
                title:
                    Text('Favourites'.tr, style: textStyle.text16b400(context)),
              ),
              ListTile(
                onTap: () {
                  Get.to(SettingsPage());
                },
                leading: const Icon(Icons.settings,
                    color: CustomColor.iconColorWhite),
                title:
                    Text('Settings'.tr, style: textStyle.text16b400(context)),
              ),
              ListTile(
                title: Text('Theme'.tr, style: textStyle.text16b400(context)),
                leading: Icon(
                  Get.isDarkMode ? Icons.light_mode : Icons.dark_mode,
                  color: Colors.white,
                ),
                onTap: () {
                  themeController.switchTheme();
                },
              ),
              ListTile(
                onTap: () {
                  //logout
                  authService.logout();
                },
                leading:
                    const Icon(Icons.logout, color: CustomColor.iconColorWhite),
                title: Text('Logout'.tr, style: textStyle.text16b400(context)),
              ),
              const Spacer(),
              DefaultTextStyle(
                style: const TextStyle(
                  fontSize: 12,
                  color: CustomColor.textDefaultColor,
                ),
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 16.0),
                  child: const Text(''),
                ),
              ),
            ],
          ),
        ),
      ),
      child: Scaffold(
        appBar: AppBar(
          title: Text(_titles[_selectedIndex].tr,
              style: textStyle.head18b(context)),
          backgroundColor: !Get.isDarkMode
              ? const Color.fromRGBO(30, 168, 231, 1)
              : Colors.black,
          leading: IconButton(
            onPressed: _handleMenuButtonPressed,
            icon: ValueListenableBuilder<AdvancedDrawerValue>(
              valueListenable: _advancedDrawerController,
              builder: (_, value, __) {
                return AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  child: Icon(
                    value.visible ? Icons.clear : Icons.menu,
                    color: Colors.white,
                    key: ValueKey<bool>(value.visible),
                  ),
                );
              },
            ),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: DropdownButton<Locale>(
                value: Get.locale,
                icon: const Icon(
                  Icons.language,
                  color: Colors.white,
                ),
                dropdownColor:
                    Theme.of(context).floatingActionButtonTheme.backgroundColor,
                underline: const SizedBox(),
                onChanged: (Locale? newLocale) {
                  if (newLocale != null) {
                    Get.updateLocale(newLocale);
                  }
                },
                items: supportedLocales.map((Locale locale) {
                  return DropdownMenuItem<Locale>(
                    value: locale,
                    child: Text(
                      languageMap[locale.toString()] ?? '',
                      style: const TextStyle(color: Colors.white),
                    ),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
        body: _screens[_selectedIndex],
        bottomNavigationBar: SalomonBottomBar(
          backgroundColor: Get.isDarkMode
              ? Colors.black
              : const Color.fromRGBO(30, 168, 231, 1),
          currentIndex: _selectedIndex,
          onTap: (i) => setState(() => _selectedIndex = i),
          items: [
            SalomonBottomBarItem(
              icon: const Icon(Icons.home_outlined, color: Colors.white),
              title: const Text("Home"),
              selectedColor: Colors.white,
            ),
            // SalomonBottomBarItem(
            //   icon: const Icon(
            //     Icons.book_outlined,
            //     color: Colors.white,
            //   ),
            //   title: const Text("Bookings"),
            //   selectedColor: Colors.white,
            // ),
            SalomonBottomBarItem(
              icon: const Icon(
                Icons.mail_outline,
                color: Colors.white,
              ),
              title: const Text("Mailings"),
              selectedColor: Colors.white,
            ),
            // SalomonBottomBarItem(
            //   icon: const Icon(
            //     Icons.person_2_outlined,
            //     color: Colors.white,
            //   ),
            //   title: const Text("Visitors"),
            //   selectedColor: Colors.white,
            // ),
            SalomonBottomBarItem(
              icon: const Icon(
                Icons.meeting_room,
                color: Colors.white,
              ),
              title: const Text("Meetings"),
              selectedColor: Colors.white,
            ),
            // SalomonBottomBarItem(
            //   icon: const Icon(
            //     Icons.book_outlined,
            //     color: Colors.white,
            //   ),
            //   title: const Text("Bookings"),
            //   selectedColor: Colors.white,
            // ),
          ],
        ),
      ),
    );
  }

  void _handleMenuButtonPressed() {
    _advancedDrawerController.showDrawer();
  }
}
