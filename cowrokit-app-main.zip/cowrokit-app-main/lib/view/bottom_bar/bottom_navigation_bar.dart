// import 'package:adaptive_theme/adaptive_theme.dart';
// import 'package:co_workit/view/mailing/mailing_screen.dart';
// import 'package:co_workit/view/profile/profile_screen.dart';
// import 'package:flutter/material.dart';
// import 'package:co_workit/view/visitors/visitor_screen.dart';
// import 'package:co_workit/view/booking/booking_screen.dart';
// import 'package:flutter_advanced_drawer/flutter_advanced_drawer.dart';
// import 'package:get/get.dart';
// import 'package:co_workit/constant/custom_color.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
//
// import '../../constant/custom_text_style.dart';
// import '../invoice/invoice_design.dart';
//
// class BottomBar extends StatefulWidget {
//   @override
//   _BottomBarState createState() => _BottomBarState();
// }
//
// class _BottomBarState extends State<BottomBar> {
//   final _advancedDrawerController = AdvancedDrawerController();
//   int _selectedIndex = 0;
//
//   final List<Widget> _screens = [
//     InvoiceScreen1(),
//     // InvoiceScreen(),
//     BookingScreen(),
//     MailingScreen(),
//     VisitorScreen(),
//   ];
//   final List<String> _titles = [
//     'Invoices',
//     'Bookings',
//     'Mailing',
//     'Visitors',
//   ];
//
//   void _onItemTapped(int index) {
//     setState(() {
//       _selectedIndex = index;
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     CustomTextStyles textStyle =CustomTextStyles();
//     return AdvancedDrawer(
//       backdropColor: CustomColor.SplashScreen,
//       backdrop: Container(
//         width: double.infinity,
//         height: double.infinity,
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//             begin: Alignment.topLeft,
//             end: Alignment.bottomRight,
//             colors: [Colors.blueGrey, Colors.blueGrey.withOpacity(0.2)],
//           ),
//         ),
//       ),
//       controller: _advancedDrawerController,
//       animationCurve: Curves.easeInOut,
//       animationDuration: const Duration(milliseconds: 300),
//       animateChildDecoration: true,
//       rtlOpening: false,
//       // openScale: 1.0,
//       disabledGestures: false,
//       childDecoration: const BoxDecoration(
//         borderRadius: BorderRadius.all(Radius.circular(16)),
//       ),
//       drawer: SafeArea(
//         child: Container(
//           child: ListTileTheme(
//             textColor: CustomColor.textColorWhite,
//             iconColor: CustomColor.textColorWhite,
//             child: Column(
//
//               mainAxisSize: MainAxisSize.max,
//               children: [
//                 Center(
//                   child: GestureDetector(
//                     onTap: () {
//                       // Handle image update
//                       // Implement your image update logic here
//                     },
//                     child: const CircleAvatar(
//                         radius: 50,
//                         backgroundImage: NetworkImage("https://firebasestorage.googleapis.com/v0/b/final-year-project-b1601.appspot.com/o/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa%2FCoworkit-2%201.png?alt=media&token=a3372457-11c3-484b-ab92-ba2a9842b7c0")
//                     ),
//                   ),
//                 ),
//                 ListTile(
//                   onTap: () {},
//                   leading: const Icon(Icons.home, color: CustomColor.iconColorWhite),
//                   title: Text('Home', style: CustomTextStyles().text16b400(context)),
//                 ),
//                 ListTile(
//                   onTap: () {
//                     Get.to(() => ProfileScreen());
//                   },
//                   leading: const Icon(Icons.account_circle_rounded, color: CustomColor.iconColorWhite),
//                   title: Text('Profile', style: CustomTextStyles().text16b400(context)),
//                 ),
//                 ListTile(
//                   onTap: () {},
//                   leading: const Icon(Icons.favorite, color: CustomColor.iconColorWhite),
//                   title: Text('Favourites', style: CustomTextStyles().text16b400(context)),
//                 ),
//                 ListTile(
//                   onTap: () {},
//                   leading: const Icon(Icons.settings, color: CustomColor.iconColorWhite),
//                   title: Text('Settings', style: CustomTextStyles().text16b400(context)),
//                 ),
//                 const Spacer(),
//                 DefaultTextStyle(
//                   style: const TextStyle(
//                     fontSize: 12,
//                     color: CustomColor.textDefaultColor,
//                   ),
//                   child: Container(
//                     margin: const EdgeInsets.symmetric(vertical: 16.0),
//                     child: const Text(''),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//       child: Scaffold(
//         appBar: AppBar(
//           title: Text(_titles[_selectedIndex], style:textStyle.head18b(context)),
//           backgroundColor: AdaptiveTheme.of(context).mode == AdaptiveThemeMode.dark? CustomColor.iconColor: CustomColorDark.iconColorWhite,
//           leading: IconButton(
//             onPressed: _handleMenuButtonPressed,
//
//             icon: ValueListenableBuilder<AdvancedDrawerValue>(
//               valueListenable: _advancedDrawerController,
//               builder: (_, value, __) {
//                 return AnimatedSwitcher(
//                   duration: const Duration(milliseconds: 250),
//                   child: Icon(
//                     value.visible ? Icons.clear : Icons.menu,
//                     color: AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light? CustomColor.iconColor: CustomColorDark.iconColorWhite,
//                     key: ValueKey<bool>(value.visible),
//                   ),
//                 );
//               },
//             ),
//           ),
//           actions: [
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 10.0),
//               child: IconButton(onPressed: ()=>
//               AdaptiveTheme.of(context).mode == AdaptiveThemeMode.dark
//                   ? AdaptiveTheme.of(context).setLight()
//                   : AdaptiveTheme.of(context).setDark(),
//                   icon: AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light
//                       ? const Icon(Icons.dark_mode)
//                       : const Icon(Icons.light_mode)),
//             )
//           ],
//         ),
//         body: _screens[_selectedIndex],
//         bottomNavigationBar: BottomNavigationBar(
//           type: BottomNavigationBarType.fixed,
//           backgroundColor: AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light? CustomColor.backgroundColor: CustomColorDark.backgroundColor,
//           showSelectedLabels: false,
//           showUnselectedLabels: false,
//           selectedItemColor:  AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light? CustomColor.iconColor: CustomColorDark.iconColorWhite,
//           items:  <BottomNavigationBarItem>[
//             BottomNavigationBarItem(
//               icon: _selectedIndex==0 ? FaIcon(Icons.home_rounded, color:  AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light? CustomColor.iconColor: CustomColorDark.iconColorWhite)
//                   :Icon(Icons.home_outlined, color:  AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light? CustomColor.iconColor: CustomColorDark.iconColorWhite),
//               label: 'Home',
//             ),
//             BottomNavigationBarItem(
//               icon: _selectedIndex==1 ?Icon(Icons.book, color:  AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light? CustomColor.iconColor: CustomColorDark.iconColorWhite)
//                   :Icon(Icons.book_outlined, color:  AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light? CustomColor.iconColor: CustomColorDark.iconColorWhite),
//               label: 'Booking',
//             ),
//             BottomNavigationBarItem(
//               icon: _selectedIndex==2?Icon(Icons.mail,color:  AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light? CustomColor.iconColor: CustomColorDark.iconColorWhite)
//                   :Icon(Icons.mail_outline,color:  AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light? CustomColor.iconColor: CustomColorDark.iconColorWhite),
//               label: 'Mailing',
//             ),
//             BottomNavigationBarItem(
//               icon:_selectedIndex==3?Icon(Icons.people,color:  AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light? CustomColor.iconColor: CustomColorDark.iconColorWhite)
//                   :Icon(Icons.people_outline,color:  AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light? CustomColor.iconColor: CustomColorDark.iconColorWhite),
//               label: 'Visitor',
//             ),
//           ],
//           currentIndex: _selectedIndex,
//           unselectedItemColor: CustomColor.unselectedItemColor,
//           onTap: _onItemTapped,
//         ),
//       ),
//     );
//   }
//
//   void _handleMenuButtonPressed() {
//     _advancedDrawerController.showDrawer();
//   }
// }
