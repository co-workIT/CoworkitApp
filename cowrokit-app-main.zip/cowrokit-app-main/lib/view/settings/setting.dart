import 'package:co_workit/controllers/auth_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final TextStyle listTileTextStyle = TextStyle(color: Colors.black);
    final Color? iconColor = Get.theme.floatingActionButtonTheme.backgroundColor;
    final AuthService authService = Get.find();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: iconColor,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text('Settings', style: TextStyle(color: Colors.white)),
        actions: [

          IconButton(onPressed:()=> authService.logout(), icon: Icon(Icons.logout)),
          SizedBox(height: 10,),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8.0),
        child: ListView(
          children: <Widget>[
            ListTile(

              title: Text('Account Settings', style: listTileTextStyle),
              leading: Icon(Icons.account_circle, color: iconColor),
              onTap: () {
                // Navigate to account settings
              },
            ),
            ListTile(
              title: Text('Notifications', style: listTileTextStyle),
              leading: Icon(Icons.notifications, color: iconColor),
              onTap: () {
                // Navigate to notification settings
              },
            ),
            ListTile(
              title: Text('Privacy', style: listTileTextStyle),
              leading: Icon(Icons.lock, color: iconColor),
              onTap: () {
                // Navigate to privacy settings
              },
            ),
            ListTile(
              title: Text('Theme and Appearance', style: listTileTextStyle),
              leading: Icon(Icons.palette, color: iconColor),
              onTap: () {
                // Navigate to theme settings
              },
            ),
            ListTile(
              title: Text('Language and Region', style: listTileTextStyle),
              leading: Icon(Icons.language, color: iconColor),
              onTap: () {
                // Navigate to language settings
              },
            ),
            ListTile(
              title: Text('Data and Storage', style: listTileTextStyle),
              leading: Icon(Icons.storage, color: iconColor),
              onTap: () {
                // Navigate to data settings
              },
            ),
            ListTile(
              title: Text('Help and Support', style: listTileTextStyle),
              leading: Icon(Icons.help, color: iconColor),
              onTap: () {
                // Navigate to help and support
              },
            ),
            ListTile(
              title: Text('Legal', style: listTileTextStyle),
              leading: Icon(Icons.gavel, color: iconColor),
              onTap: () {
                // Navigate to legal information
              },
            ),
            ListTile(
              title: Text('General Settings', style: listTileTextStyle),
              leading: Icon(Icons.settings, color: iconColor),
              onTap: () {
                // Navigate to general settings
              },
            ),
          ],
        ),
      ),
    );
  }
}
