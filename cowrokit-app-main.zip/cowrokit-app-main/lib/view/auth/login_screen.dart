import 'package:co_workit/constant/custom_form_field.dart';
import 'package:co_workit/constant/custom_text_style.dart';
import 'package:co_workit/controllers/auth_controller.dart';
import 'package:co_workit/view/profile/profile_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../constant/custom_button.dart';
import '../bottom_bar/new_bottom_bar.dart';

class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final AuthService controller = Get.put(AuthService());
  CustomTextStyles textStyle = CustomTextStyles();

  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(
        children: [
          // Full screen container
          Container(
            alignment: Alignment.center,
            width: screenSize.width,
            height: 200,
            color: Theme.of(context).floatingActionButtonTheme.backgroundColor,
          ),
          Center(
            child: Padding(
              padding:
              const EdgeInsets.symmetric(horizontal: 16.0, vertical: 0),
              child: Form(
                key: controller.formKey,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 200,
                        width: 200,
                        child: Image.asset("assets/images/Coworkit-2.png"),
                      ),
                      Text(
                        "Log In".tr,
                        style: TextStyle(
                            color: Theme.of(context)
                                .floatingActionButtonTheme
                                .backgroundColor,
                            fontSize: 35,
                            fontWeight: FontWeight.w600),
                      ),
                      CustomTextFormField(
                        textStyle: TextStyle(
                            color: Theme.of(context).secondaryHeaderColor),
                        controller: controller.emailController,
                        validator: (value) => controller.validateEmail(value),
                        labelText: 'Email'.tr,
                        keyboardType: TextInputType.emailAddress,
                        prefixIcon: Icon(Icons.email,
                            color: Theme.of(context).secondaryHeaderColor),
                      ),
                      const SizedBox(height: 20),
                      CustomTextFormField(
                        textStyle: TextStyle(
                            color: Theme.of(context).secondaryHeaderColor),
                        controller: controller.passwordController,
                        validator: (value) =>
                            controller.validatePassword(value),
                        labelText: 'Password'.tr,
                        keyboardType: TextInputType.text,
                        prefixIcon: const Icon(Icons.lock, color: Colors.black),
                        obscureText: true,
                      ),
                      const SizedBox(height: 20),
                      Obx(() {
                        return controller.isLoading.value
                            ? const CircularProgressIndicator()
                            : CustomButton(
                          width: 100,
                          backgroundColor: Get
                              .theme.floatingActionButtonTheme.backgroundColor,
                          elevation: 2.0,
                          onPressed: () async {
                            if (controller.formKey.currentState?.validate() ??
                                false) {
                              bool response = await controller.login(
                                controller.emailController.text,
                                controller.passwordController.text,
                              );
                              if (response) {
                                Get.to(BottomBar());
                              } else {
                                Get.snackbar('Login Failed', 'Invalid email or password');
                              }
                            }
                          },
                          text: 'Login'.tr,
                        );
                      }),

                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
