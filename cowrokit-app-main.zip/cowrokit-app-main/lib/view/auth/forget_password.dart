import 'package:co_workit/constant/custom_button.dart';
import 'package:co_workit/constant/custom_form_field.dart';
import 'package:co_workit/constant/custom_text_style.dart';
import 'package:co_workit/controllers/forget_password_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../constant/custom_color.dart';

// ignore: must_be_immutable
class ForgetPassword extends StatelessWidget {
  final PasswordController controller = Get.put(PasswordController());
  CustomTextStyles textStyle=CustomTextStyles();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CustomColor.appBackgrounColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).floatingActionButtonTheme.backgroundColor,
        title: Text('Change Password'.tr,style: textStyle.head18b(context),),
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Container(
        width: double.infinity,
        color:  Theme.of(context).brightness == Brightness.light ? CustomColor.backgroundColor.withOpacity(0.8): CustomColorDark.backgroundColor,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: controller.formKey,
            child: Column(
              children: [
                CustomTextFormField(
                  textStyle: TextStyle(color: Theme.of(context).secondaryHeaderColor),
                  controller: controller.oldPasswordController,
                  onChanged: (value) => controller.oldPassword.value = value,
                  labelText: 'Old Password'.tr,
                  obscureText: true,
                  validator: (value) => controller.validateOldPassword(value!),
                ),
                const SizedBox(height: 8),
                CustomTextFormField(
                  textStyle: TextStyle(color: Theme.of(context).secondaryHeaderColor),
                  controller: controller.newPasswordController,
                  onChanged: (value) => controller.newPassword.value = value,
                  labelText: 'New Password'.tr,
                  obscureText: true,
                  validator: (value) => controller.validateNewPassword(value!),
                ),
                const SizedBox(height: 8),
                CustomTextFormField(

                  textStyle:  TextStyle(color: Theme.of(context).secondaryHeaderColor),
                  controller: controller.confirmNewPasswordController,
                  onChanged: (value) =>
                      controller.confirmNewPassword.value = value,
                  labelText: 'Confirm New Password'.tr,
                  obscureText: true,
                  validator: (value) =>
                      controller.validateConfirmNewPassword(value!),
                ),
                const SizedBox(height: 32),

                Obx((){
                return controller.isLoading.value
                    ? const CircularProgressIndicator()
                    : CustomButton(
                  height: 50,
                  width: 200,
                  onPressed: controller.resetPassword,
                  text: 'Change Password'.tr,
                  backgroundColor:  Theme.of(context).brightness == Brightness.dark
                      ? CustomColor.backgroundColor
                      : CustomColorDark.backgroundColor,);
                }),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
