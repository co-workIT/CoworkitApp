import 'package:co_workit/controllers/mailing_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class MailingView extends StatelessWidget {
  final MailingController mailingController = Get.put(MailingController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Obx(() {
        if (mailingController.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        } else {
          return ListView.builder(
            itemCount: mailingController.mailingList.length,
            itemBuilder: (context, index) {
              var item = mailingController.mailingList[index];
              return ListTile(
                title: Text(item.name ?? 'No Name'),
                subtitle: Text(item.date ?? 'No Date'),
                trailing: Text(item.companyId ?? 'No Company'),
              );
            },
          );
        }
      }),
    );
  }
}
