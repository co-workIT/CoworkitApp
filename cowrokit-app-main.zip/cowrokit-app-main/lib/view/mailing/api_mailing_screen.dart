import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controllers/new_mailing_controller.dart';


class MailingView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final MailingController controller = Get.put(MailingController());

    return Scaffold(
      appBar: AppBar(title: Text('Mailings')),
      body: Obx(() {
        if (controller.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        } else if (controller.errorMessage.value.isNotEmpty) {
          return Center(child: Text(controller.errorMessage.value));
        } else {
          return ListView.builder(
            itemCount: controller.mailings.length,
            itemBuilder: (context, index) {
              final mailing = controller.mailings[index];
              return ListTile(
                title: Text(mailing.name),
                subtitle: Text('Capacity: ${mailing.capacity}, Price: ${mailing.price}'),
              );
            },
          );
        }
      }),
    );
  }
}
