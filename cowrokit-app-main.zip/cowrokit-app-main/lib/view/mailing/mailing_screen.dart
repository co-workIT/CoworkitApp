import 'package:co_workit/constant/custom_form_field.dart';
import 'package:co_workit/constant/custom_text_style.dart';
import 'package:co_workit/controllers/mailing_controller.dart';
import 'package:co_workit/models/mailing_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../constant/custom_fab_button.dart';

class MailingScreen extends StatelessWidget {
  final MailingController mailingController = Get.put(MailingController());

  MailingScreen({Key? key}) : super(key: key);
  CustomTextStyles textStyle = CustomTextStyles();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: CustomFloatingButton(
        backgroundColor:
            Theme.of(context).floatingActionButtonTheme.backgroundColor,
        icon: Icon(Icons.add, color: Theme.of(context).iconTheme.color),
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) {
              return MailingDialog(mailingController: mailingController);
            },
          );
        },
      ),
      body: SafeArea(
        child: Obx(() {
          if (mailingController.isLoading.value) {
            return const Center(child: CircularProgressIndicator());
          }
          return Container(
            height: double.infinity,
            color: Theme.of(context).scaffoldBackgroundColor,
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(vertical: 10.0, horizontal: 30.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: ListView.builder(
                      itemCount: mailingController.mailingList.length,
                      itemBuilder: (context, index) {
                        final mailing = mailingController.mailingList[index];
                        return Card(
                          color: Theme.of(context).cardColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                          elevation: 4,
                          shadowColor: Theme.of(context).shadowColor,
                          margin: const EdgeInsets.symmetric(vertical: 8.0),
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    buildRow(
                                        'Name:'.tr,
                                        mailing.name!.toUpperCase().tr,
                                        context),
                                    buildRow('user id:'.tr,
                                        mailing.userId ?? '---', context),
                                    buildRow(
                                        'Date:'.tr, '${mailing.date}', context),
                                    buildRow('Price:'.tr,
                                        mailing.price ?? '---', context),
                                    buildRow('Owner:'.tr,
                                        mailing.ownedBy ?? '---', context),
                                    buildRow('Created By:'.tr,
                                        mailing.createdBy ?? '---', context),
                                    buildRow(
                                        'Created at:'.tr,
                                        '${mailing.createdAt?.substring(0, 10)} ${mailing.createdAt?.substring(11, 16)}' ??
                                            '---',
                                        context),
                                    buildRow(
                                        'Updated at:'.tr,
                                        '${mailing.updatedAt?.substring(0, 10)} ${mailing.updatedAt?.substring(11, 16)}' ??
                                            '---',
                                        context),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget buildRow(String label, String value, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Text(label, style: textStyle.text14b(context)),
          const SizedBox(width: 8.0),
          Text(value, style: textStyle.text14n(context)),
        ],
      ),
    );
  }
}

class MailingDialog extends StatefulWidget {
  final MailingController mailingController;
  final Data? mailing;

  MailingDialog({required this.mailingController, this.mailing});

  @override
  _MailingDialogState createState() => _MailingDialogState();
}

class _MailingDialogState extends State<MailingDialog> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _companyIdController;
  late TextEditingController _dateController;
  late DateTime _dateTime = DateTime.now();
  CustomTextStyles textStyle = CustomTextStyles();

  var datePicked = 'yyyy-mm-dd'.obs;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.mailing?.name ?? '');
    _companyIdController =
        TextEditingController(text: widget.mailing?.companyId ?? '');
    _dateController = TextEditingController(text: widget.mailing?.date ?? '');
    if (widget.mailing != null) {
      _dateTime = DateTime.parse(widget.mailing!.date!);
      datePicked.value = _dateController.text;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _companyIdController.dispose();
    _dateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.white,
      shadowColor: Colors.black54,
      title:
          Text(widget.mailing == null ? 'Add Mailing'.tr : 'Update Mailing'.tr),
      content: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomTextFormField(
              labelText: 'Name'.tr,
              padding: 8.0,
              keyboardType: TextInputType.text,
              controller: _nameController,
              prefixIcon: const Icon(Icons.person_2_rounded),
              textStyle: textStyle.text14b(context),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter a name'.tr;
                }
                return null;
              },
            ),
            ElevatedButton(
              onPressed: () async {
                FocusScope.of(context).requestFocus(new FocusNode());
                DateTime? picked = await showDatePicker(
                  context: context,
                  initialDate: _dateTime,
                  firstDate: DateTime(2000),
                  lastDate: DateTime(2101),
                );
                if (picked != null && picked != _dateTime) {
                  setState(() {
                    _dateTime = picked;
                    _dateController.text = _dateTime.toIso8601String();
                    datePicked.value = _dateController.text;
                  });
                }
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Icon(Icons.calendar_month),
                  SizedBox(width: 8.0),
                  Text(datePicked.substring(0, 10),
                      style: TextStyle(color: Colors.black)),
                ],
              ),
            ),
          ],
        ),
      ),
      actions: [
        Obx(() {
          return widget.mailingController.isLoading.value
              ? const CircularProgressIndicator()
              : Row(
                  children: [
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: Text('Cancel'.tr),
                    ),
                    TextButton(
                      onPressed: () {
                        if (_formKey.currentState?.validate() ?? false) {
                          if (widget.mailing == null) {
                            widget.mailingController.addMailing(
                              _nameController.text,
                              _dateController.text,
                              // _companyIdController.text,,
                            );
                          } else {
                            widget.mailingController.updateMailing(
                              widget.mailing!.id.toString(),
                              _nameController.text,
                              _dateController.text,
                              '0',
                            );
                          }
                          Navigator.of(context).pop();
                        }
                      },
                      child: Text(
                        widget.mailing == null ? 'Add'.tr : 'Update'.tr,
                        style: textStyle.themeText(context, 14,
                            Theme.of(context).secondaryHeaderColor, true),
                      ),
                    ),
                  ],
                );
        })
      ],
    );
  }
}
