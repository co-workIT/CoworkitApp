// import 'package:adaptive_theme/adaptive_theme.dart';
// import 'package:co_workit/constant/custom_color.dart';
// import 'package:co_workit/constant/custom_text_style.dart';
// import 'package:co_workit/controllers/mailing_controller.dart';
// import 'package:co_workit/models/mailing_model.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
//
// import '../../constant/custom_icon_button.dart';
//
// class MailingScreen extends StatelessWidget {
//   final MailingController mailingController = Get.put(MailingController());
//
//   MailingScreen({Key? key}) : super(key: key);
//   CustomTextStyles textStyle = CustomTextStyles();
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       floatingActionButton: CustomFloatingButton(
//         backgroundColor: CustomColor.bottomBarColor,
//         icon: const Icon(Icons.add, color: CustomColor.iconColorWhite),
//         onPressed: () {
//           showDialog(
//             context: context,
//             builder: (context) {
//               return MailingDialog(mailingController: mailingController);
//             },
//           );
//         },
//       ),
//       body: SafeArea(
//         child: GetBuilder<MailingController>(
//           builder: (controller) => Container(
//             height: double.infinity,
//             color: AdaptiveTheme.of(context).mode == AdaptiveThemeMode.light
//                 ? CustomColor.backgroundColor
//                 : CustomColorDark.backgroundColor,
//             child: Padding(
//               padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 30.0),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Expanded(
//                     child: ListView.builder(
//                       itemCount: controller.mailings.length,
//                       itemBuilder: (context, index) {
//                         final mailing = controller.mailings[index];
//                         return Card(
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(10.0),
//                           ),
//                           elevation: 4,
//                           shadowColor: CustomColor.shadowColor,
//                           margin: const EdgeInsets.symmetric(vertical: 8.0),
//                           child: Padding(
//                             padding: const EdgeInsets.all(16.0),
//                             child: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 buildRow('Name:', mailing.name.toUpperCase(), context),
//                                 buildRow('Date:', mailing.date, context),
//                                 buildRow('Price:', mailing.price, context),
//                                 const SizedBox(height: 10),
//                                 Row(                                  mainAxisAlignment: MainAxisAlignment.end,
//                                   children: [
//                                     IconButton(
//                                       icon: const Icon(Icons.edit, color: CustomColor.iconColorGreen),
//                                       onPressed: () {
//                                         showDialog(
//                                           context: context,
//                                           builder: (context) {
//                                             return MailingDialog(
//                                               mailingController: mailingController,
//                                               mailing: mailing,
//                                             );
//                                           },
//                                         );
//                                       },
//                                     ),
//                                     IconButton(
//                                       icon: const Icon(Icons.delete, color: CustomColor.iconColorRed),
//                                       onPressed: () {
//                                         mailingController.deleteMailing(mailing.id);
//                                       },
//                                     ),
//                                   ],
//                                 ),
//                               ],
//                             ),
//                           ),
//                         );
//                       },
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget buildRow(String label, String value, BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 4.0),
//       child: Row(
//         children: [
//           Text(label, style: textStyle.text14b(context)),
//           const SizedBox(width: 8.0),
//           Text(value, style: textStyle.text14n(context)),
//         ],
//       ),
//     );
//   }
// }
//
// class MailingDialog extends StatefulWidget {
//   final MailingController mailingController;
//   final MailingModel? mailing;
//
//   MailingDialog({required this.mailingController, this.mailing});
//
//   @override
//   _MailingDialogState createState() => _MailingDialogState();
// }
//
// class _MailingDialogState extends State<MailingDialog> {
//   final _formKey = GlobalKey<FormState>();
//   late TextEditingController _nameController;
//   late TextEditingController _priceController;
//   late DateTime _dateTime = DateTime.now();
//
//   @override
//   void initState() {
//     super.initState();
//     _nameController = TextEditingController(text: widget.mailing?.name ?? '');
//     _priceController = TextEditingController(text: widget.mailing?.price ?? '');
//     if (widget.mailing != null) {
//       _dateTime = DateTime.parse(widget.mailing!.date);
//     }
//   }
//
//   @override
//   void dispose() {
//     _nameController.dispose();
//     _priceController.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return AlertDialog(
//       title: Text(widget.mailing == null ? 'Add Mailing' : 'Update Mailing'),
//       content: Form(
//         key: _formKey,
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             TextFormField(
//               controller: _nameController,
//               decoration: const InputDecoration(labelText: 'Name'),
//               validator: (value) {
//                 if (value == null || value.isEmpty) {
//                   return 'Please enter a name';
//                 }
//                 return null;
//               },
//             ),
//             TextFormField(
//               controller: _priceController,
//               decoration: const InputDecoration(labelText: 'Price'),
//               validator: (value) {
//                 if (value == null || value.isEmpty) {
//                   return 'Please enter a price';
//                 }
//                 return null;
//               },
//             ),
//             const SizedBox(height: 16),
//             Row(
//               children: [
//                 Text('Date: ${_dateTime.toLocal()}'.split(' ')[0]),
//                 const SizedBox(width: 8),
//                 ElevatedButton(
//                   onPressed: () async {
//                     final pickedDate = await showDatePicker(
//                       context: context,
//                       initialDate: _dateTime,
//                       firstDate: DateTime(2000),
//                       lastDate: DateTime(2101),
//                     );
//                     if (pickedDate != null && pickedDate != _dateTime) {
//                       setState(() {
//                         _dateTime = pickedDate;
//                       });
//                     }
//                   },
//                   child: const Text('Select date'),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//       actions: [
//         TextButton(
//           onPressed: () => Navigator.of(context).pop(),
//           child: const Text('Cancel'),
//         ),
//         TextButton(
//           onPressed: () {
//             if (_formKey.currentState?.validate() ?? false) {
//               if (widget.mailing == null) {
//                 widget.mailingController.addMailing(
//                   MailingModel(
//                     id: DateTime.now().millisecondsSinceEpoch,
//                     name: _nameController.text,
//                     date: _dateTime.toIso8601String(),
//                     price: _priceController.text,
//                   ),
//                 );
//               } else {
//                 widget.mailingController.updateMailing(
//                   MailingModel(
//                     id: widget.mailing!.id,
//                     name: _nameController.text,
//                     date: _dateTime.toIso8601String(),
//                     price: _priceController.text,
//                   ),
//                 );
//               }
//               Navigator.of(context).pop();
//             }
//           },
//           child: Text(widget.mailing == null ? 'Add' : 'Update'),
//         ),
//       ],
//     );
//   }
// }
