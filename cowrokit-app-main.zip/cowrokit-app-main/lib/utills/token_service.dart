// lib/services/token_service.dart

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class TokenService {
  static final _storage = FlutterSecureStorage();

  // Storing the token
  static Future<void> storeToken(String token) async {
    await _storage.write(key: 'bearer_token', value: token);
  }

  // Retrieving the token
  static Future<String?> getToken() async {
    return await _storage.read(key: 'bearer_token');
  }

  // Deleting the token (optional)
  static Future<void> deleteToken() async {
    await _storage.delete(key: 'bearer_token');
  }
}
