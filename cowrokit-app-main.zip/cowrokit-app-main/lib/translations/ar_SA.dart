const Map<String, String> arSA = {
  //invoice Screen
  'Invoices':'الفواتير',
  'No invoices available': 'لا توجد فواتير',
  'Invoice #:': 'رقم الفاتورة:',
  'Issue Date:': 'تاريخ الإصدار:',
  'Due Date:': 'تاريخ الاستحقاق:',
  'Due Amount:': 'المبلغ المستحق:',
  'Status:': 'الحالة:',
  'Paid': 'مدفوع',
  'Unpaid': 'غير مدفوع',

  //booking Screen
  'Bookings':'الحجوزات',
  'Mailing':'المراسلات',
  'Visitors':'الزائرين',
  // Add more keys and translations here
};
