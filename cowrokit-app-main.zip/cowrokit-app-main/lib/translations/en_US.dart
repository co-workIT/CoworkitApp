const Map<String, String> enUS = {
  //drawer
  'Home':'Home',
  'Profile':'Profile',
  'Favourites':'Favourites',
  'Settings':'Settings',
  'Theme':'Theme',


  //bottombar

  'Mailings':'Mailings',

  //mailing Scrren
  'Name:':'Name:',
  'Date:':'Date:',
  'Price:':'Price:',
  'Rs.':'Rs.',
  'Add Mailing':'Add Mailing',
  'Update Mailing':'Update Mailing',
  'Name':'Name',
  'Please enter a name':'Please enter a name',
  'Price':'Price',
  'Please enter a Price':'Please enter a Price',
  'Date':'Date',
  'mm-dd-yyyy':'mm-dd-yyyy',
  'Please enter a valid Date':'Please enter a valid Date',
  'Cancel':'Cancel',
  'Add' :'Add',
  'Update':'Update',


  //invoice Screen
  'Invoices':'Invoices',
  'No invoices available':'No invoices available',
  'Invoice #:':'Invoice #:',
  'Issue Date:':'Issue Date:',
  'Due Date:':'Due Date:',
  'Due Amount:':'Due Amount:',
  'Status:':'Status:',
  'Paid':'Paid',
  'Unpaid':'Unpaid',

  //Invoice Details
  'Invoice Details':'Invoice Details',
  'Invoice ID: #':'Invoice ID: #',
  'Issue Date: ':'Issue Date: ',
  'Due Date: ':'Due Date: ',
  'Due Amount: ':'Due Amount: ',
  'Invoice: #':'Invoice: #',
  'Products:':'Products:',
  'Quantity:':'Quantity:',
  'Rate:':'Rate:',
  'Discount:':'Discount:',
  'Tax:':'Tax:',
  'Description:':'Description:',


  //booking screen
  'Bookings':'Bookings',

  'Mailing':'Mailing',

  //visitors screen
  'Visitors':'Visitors',
  'Visitor Name':'Visitor Name',
  'Visitor CNIC':'Visitor CNIC',
  'Add Visitor' :'Add Visitor' ,
  'Update Visitor':'Update Visitor',
  'CNIC':'CNIC',

  //Settings
  'Account Settings':'Account Settings',
  'Notifications':'Notifications',
  'Privacy':'Privacy',
  'Theme and Appearance':'Theme and Appearance',
  'Language and Region':'Language and Region',
  'Data and Storage':'Data and Storage',
  'Help and Support':'Help and Support',
  'Legal':'Legal',
  'General Settings':'General Settings',

  //onboardings


  //Lopin
'Log In':'Log In',
'Email':'Email',
  'Password':'Password',
  'Login':'Login',
//forgetPassword
  'Change Password':'Change Password',
  'Old Password':'Old Password',
  'New Password':'New Password',
  'Confirm New Password':'Confirm New Password',


};
