const Map<String, String> esES = {
  //invoice
  'Invoices':'Facturas',
  'No invoices available': 'No hay facturas disponibles',
  'Invoice #:': 'Factura #:',
  'Issue Date:': 'Fecha de emisión:',
  'Due Date:': 'Fecha de vencimiento:',
  'Due Amount:': 'Monto adeudado:',
  'Status:': 'Estado:',
  'Paid': 'Pagado',
  'Unpaid': 'No pagado',

  //Booking
  'Bookings':'Reservaciones',
  'Mailing':'Envío',
  'Visitors':'Visitantes',
  // Add more keys and translations here
};
