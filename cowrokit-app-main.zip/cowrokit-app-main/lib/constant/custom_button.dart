import 'package:flutter/material.dart';
import 'package:co_workit/constant/custom_color.dart';

class CustomButton extends StatelessWidget {
  final VoidCallback onPressed;
  final String text;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final Color? iconColor;
  final IconData? icon;
  final double? elevation;
  final double height;
  final double width;
  final double? borderRadius;
  final bool? isTextWhite;

  const CustomButton({
    required this.onPressed,
    required this.text,
    this.backgroundColor,
    this.foregroundColor,
    this.iconColor,
    this.icon,
    this.elevation,
    this.borderRadius,
    this.isTextWhite,
    this.height = 50,
    this.width = 200,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.all<Color>(
              backgroundColor ?? CustomColor.buttonColor),
          foregroundColor:
              WidgetStateProperty.all<Color>(foregroundColor ?? Colors.white),
          elevation: WidgetStateProperty.all<double>(elevation ?? 4.0),
          shape: WidgetStateProperty.all<RoundedRectangleBorder>(
            RoundedRectangleBorder(
              
              borderRadius: BorderRadius.circular(borderRadius ?? 10.0),
            ),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            if (icon!=null) Icon(icon,color: iconColor,),
            SizedBox(width: 10,),
            Text(
              text,
              style: TextStyle(
                color: Theme.of(context).brightness == Brightness.light
                    ? CustomColor.backgroundColor
                    : CustomColorDark.backgroundColor,
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
