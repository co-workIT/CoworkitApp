import 'package:flutter/material.dart';

class CustomColor {
  //need to uses these colors only
  static const Color primaryColor = Colors.white;
  static const Color secondaryColor = Colors.white;
  static const Color backgroundColor = Colors.white;
  static const Color textColor = Colors.black;
  static const Color buttonColor = Color.fromRGBO(36,107,253,1);
  static const Color iconColor = Color.fromRGBO(36,107,253,1);
  static const Color systemBottomBarColor = Colors.black12;
  static const Color SplashScreen = Color.fromRGBO(36,107,253,1);

  static const Color headingColor = Color.fromRGBO(36,107,253,1);

  static const Color textColortheme = Color.fromRGBO(47, 72, 88,1);
  static const Color textColorWhite = Colors.white;

  static const Color iconColorWhite = Colors.white;
  static const Color iconColorblack = Colors.black;
  static const Color buttonTextColor = Colors.white;
  static const Color appBarColor = Color.fromRGBO(33,169,255,1);
  //static const Color cardColor = Color.fromRGBO(194, 209, 216,1);

  static const Color bottomBarColor =Color.fromRGBO(33,169,255,1);
  static const Color labelTextColor =Colors.white;
  static const Color selectedItemColor =Colors.white;
  static const Color unselectedItemColor =Colors.white30;

  static const Color borderColorBlack =Colors.black12;
  static const Color borderColorWhite =Colors.white10;
  static const Color textColorPaid =Colors.green;
  static const Color iconColorGreen =Colors.green;

  static const Color iconColorRed =Colors.red;
  static const Color textColorUnpaid =Colors.redAccent;
  static const Color textDefaultColor =Colors.white70;

  static const Color cardColor =Color.fromRGBO(0, 193, 179,1);
  static const Color appBackgrounColor =Colors.white;
  static const Color shadowColor =Colors.white30;
  static const Color formText =Color.fromRGBO(19, 31, 88,1);

}

class CustomColorDark {

  //need to uses these colors only
  static const Color primaryColor = Colors.white;
  static const Color secondaryColor = Colors.white;
  static const Color backgroundColor = Colors.black87;
  static const Color textColor = Colors.white;
  static const Color iconColor = Colors.white;


  static const Color textColortheme = Color.fromRGBO(47, 72, 88,1);
  // static const Color textColor = Colors.white;
  static const Color textColorWhite = Colors.white;
  static const Color buttonColor = Color.fromRGBO(33,169,255,1);

  static const Color iconColorWhite = Colors.white;
  static const Color iconColorblack = Colors.white;
  static const Color buttonTextColor = Colors.white;
  static const Color appBarColor = Color.fromRGBO(33,169,255,1);
  //static const Color cardColor = Color.fromRGBO(194, 209, 216,1);

  static const Color bottomBarColor =Colors.white;
  static const Color labelTextColor =Colors.white;
  static const Color selectedItemColor =Colors.white;
  static const Color unselectedItemColor =Colors.white30;

  static const Color borderColorBlack =Colors.black12;
  static const Color borderColorWhite =Colors.white10;
  static const Color textColorPaid =Colors.green;
  static const Color iconColorGreen =Colors.green;

  static const Color iconColorRed =Colors.red;
  static const Color textColorUnpaid =Colors.redAccent;
  static const Color textDefaultColor =Colors.white70;

  static const Color cardColor =Color.fromRGBO(0, 193, 179,1);
  static const Color appBackgrounColor =Colors.white;
  static const Color shadowColor =Colors.white30;
  static const Color formText =Color.fromRGBO(19, 31, 88,1);



}
