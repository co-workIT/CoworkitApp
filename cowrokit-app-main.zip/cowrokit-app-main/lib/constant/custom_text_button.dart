import 'package:flutter/material.dart';
import 'package:co_workit/constant/custom_color.dart';

class CustomTextButton extends StatelessWidget {
  final VoidCallback onPressed;
  final String text;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final double? elevation;
  final double? borderRadius;
  final bool? isTextWhite;
  final double height;
  final double width;
  final Color? textColor;

  const CustomTextButton({
    required this.onPressed,
    required this.text,
    this.backgroundColor,
    this.foregroundColor,
    this.elevation,
    this.borderRadius,
    this.isTextWhite,
    this.textColor,
    this.height = 50,
    this.width = 150,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
        width: width,
        height: height,
        child: TextButton(
          onPressed: onPressed,
          style: ButtonStyle(
            backgroundColor: WidgetStateProperty.all<Color>(
                backgroundColor ?? CustomColor.primaryColor),
            foregroundColor:
                WidgetStateProperty.all<Color>(foregroundColor ?? Colors.white),
            shape: WidgetStateProperty.all<RoundedRectangleBorder>(
              RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(borderRadius ?? 10.0),
              ),
            ),
          ),
          child: Text(
            text,
            style: TextStyle(
              color: textColor ??
                  (Theme.of(context).brightness == Brightness.dark
                      ? CustomColor.backgroundColor
                      : CustomColorDark.backgroundColor),
              fontSize: 16,
            ),
          ),
        )
        // ElevatedButton(
        //   onPressed: onPressed,
        //   style: ButtonStyle(
        //     backgroundColor: MaterialStateProperty.all<Color>(backgroundColor ?? CustomColor.primaryColor),
        //     foregroundColor: MaterialStateProperty.all<Color>(foregroundColor ?? Colors.white),
        //     elevation: MaterialStateProperty.all<double>(elevation ?? 4.0),
        //     shape: MaterialStateProperty.all<RoundedRectangleBorder>(
        //       RoundedRectangleBorder(
        //         borderRadius: BorderRadius.circular(borderRadius ?? 40.0),
        //       ),
        //     ),
        //   ),
        //   child: Text(
        //     text,
        //     style: const TextStyle(
        //       color: CustomColor.textColorWhite,
        //       fontSize: 16,
        //     ),
        //   ),
        // ),
        );
  }
}
