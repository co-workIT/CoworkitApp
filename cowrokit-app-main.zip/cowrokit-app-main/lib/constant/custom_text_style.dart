import 'package:co_workit/constant/custom_color.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CustomTextStyles {
  TextStyle headline1(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontSize: 32,
      fontWeight: FontWeight.bold,
      color: isLightMode ? CustomColor.textColor : Colors.white,
    );
  }

  TextStyle headline2(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontSize: 24,
      fontWeight: FontWeight.w600,
      color: isLightMode ? CustomColor.textColor : Colors.white,
    );
  }

  TextStyle text16b400(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontSize: 16,
      fontWeight: FontWeight.w400,
      color: isLightMode ? Colors.white : Colors.black,
    );
  }

  TextStyle text14(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontSize: 14,
      fontWeight: FontWeight.normal,
      color: isLightMode ? Colors.black : Colors.white,
    );
  }

  TextStyle text14b(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontSize: 14,
      fontWeight: FontWeight.bold,
      color: isLightMode ? Colors.black : Colors.white,
    );
  }

  TextStyle text14n(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontWeight: FontWeight.normal,
      fontSize: 14,
      color: isLightMode ? CustomColor.textColortheme : Colors.white,
    );
  }

  TextStyle headline3(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontSize: 16,
      fontWeight: FontWeight.normal,
      color: isLightMode ? CustomColor.textColor : Colors.white,
    );
  }

  TextStyle headline4(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontSize: 14,
      fontWeight: FontWeight.normal,
      color: isLightMode ? CustomColor.textColor : Colors.white,
    );
  }

  TextStyle paragraph(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontSize: 14,
      fontWeight: FontWeight.normal,
      color: isLightMode ? CustomColor.textColor : Colors.white,
    );
  }

  TextStyle formText(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontSize: 14,
      fontWeight: FontWeight.bold,
      color: isLightMode ? CustomColor.formText : Colors.white,
    );
  }

  TextStyle button(BuildContext context) {
    return const TextStyle(
      fontFamily: 'Ubuntu',
      fontSize: 16,
      fontWeight: FontWeight.bold,
      color: Colors.white,
    );
  }

  TextStyle text14bw(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontWeight: FontWeight.bold,
      fontSize: 14,
      color: isLightMode ? CustomColor.textColorWhite : Colors.black,
    );
  }

  TextStyle text16bw(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontWeight: FontWeight.bold,
      fontSize: 16,
      color: isLightMode ? CustomColor.textColorWhite : Colors.black,
    );
  }

  TextStyle text16b(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontWeight: FontWeight.bold,
      fontSize: 16,
      color: isLightMode ? CustomColor.textColorWhite : Colors.black,
    );
  }

  TextStyle text14nPaid(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontWeight: FontWeight.normal,
      fontSize: 14,
      color: isLightMode ? CustomColor.textColorPaid : Colors.greenAccent,
    );
  }

  TextStyle text14nUnpaid(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontWeight: FontWeight.normal,
      fontSize: 14,
      color: isLightMode ? CustomColor.textColorUnpaid : Colors.redAccent,
    );
  }

  TextStyle head18b(BuildContext context) {
    bool isDarkMode = Theme.of(context).brightness == Brightness.dark;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontWeight: FontWeight.bold,
      fontSize: 18,
      color: !isDarkMode ? CustomColor.textColorWhite : Colors.black,
    );
  }

  TextStyle head18bw(BuildContext context) {
    bool isDarkMode = Theme.of(context).brightness == Brightness.dark;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontWeight: FontWeight.bold,
      fontSize: 18,
      color: isDarkMode ? CustomColor.textColorWhite : Colors.black,
    );
  }

  TextStyle head16b(BuildContext context) {
    bool isLightMode = !Get.isDarkMode;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontWeight: FontWeight.bold,
      fontSize: 16,
      color: !isLightMode ? CustomColor.textColorWhite : Colors.black,
    );
  }

  TextStyle head16n(BuildContext context) {
    bool isLightMode = !Get.isDarkMode;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontWeight: FontWeight.normal,
      fontSize: 16,
      color: !isLightMode ? CustomColor.textColorWhite : Colors.black,
    );
  }

  TextStyle head18bb(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontWeight: FontWeight.bold,
      fontSize: 18,
      color: isLightMode ? CustomColor.textColor : Colors.white,
    );
  }

  TextStyle head26b(BuildContext context) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontWeight: FontWeight.bold,
      fontSize: 26,
      color: isLightMode ? CustomColor.textColor : Colors.white,
    );
  }

  TextStyle themeText(
      BuildContext context, double fontSize, Color? color, bool isBold) {
    bool isLightMode = Theme.of(context).brightness == Brightness.light;
    return TextStyle(
      fontFamily: 'Ubuntu',
      fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
      fontSize: fontSize,
      color: color ?? (isLightMode ? CustomColor.textColor : Colors.white),
    );
  }
}
