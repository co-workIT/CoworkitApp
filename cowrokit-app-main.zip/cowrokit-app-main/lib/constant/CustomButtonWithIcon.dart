import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:co_workit/constant/custom_color.dart';
import 'package:flutter/widgets.dart';

class CustomIconButton extends StatelessWidget {
  final VoidCallback onPressed;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final double? elevation;
  final double height;
  final double width;
  final double? borderRadius;
  final bool? isTextWhite;
  IconData? icon;
  final Color? iconColor;

  CustomIconButton({
    required this.onPressed,
    this.backgroundColor,
    this.foregroundColor,
    this.elevation,
    this.borderRadius,
    this.isTextWhite,
    required this.icon,
    this.iconColor,
    this.height = 50,
    this.width = 50,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: IconButton(
        onPressed: onPressed,
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.all<Color>(
              backgroundColor ?? Color.fromRGBO(72, 73, 75, 1)),
          foregroundColor:
              WidgetStateProperty.all<Color>(foregroundColor ?? Colors.white),
          elevation: WidgetStateProperty.all<double>(elevation ?? 4.0),
          shape: WidgetStateProperty.all<RoundedRectangleBorder>(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(borderRadius ?? 10.0),
            ),
          ),
        ),
        icon: Icon(
          icon,
          color: iconColor,
        ),
      ),
    );
  }
}
