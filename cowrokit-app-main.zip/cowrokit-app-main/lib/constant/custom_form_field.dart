// import 'package:flutter/material.dart';

// class CustomTextFormField extends StatelessWidget {
//   final TextEditingController? controller;
//   final String? labelText;
//   final String? hintText;
//   final bool obscureText;
//   final TextInputType? keyboardType;
//   final String? Function(String?)? validator;
//   final void Function(String)? onFieldSubmitted;
//   final void Function(String)? onChanged;
//   final Widget? prefixIcon;
//   final Widget? suffixIcon;

//   const CustomTextFormField({
//     super.key,
//     this.controller,
//     this.labelText,
//     this.hintText,
//     this.obscureText = false,
//     this.keyboardType,
//     this.validator,
//     this.onFieldSubmitted,
//     this.onChanged,
//     this.prefixIcon,
//     this.suffixIcon,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.all(16),
//       child: Container(
//         width: 300,
//         height: 50,
//         child: TextFormField(
//           controller: controller,
//           obscureText: obscureText,
//           keyboardType: keyboardType,
//           validator: validator,
//           onFieldSubmitted: onFieldSubmitted,
//           onChanged: onChanged,
//           decoration: InputDecoration(
//             labelText: labelText,
//             hintText: hintText,
//             prefixIcon: prefixIcon,
//             suffixIcon: suffixIcon,
//           ),
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';

import 'custom_color.dart';

class CustomTextFormField extends StatelessWidget {
  final TextEditingController? controller;
  final String? labelText;
  final String? hintText;
  final TextStyle textStyle;
  final TextStyle? hintstyle;
  final bool obscureText;
  final TextInputType? keyboardType;
  final String? Function(String?)? validator;
  final void Function(String)? onFieldSubmitted;
  final void Function(String)? onChanged;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final double padding;
  final double height;
  final double width;
  final double radius;
  final double borderWidth;

  const CustomTextFormField({
    super.key,
    this.controller,
    this.labelText,
    this.hintText,
    this.hintstyle,
    this.obscureText = false,
    this.keyboardType,
    this.validator,
    this.onFieldSubmitted,
    this.onChanged,
    this.prefixIcon,
    this.suffixIcon,
    this.borderWidth = 1.0,
    this.radius = 10,
    this.height = 50,
    this.width = 300,
    this.padding = 16.0,
    required this.textStyle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(padding),
      child: SizedBox(
        width: width,
        height: height,
        child: TextFormField(
          showCursor: true,
          cursorWidth: 1.0,
          cursorColor: Colors.black,
          controller: controller,
          obscureText: obscureText,
          keyboardType: keyboardType,
          validator: validator,
          onFieldSubmitted: onFieldSubmitted,
          onChanged: onChanged,
          decoration: InputDecoration(
            hintStyle: hintstyle,
            labelText: labelText,
            labelStyle: textStyle,
            hintText: hintText,
            prefixIcon: prefixIcon,
            suffixIcon: suffixIcon,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(radius),
              borderSide: const BorderSide(
                color: Colors.black,
                width: 1.0,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(radius),
              borderSide: const BorderSide(
                color: CustomColor.appBarColor,
                width: 2.0,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(radius),
              borderSide: const BorderSide(
                color: Colors.grey,
                width: 1.0,
              ),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(radius),
              borderSide: const BorderSide(
                color: Colors.red,
                width: 1.0,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
