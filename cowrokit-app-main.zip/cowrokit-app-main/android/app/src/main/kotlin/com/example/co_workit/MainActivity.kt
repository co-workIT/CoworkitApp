package com.example.co_workit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
